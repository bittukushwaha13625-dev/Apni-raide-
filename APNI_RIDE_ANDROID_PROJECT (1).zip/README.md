# 🚖 APNI RIDE (अपनी राइड) – Complete Android & Web Mobility Platform
> **Tagline:** *"Aapki Ride, Aapka Safar"* (आपकी राइड, आपका सफर)  
> **Launch City:** Ambikapur, Chhattisgarh, India (RTO Code: CG-15)  
> **App Types:** Bike Taxi, Auto Rickshaw, and Car/Cab Booking Platform  
> **Package ID:** `com.apniride.ambikapur`  
> **Target SDK:** Android 14 (API Level 34)

---

## 📱 Project Architecture & Modules Included

This project contains the complete, production-ready source code for:

1. **Customer App (`src/components/Customer`)**:
   - Mobile number login with OTP verification simulation
   - Real-time GPS location detection across Ambikapur
   - Interactive Leaflet & OpenStreetMap / CartoDB / Satellite / Terrain map views
   - Complete Ambikapur road network, mohallas, landmarks, petrol pumps, colleges, hospitals
   - Instant booking & "Schedule for Later"
   - Fare estimates and route distance calculation
   - Live driver movement tracking on the map
   - In-app driver chat & simulated direct calling
   - Cash, UPI (Google Pay, PhonePe, Paytm), and Wallet payment
   - Ride cancellation with reason selection
   - SOS Emergency panic button with Ambikapur police integration
   - Customer profile, saved home/office places, ride history, and PDF invoice generation
   - Hindi & English language toggle

2. **Driver Partner App (`src/components/Driver`)**:
   - Driver onboarding & registration
   - Aadhaar KYC and Driving License document upload simulation
   - Online / Offline availability toggle switch
   - Real-time incoming ride request popups (Accept / Reject with audio tone)
   - Turn-by-turn spoken voice navigation (Web Speech API)
   - OTP start ride confirmation & complete trip flow
   - Daily, weekly, monthly earnings breakdown with company commission deduction
   - In-app wallet, cash collection logs, and instant payout requests
   - Driver rating & performance dashboard
   - Driver SOS emergency button

3. **Admin Command Center (`src/components/Admin`)**:
   - Live dashboard: Total customers, active drivers, total revenue, commission earned
   - Driver verification & document approval/rejection panel
   - Real-time ride monitoring map with live fleet positions
   - Customer support ticket handling & complaint resolution
   - Pricing & fare matrix management (per-km base fare, night surge, vehicle commission)
   - Promo code creator & referral bonus engine
   - Missing road / map error report management

4. **Brand Identity & 6 Official Logo Versions (`public/`)**:
   - `public/logo-main.svg`: Master brand lockup with APNI RIDE typography, category badges, and bilingual tagline
   - `public/icon.svg`: Android adaptive squircle launcher icon (512×512)
   - `public/logo-icon-only.svg`: Standalone Letter "A" velocity emblem (512×512)
   - `public/logo-horizontal.svg`: Wide header & vehicle side door decal (820×220)
   - `public/logo-monochrome.svg`: Black & White version for thermal receipts and uniform embroidery (600×640)
   - `public/logo-transparent.svg`: Zero-background transparent overlay (760×200)

5. **Android Native Project (`android/`)**:
   - Gradle build scripts (`build.gradle`, `app/build.gradle`, `settings.gradle`)
   - `AndroidManifest.xml` with all GPS, Background Location, Camera, Phone, and Notification permissions
   - `MainActivity.java` with hardware-accelerated WebView and HTML5 Geolocation bridge
   - `res/values/strings.xml`, `colors.xml`, `styles.xml`, and layouts

---

## 🛠️ Step-by-Step Instructions: How to Build & Install the Android APK

### Option A: Build via Android Studio (Recommended)

1. **Prerequisites:**
   - Install [Android Studio Hedgehog / Iguana / Jellyfish or newer](https://developer.android.com/studio).
   - Install Android SDK Platform 34 and JDK 17+.

2. **Build Web Assets:**
   In your terminal inside the project root:
   ```bash
   npm install
   npm run build
   ```
   This generates the optimized `dist/` production folder.

3. **Open Android Project in Android Studio:**
   - Launch Android Studio.
   - Click **Open** and select the `android/` directory inside this project folder.
   - Wait for Gradle sync to complete automatically.

4. **Build APK:**
   - In the top menu, go to **Build** → **Build Bundle(s) / APK(s)** → **Build APK(s)**.
   - Once compilation finishes, click **locate** in the popup notification.
   - Your APK file is ready at:
     `android/app/build/outputs/apk/debug/app-debug.apk`

5. **Build Signed Release APK / AAB for Google Play Store:**
   - Go to **Build** → **Generate Signed Bundle / APK**.
   - Select **Android App Bundle** (for Play Store) or **APK** (for direct distribution).
   - Create or select your release keystore and choose **release** build variant.
   - Click **Finish**.

---

### Option B: Build via Command Line (Terminal / Mac / Linux / Windows)

1. Open your terminal in the `android/` folder:
   ```bash
   cd android
   ```

2. Run the Gradle build command:
   * **On Linux / macOS:**
     ```bash
     chmod +x gradlew
     ./gradlew assembleRelease
     # Or for debug build:
     ./gradlew assembleDebug
     ```
   * **On Windows:**
     ```cmd
     gradlew.bat assembleRelease
     ```

3. The generated APK will be located at:
   `android/app/build/outputs/apk/release/app-release-unsigned.apk` (or `app-debug.apk`).

---

### Option C: Build via Capacitor CLI

This project is configured with `capacitor.config.json`. You can build with:
```bash
npm install
npm run build
npx cap add android        # (if not already added)
npx cap copy android
npx cap open android       # opens directly in Android Studio
```

---

## 📲 How to Install the APK on Your Android Device

1. **Transfer the APK to your phone:**
   - Connect your phone via USB cable and copy `app-debug.apk` to your phone's *Download* folder, OR
   - Send the APK to yourself via WhatsApp / Google Drive / Email, OR
   - Download `APNI_RIDE_ANDROID_PROJECT.zip` directly from the app interface.

2. **Install via Phone File Manager:**
   - Open the **Files** or **File Manager** app on your phone.
   - Tap on the APK file.
   - If prompted: *"For your security, your phone is not allowed to install unknown apps from this source"*, tap **Settings** and enable **"Allow from this source"**.
   - Tap **Install**.
   - Tap **Open** to launch **APNI RIDE**!
   - When asked, tap **"While using the app"** for Location permissions so the Ambikapur map can detect your location.

---

## 💻 Running the Web App Locally

To test or develop the web version locally on your computer:

```bash
# 1. Install dependencies
npm install

# 2. Start the development server
npm run dev
```

Open your browser and navigate to `http://localhost:3000`.

---

## 🔒 Android Permissions Configured

| Permission | Purpose in APNI RIDE |
|---|---|
| `ACCESS_FINE_LOCATION` | High-accuracy GPS tracking for rider pickup and driver navigation |
| `ACCESS_COARSE_LOCATION` | Approximate location detection |
| `ACCESS_BACKGROUND_LOCATION` | Continuous driver position streaming during an active ride |
| `INTERNET` | Real-time map tiles, ride dispatch, and server communication |
| `CALL_PHONE` | Direct calling between customer and driver |
| `VIBRATE` | Haptic feedback for new incoming ride alerts |
| `POST_NOTIFICATIONS` | Ride status notifications on Android 13+ |
| `CAMERA` | Instant capture for Driver License & Aadhaar KYC verification |

---

## 🏷️ Brand Palette Reference

- **Deep Royal Blue:** `#0a1931` (Background / Trust) & `#1d4ed8` (Action / Navigation)
- **Bright Electric Yellow:** `#facc15` / `#eab308` (Speed / Auto Rickshaw Heritage)
- **Pure White:** `#ffffff` (High-contrast typography)
- **Dark Charcoal:** `#070c16` (OLED battery efficiency in night rides)

---

*APNI RIDE – Built for Ambikapur, Surguja, Chhattisgarh (CG-15)*
