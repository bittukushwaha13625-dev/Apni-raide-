import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  AdminStats,
  ChatMessage,
  Driver,
  LocationPoint,
  PromoCode,
  Ride,
  RideStatus,
  SosAlert,
  VehicleCategory,
  VehicleOption,
} from '../types/ride';
import {
  AMBIKAPUR_CENTER,
  INITIAL_DRIVERS,
  POPULAR_LOCATIONS,
  PROMO_CODES,
  VEHICLE_OPTIONS,
} from '../data/ambikapurLocations';
import { Language, translations } from '../i18n/translations';
import { playSound } from '../utils/soundEffects';

interface CustomerProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  photo: string;
  walletBalance: number;
  rating: number;
  totalRides: number;
  isLoggedIn: boolean;
}

interface RideContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations.en;
  activeRole: 'customer' | 'driver' | 'admin';
  setActiveRole: (role: 'customer' | 'driver' | 'admin') => void;
  isDevicePreview: boolean;
  setIsDevicePreview: (val: boolean | ((prev: boolean) => boolean)) => void;
  showApkModal: boolean;
  setShowApkModal: (val: boolean) => void;
  
  // Locations & Vehicles
  popularLocations: LocationPoint[];
  vehicleOptions: VehicleOption[];
  promoCodes: PromoCode[];
  draftPickup: LocationPoint;
  draftDestination: LocationPoint;
  setDraftPickup: (loc: LocationPoint) => void;
  setDraftDestination: (loc: LocationPoint) => void;
  
  // Customer State
  customer: CustomerProfile;
  updateCustomerProfile: (data: Partial<CustomerProfile>) => void;
  customerLogin: (phone: string, otp: string) => boolean;
  
  // Ride Booking
  currentRide: Ride | null;
  rideHistory: Ride[];
  requestRide: (
    pickup: LocationPoint,
    drop: LocationPoint,
    vehicle: VehicleCategory,
    paymentMethod: 'cash' | 'upi' | 'wallet',
    appliedPromo?: PromoCode | null,
    isScheduled?: boolean,
    scheduledTime?: string
  ) => void;
  cancelRide: (reason?: string) => void;
  resetRide: () => void;
  rateRide: (rideId: string, rating: number, review: string) => void;
  
  // Driver Partner State
  currentDriver: Driver;
  drivers: Driver[];
  toggleDriverOnline: () => void;
  incomingRideRequest: Ride | null;
  driverAcceptRide: () => void;
  driverRejectRide: () => void;
  driverArrivedAtPickup: () => void;
  driverStartRide: (otp: string) => { success: boolean; error?: string };
  driverCompleteRide: () => void;
  driverSubmitKyc: (aadhaar: string, dl: string, vehicleNo: string) => void;
  
  // Real-time Vehicle Position
  driverPosition: { lat: number; lng: number; heading: number };
  
  // Chat & Communication
  chatMessages: ChatMessage[];
  sendChatMessage: (sender: 'customer' | 'driver', text: string) => void;
  
  // SOS & Emergency
  sosAlerts: SosAlert[];
  triggerSos: () => void;
  resolveSos: (id: string) => void;
  
  // Admin Center
  adminStats: AdminStats;
  adminApproveDriver: (driverId: string) => void;
  adminRejectDriver: (driverId: string) => void;
  adminUpdateFare: (category: VehicleCategory, base: number, perKm: number) => void;
}

const RideContext = createContext<RideContextType | undefined>(undefined);

export const RideProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('hi');
  const [activeRole, setActiveRole] = useState<'customer' | 'driver' | 'admin'>('customer');
  const [isDevicePreview, setIsDevicePreview] = useState<boolean>(false);
  const [showApkModal, setShowApkModal] = useState<boolean>(false);

  const t = translations[language];

  // Vehicles with editable fares
  const [vehicleOptions, setVehicleOptions] = useState<VehicleOption[]>(VEHICLE_OPTIONS);
  const [drivers, setDrivers] = useState<Driver[]>(INITIAL_DRIVERS);
  const [currentDriver, setCurrentDriver] = useState<Driver>(INITIAL_DRIVERS[0]);

  // Customer Profile
  const [customer, setCustomer] = useState<CustomerProfile>({
    id: 'cust-1',
    name: 'Aakash Verma',
    phone: '+91 94252 81920',
    email: 'aakash@ambikapur.in',
    photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    walletBalance: 420,
    rating: 4.95,
    totalRides: 24,
    isLoggedIn: true,
  });

  // Default draft locations: Pickup at Ghadi Chowk, Destination at Ambikapur Railway Station
  const [draftPickup, setDraftPickup] = useState<LocationPoint>(POPULAR_LOCATIONS[0]);
  const [draftDestination, setDraftDestination] = useState<LocationPoint>(POPULAR_LOCATIONS[1]);

  // Current Ride State
  const [currentRide, setCurrentRide] = useState<Ride | null>(null);
  const [incomingRideRequest, setIncomingRideRequest] = useState<Ride | null>(null);
  const [rideHistory, setRideHistory] = useState<Ride[]>([]);

  // Driver animated position
  const [driverPosition, setDriverPosition] = useState<{ lat: number; lng: number; heading: number }>({
    lat: INITIAL_DRIVERS[0].lat,
    lng: INITIAL_DRIVERS[0].lng,
    heading: 0,
  });

  // Chat
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);

  // SOS Alerts
  const [sosAlerts, setSosAlerts] = useState<SosAlert[]>([]);

  // Admin Stats
  const [adminStats, setAdminStats] = useState<AdminStats>({
    totalCustomers: 14820,
    totalDrivers: 128,
    totalRides: 38940,
    activeRides: 0,
    cancelledRides: 142,
    dailyRevenue: 54200,
    monthlyRevenue: 1380000,
    platformProfit: 207000,
  });

  // Animation interval reference
  const moveIntervalRef = useRef<number | null>(null);

  // Helper to calculate distance in km using Haversine formula
  const calculateDistance = (p1: { lat: number; lng: number }, p2: { lat: number; lng: number }) => {
    const R = 6371; // km
    const dLat = ((p2.lat - p1.lat) * Math.PI) / 180;
    const dLon = ((p2.lng - p1.lng) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((p1.lat * Math.PI) / 180) *
        Math.cos((p2.lat * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.max(1.2, Number((R * c).toFixed(1)));
  };

  // Helper to calculate bearing
  const calculateBearing = (startLat: number, startLng: number, destLat: number, destLng: number) => {
    const y = Math.sin((destLng - startLng) * (Math.PI / 180)) * Math.cos(destLat * (Math.PI / 180));
    const x =
      Math.cos(startLat * (Math.PI / 180)) * Math.sin(destLat * (Math.PI / 180)) -
      Math.sin(startLat * (Math.PI / 180)) *
        Math.cos(destLat * (Math.PI / 180)) *
        Math.cos((destLng - startLng) * (Math.PI / 180));
    let brng = (Math.atan2(y, x) * 180) / Math.PI;
    return (brng + 360) % 360;
  };

  // Request a Ride
  const requestRide = (
    pickup: LocationPoint,
    drop: LocationPoint,
    vehicleCat: VehicleCategory,
    paymentMethod: 'cash' | 'upi' | 'wallet',
    appliedPromo?: PromoCode | null,
    isScheduled: boolean = false,
    scheduledTime?: string
  ) => {
    const vehicleObj = vehicleOptions.find((v) => v.id === vehicleCat) || vehicleOptions[0];
    const distanceKm = calculateDistance(pickup, drop);
    const durationMinutes = Math.max(4, Math.round(distanceKm * 2.5));

    const distanceFare = Math.round(distanceKm * vehicleObj.perKmRate);
    const baseFare = vehicleObj.baseFare;
    const rawTotal = Math.max(vehicleObj.minFare, baseFare + distanceFare);

    let discount = 0;
    if (appliedPromo) {
      discount = Math.min(appliedPromo.maxDiscount, Math.round((rawTotal * appliedPromo.discountPercent) / 100));
    }
    const finalFare = Math.max(15, rawTotal - discount);
    const driverCommission = Math.round(finalFare * 0.15);

    // Random 4-digit PIN for passenger verification
    const randomOtp = Math.floor(1000 + Math.random() * 9000).toString();

    const newRide: Ride = {
      id: `AR-${Date.now().toString().slice(-6)}`,
      customerId: customer.id,
      customerName: customer.name,
      customerPhone: customer.phone,
      pickup,
      destination: drop,
      vehicleCategory: vehicleCat,
      distanceKm,
      durationMinutes,
      fareAmount: rawTotal,
      baseFare,
      distanceFare,
      discountAmount: discount,
      finalFare,
      driverCommission,
      status: 'SEARCHING',
      startOtp: randomOtp,
      createdAt: Date.now(),
      paymentMethod,
      paymentStatus: 'pending',
      isScheduled,
      scheduledTime,
    };

    setCurrentRide(newRide);
    setIncomingRideRequest(newRide);
    setChatMessages([]);
    playSound('beep');

    // Notify sound alert
    setTimeout(() => {
      playSound('alert');
    }, 500);

    // If user is currently in Customer App or Admin view, automatically simulate driver acceptance after 3 seconds
    setTimeout(() => {
      // Pick matching driver
      const matchedDriver = drivers.find((d) => d.vehicleCategory === vehicleCat && d.isOnline) || drivers[0];
      if (matchedDriver) {
        setDriverPosition({
          lat: matchedDriver.lat,
          lng: matchedDriver.lng,
          heading: matchedDriver.heading,
        });

        const accepted: Ride = {
          ...newRide,
          driverId: matchedDriver.id,
          driver: matchedDriver,
          status: 'ARRIVING',
          acceptedAt: Date.now(),
        };

        setCurrentRide(accepted);
        setIncomingRideRequest(null);
        playSound('success');

        // Start animating driver towards pickup
        startDriverMovement(
          { lat: matchedDriver.lat, lng: matchedDriver.lng },
          { lat: pickup.lat, lng: pickup.lng },
          () => {
            // Arrived at pickup
            setCurrentRide((prev) => (prev ? { ...prev, status: 'ARRIVED' } : null));
            playSound('beep');
          }
        );
      }
    }, 3800);
  };

  // Driver Accept Ride manually from Driver App
  const driverAcceptRide = () => {
    if (!incomingRideRequest) return;
    playSound('success');

    const updatedRide: Ride = {
      ...incomingRideRequest,
      driverId: currentDriver.id,
      driver: currentDriver,
      status: 'ARRIVING',
      acceptedAt: Date.now(),
    };

    setCurrentRide(updatedRide);
    setIncomingRideRequest(null);

    // Animate driver to pickup
    startDriverMovement(
      { lat: currentDriver.lat, lng: currentDriver.lng },
      { lat: updatedRide.pickup.lat, lng: updatedRide.pickup.lng },
      () => {
        setCurrentRide((prev) => (prev ? { ...prev, status: 'ARRIVED' } : null));
        playSound('beep');
      }
    );
  };

  // Driver Reject Ride
  const driverRejectRide = () => {
    setIncomingRideRequest(null);
    playSound('beep');
  };

  // Driver arrived at pickup
  const driverArrivedAtPickup = () => {
    if (!currentRide) return;
    setCurrentRide({
      ...currentRide,
      status: 'ARRIVED',
    });
    playSound('beep');
  };

  // Driver Start Ride by validating OTP
  const driverStartRide = (enteredOtp: string): { success: boolean; error?: string } => {
    if (!currentRide) return { success: false, error: 'No active ride found' };
    if (enteredOtp.trim() !== currentRide.startOtp) {
      return { success: false, error: language === 'hi' ? 'गलत OTP! ग्राहक से 4-अंकीय कोड पूछें।' : 'Invalid OTP! Please ask customer for correct 4-digit PIN.' };
    }

    const startedRide: Ride = {
      ...currentRide,
      status: 'IN_PROGRESS',
      startedAt: Date.now(),
    };
    setCurrentRide(startedRide);
    playSound('success');

    // Animate driver from pickup to dropoff
    startDriverMovement(
      { lat: startedRide.pickup.lat, lng: startedRide.pickup.lng },
      { lat: startedRide.destination.lat, lng: startedRide.destination.lng },
      () => {
        // Complete ride
        driverCompleteRide();
      }
    );

    return { success: true };
  };

  // Driver Complete Ride
  const driverCompleteRide = () => {
    if (!currentRide) return;

    if (moveIntervalRef.current) {
      window.clearInterval(moveIntervalRef.current);
      moveIntervalRef.current = null;
    }

    const fare = currentRide.finalFare;
    const commission = currentRide.driverCommission;
    const netEarning = fare - commission;

    const completedRide: Ride = {
      ...currentRide,
      status: 'COMPLETED',
      completedAt: Date.now(),
      paymentStatus: 'paid',
    };

    setCurrentRide(completedRide);
    setRideHistory((prev) => [completedRide, ...prev]);

    // Update driver wallet & earnings
    setCurrentDriver((prev) => ({
      ...prev,
      earningsToday: prev.earningsToday + netEarning,
      totalEarnings: prev.totalEarnings + netEarning,
      walletBalance: prev.walletBalance + netEarning,
      totalRides: prev.totalRides + 1,
    }));

    // Update Admin Stats
    setAdminStats((prev) => ({
      ...prev,
      totalRides: prev.totalRides + 1,
      dailyRevenue: prev.dailyRevenue + fare,
      monthlyRevenue: prev.monthlyRevenue + fare,
      platformProfit: prev.platformProfit + commission,
    }));

    playSound('complete');
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }
  };

  // Cancel Ride
  const cancelRide = (reason: string = 'User requested cancellation') => {
    if (moveIntervalRef.current) {
      window.clearInterval(moveIntervalRef.current);
      moveIntervalRef.current = null;
    }
    if (currentRide) {
      const cancelled: Ride = {
        ...currentRide,
        status: 'CANCELLED',
        cancelledAt: Date.now(),
        cancelReason: reason,
      };
      setRideHistory((prev) => [cancelled, ...prev]);
      setAdminStats((prev) => ({ ...prev, cancelledRides: prev.cancelledRides + 1 }));
    }
    setCurrentRide(null);
    setIncomingRideRequest(null);
    playSound('beep');
  };

  const resetRide = () => {
    if (moveIntervalRef.current) {
      window.clearInterval(moveIntervalRef.current);
      moveIntervalRef.current = null;
    }
    setCurrentRide(null);
    setIncomingRideRequest(null);
  };

  // Rating
  const rateRide = (rideId: string, rating: number, review: string) => {
    setRideHistory((prev) =>
      prev.map((r) => (r.id === rideId ? { ...r, rating, review } : r))
    );
    if (currentRide?.id === rideId) {
      setCurrentRide((prev) => (prev ? { ...prev, rating, review } : null));
    }
    playSound('success');
  };

  // Smooth Vehicle movement interpolator
  const startDriverMovement = (
    start: { lat: number; lng: number },
    target: { lat: number; lng: number },
    onArrival: () => void
  ) => {
    if (moveIntervalRef.current) {
      window.clearInterval(moveIntervalRef.current);
    }

    const steps = 60;
    let step = 0;
    const bearing = calculateBearing(start.lat, start.lng, target.lat, target.lng);

    moveIntervalRef.current = window.setInterval(() => {
      step++;
      const progress = step / steps;
      const currentLat = start.lat + (target.lat - start.lat) * progress;
      const currentLng = start.lng + (target.lng - start.lng) * progress;

      setDriverPosition({
        lat: currentLat,
        lng: currentLng,
        heading: bearing,
      });

      if (step >= steps) {
        if (moveIntervalRef.current) {
          window.clearInterval(moveIntervalRef.current);
          moveIntervalRef.current = null;
        }
        onArrival();
      }
    }, 400); // ~24s realistic journey for prototype demonstration
  };

  // Chat message sending with simulated pilot reply
  const sendChatMessage = (sender: 'customer' | 'driver', text: string) => {
    if (!text.trim() || !currentRide) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      rideId: currentRide.id,
      sender,
      text: text.trim(),
      timestamp: Date.now(),
    };

    setChatMessages((prev) => [...prev, newMsg]);
    playSound('beep');

    // Auto-reply simulation from other party
    if (sender === 'customer') {
      setTimeout(() => {
        const repliesHi = [
          'हाँ भाई साहब, मैं रास्ते में हूँ। बस 2 मिनट में पहुँच रहा हूँ!',
          'ट्रैफिक थोड़ा धीमा है घड़ी चौक के पास, तुरंत पहुँच रहा हूँ।',
          'लोकेशन दिख रही है, मैं सफेद हेलमेट में हूँ।',
        ];
        const repliesEn = [
          'Yes sir, I am nearby and arriving in 2 minutes!',
          'Taking the Ring Road cut to reach you faster.',
          'Got your location, please wait near the main gate.',
        ];
        const chosen =
          language === 'hi'
            ? repliesHi[Math.floor(Math.random() * repliesHi.length)]
            : repliesEn[Math.floor(Math.random() * repliesEn.length)];

        setChatMessages((prev) => [
          ...prev,
          {
            id: `msg-${Date.now() + 1}`,
            rideId: currentRide.id,
            sender: 'driver',
            text: chosen,
            timestamp: Date.now(),
          },
        ]);
        playSound('beep');
      }, 1500);
    }
  };

  // SOS Emergency Trigger
  const triggerSos = () => {
    playSound('sos');
    const alert: SosAlert = {
      id: `sos-${Date.now()}`,
      rideId: currentRide?.id || 'standalone',
      customerName: customer.name,
      customerPhone: customer.phone,
      driverName: currentRide?.driver?.name,
      vehicleNumber: currentRide?.driver?.vehicleNumber,
      location: currentRide
        ? {
            lat: driverPosition.lat,
            lng: driverPosition.lng,
            name: currentRide.pickup.name,
          }
        : {
            lat: AMBIKAPUR_CENTER.lat,
            lng: AMBIKAPUR_CENTER.lng,
            name: 'Ambikapur City Center',
          },
      timestamp: Date.now(),
      status: 'active',
    };

    setSosAlerts((prev) => [alert, ...prev]);
  };

  const resolveSos = (id: string) => {
    setSosAlerts((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status: 'resolved' } : a))
    );
  };

  // Driver KYC submission
  const driverSubmitKyc = (aadhaar: string, dl: string, vehicleNo: string) => {
    setCurrentDriver((prev) => ({
      ...prev,
      aadhaarNumber: aadhaar,
      dlNumber: dl,
      vehicleNumber: vehicleNo,
      kycStatus: 'pending',
    }));
    playSound('success');
  };

  // Admin Driver Actions
  const adminApproveDriver = (driverId: string) => {
    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, kycStatus: 'verified' } : d))
    );
    if (currentDriver.id === driverId) {
      setCurrentDriver((prev) => ({ ...prev, kycStatus: 'verified' }));
    }
    playSound('success');
  };

  const adminRejectDriver = (driverId: string) => {
    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, kycStatus: 'rejected' } : d))
    );
    if (currentDriver.id === driverId) {
      setCurrentDriver((prev) => ({ ...prev, kycStatus: 'rejected' }));
    }
  };

  // Admin Fare update
  const adminUpdateFare = (category: VehicleCategory, base: number, perKm: number) => {
    setVehicleOptions((prev) =>
      prev.map((v) => (v.id === category ? { ...v, baseFare: base, perKmRate: perKm } : v))
    );
  };

  const toggleDriverOnline = () => {
    setCurrentDriver((prev) => ({
      ...prev,
      isOnline: !prev.isOnline,
    }));
    playSound('beep');
  };

  const updateCustomerProfile = (data: Partial<CustomerProfile>) => {
    setCustomer((prev) => ({ ...prev, ...data }));
  };

  const customerLogin = (phone: string, otp: string) => {
    if (phone.length >= 10 && otp.length === 4) {
      setCustomer((prev) => ({
        ...prev,
        phone,
        isLoggedIn: true,
      }));
      playSound('success');
      return true;
    }
    return false;
  };

  // Clean interval on unmount
  useEffect(() => {
    return () => {
      if (moveIntervalRef.current) {
        window.clearInterval(moveIntervalRef.current);
      }
    };
  }, []);

  return (
    <RideContext.Provider
      value={{
        language,
        setLanguage,
        t,
        activeRole,
        setActiveRole,
        isDevicePreview,
        setIsDevicePreview,
        showApkModal,
        setShowApkModal,
        popularLocations: POPULAR_LOCATIONS,
        vehicleOptions,
        promoCodes: PROMO_CODES,
        draftPickup,
        draftDestination,
        setDraftPickup,
        setDraftDestination,
        customer,
        updateCustomerProfile,
        customerLogin,
        currentRide,
        rideHistory,
        requestRide,
        cancelRide,
        resetRide,
        rateRide,
        currentDriver,
        drivers,
        toggleDriverOnline,
        incomingRideRequest,
        driverAcceptRide,
        driverRejectRide,
        driverArrivedAtPickup,
        driverStartRide,
        driverCompleteRide,
        driverSubmitKyc,
        driverPosition,
        chatMessages,
        sendChatMessage,
        sosAlerts,
        triggerSos,
        resolveSos,
        adminStats,
        adminApproveDriver,
        adminRejectDriver,
        adminUpdateFare,
      }}
    >
      {children}
    </RideContext.Provider>
  );
};

export const useRide = () => {
  const context = useContext(RideContext);
  if (!context) {
    throw new Error('useRide must be used within a RideProvider');
  }
  return context;
};
