export type VehicleCategory = 'bike' | 'auto' | 'mini' | 'sedan';

export type RideStatus = 
  | 'IDLE'
  | 'SEARCHING'
  | 'ACCEPTED'
  | 'ARRIVING'
  | 'ARRIVED'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'CANCELLED';

export type LocationCategory = 
  | 'transit'
  | 'hospital'
  | 'commercial'
  | 'landmark'
  | 'residential'
  | 'petrol'
  | 'bank'
  | 'school'
  | 'temple'
  | 'mohalla'
  | 'village'
  | 'police'
  | 'hotel'
  | 'pharmacy'
  | 'govt';

export interface SavedPlace {
  id: string;
  type: 'home' | 'work' | 'favorite';
  title: string;
  titleHi: string;
  location: LocationPoint;
}

export interface LocationPoint {
  id: string;
  name: string;
  nameHi: string;
  address: string;
  addressHi: string;
  lat: number;
  lng: number;
  category: LocationCategory;
  colony?: string;
  landmarkNear?: string;
}

export interface TurnInstruction {
  stepIndex: number;
  instruction: string;
  instructionHi: string;
  distanceMeters: number;
  maneuver: 'straight' | 'turn-left' | 'turn-right' | 'roundabout' | 'uturn' | 'arrive';
  coordinate: [number, number];
  roadName: string;
}

export interface RouteOption {
  id: string;
  name: string;
  nameHi: string;
  viaRoad: string;
  viaRoadHi: string;
  distanceKm: number;
  durationMinutes: number;
  trafficLevel: 'smooth' | 'moderate' | 'heavy';
  isRecommended: boolean;
  polyline: [number, number][];
  turnInstructions: TurnInstruction[];
}

export interface VehicleOption {
  id: VehicleCategory;
  name: string;
  nameHi: string;
  tagline: string;
  taglineHi: string;
  capacity: number;
  baseFare: number;
  perKmRate: number;
  minFare: number;
  icon: string;
  etaMinutes: number;
  description: string;
  descriptionHi: string;
}

export interface Driver {
  id: string;
  name: string;
  nameHi: string;
  phone: string;
  photo: string;
  rating: number;
  totalRides: number;
  vehicleCategory: VehicleCategory;
  vehicleModel: string;
  vehicleNumber: string; // e.g. CG 15 AB 4821
  color: string;
  isOnline: boolean;
  isBusy: boolean;
  lat: number;
  lng: number;
  heading: number;
  kycStatus: 'verified' | 'pending' | 'rejected';
  aadhaarNumber: string;
  dlNumber: string;
  earningsToday: number;
  totalEarnings: number;
  walletBalance: number;
}

export interface Ride {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  driverId?: string;
  driver?: Driver;
  pickup: LocationPoint;
  destination: LocationPoint;
  vehicleCategory: VehicleCategory;
  distanceKm: number;
  durationMinutes: number;
  fareAmount: number;
  baseFare: number;
  distanceFare: number;
  discountAmount: number;
  finalFare: number;
  driverCommission: number; // 15-20%
  status: RideStatus;
  startOtp: string; // 4-digit PIN for passenger safety
  createdAt: number;
  acceptedAt?: number;
  startedAt?: number;
  completedAt?: number;
  cancelledAt?: number;
  cancelReason?: string;
  paymentMethod: 'cash' | 'upi' | 'wallet';
  paymentStatus: 'pending' | 'paid';
  rating?: number;
  review?: string;
  isScheduled?: boolean;
  scheduledTime?: string;
  selectedRoute?: RouteOption;
}

export interface ChatMessage {
  id: string;
  rideId: string;
  sender: 'customer' | 'driver';
  text: string;
  timestamp: number;
}

export interface PromoCode {
  code: string;
  discountPercent: number;
  maxDiscount: number;
  minRideAmount: number;
  description: string;
  descriptionHi: string;
}

export interface SosAlert {
  id: string;
  rideId: string;
  customerName: string;
  customerPhone: string;
  driverName?: string;
  vehicleNumber?: string;
  location: { lat: number; lng: number; name: string };
  timestamp: number;
  status: 'active' | 'resolved';
}

export interface MapIssueReport {
  id: string;
  reporterName: string;
  reporterPhone: string;
  issueType: 'missing_road' | 'wrong_landmark' | 'closed_road' | 'new_colony';
  description: string;
  landmark: string;
  coordinates: { lat: number; lng: number };
  timestamp: number;
  status: 'pending' | 'approved' | 'rejected';
}

export interface AdminStats {
  totalCustomers: number;
  totalDrivers: number;
  totalRides: number;
  activeRides: number;
  cancelledRides: number;
  dailyRevenue: number;
  monthlyRevenue: number;
  platformProfit: number;
}

export type MapLayerStyle = 'streets' | 'satellite' | 'terrain' | 'night';
