/**
 * APNI RIDE - Project Files Manifest & Individual File Exporter
 * Provides raw source code and metadata for all key Android, Web, Brand and Map files
 * so users can inspect, copy, or download any file individually if ZIP downloads are blocked.
 */

export interface ProjectFile {
  id: string;
  name: string;
  path: string;
  category: 'android' | 'brand' | 'map' | 'core';
  description: string;
  size: string;
  mimeType: string;
  content: string;
}

export const PROJECT_FILES: ProjectFile[] = [
  {
    id: 'android-manifest',
    name: 'AndroidManifest.xml',
    path: 'android/app/src/main/AndroidManifest.xml',
    category: 'android',
    description: 'Complete Android Manifest with GPS, Camera, Phone Call, Notifications and Deep Linking permissions for Ambikapur.',
    size: '4.2 KB',
    mimeType: 'text/xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <!-- Location Permissions for Ambikapur GPS & Navigation -->
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_BACKGROUND_LOCATION" />

    <!-- Network & Internet Access -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />

    <!-- Driver Partner Real-Time Tracking & Emergency Dispatch -->
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />

    <!-- Phone Call & Driver Contact -->
    <uses-permission android:name="android.permission.CALL_PHONE" />

    <!-- Sound & Haptic Alerts -->
    <uses-permission android:name="android.permission.VIBRATE" />

    <!-- Push Notifications for Ride Requests & Updates -->
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <!-- Camera & Storage for Driver License / Aadhaar KYC Upload -->
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />

    <!-- Hardware Features -->
    <uses-feature android:name="android.hardware.location.gps" android:required="true" />
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-feature android:name="android.hardware.telephony" android:required="false" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/AppTheme"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/title_activity_main"
            android:theme="@style/AppTheme.NoActionBarLaunch"
            android:launchMode="singleTask"
            android:configChanges="orientation|keyboardHidden|keyboard|screenSize|locale|smallestScreenSize|screenLayout|uiMode"
            android:windowSoftInputMode="adjustResize">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <!-- Deep linking for apniride:// -->
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="apniride" />
            </intent-filter>

            <!-- Web App Universal Links -->
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="apniride.in" />
            </intent-filter>

        </activity>

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="com.apniride.ambikapur.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

    </application>

</manifest>`,
  },
  {
    id: 'main-activity',
    name: 'MainActivity.java',
    path: 'android/app/src/main/java/com/apniride/ambikapur/MainActivity.java',
    category: 'android',
    description: 'Native Java Android Activity with HTML5 GPS bridge, WebView hardware acceleration, and KYC file chooser.',
    size: '6.8 KB',
    mimeType: 'text/x-java-source',
    content: `package com.apniride.ambikapur;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * APNI RIDE - Native Android Production Wrapper
 * Launches Customer App, Driver Partner Interface, and Admin Command Center
 */
public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ProgressBar progressBar;
    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final int FILE_CHOOSER_REQUEST_CODE = 2001;
    private ValueCallback<Uri[]> uploadMessageAboveL;

    private static final String APP_URL = "file:///android_asset/index.html";
    private static final String FALLBACK_URL = "https://apniride.in";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);

        checkAndRequestPermissions();
        setupWebView();
        loadApp();
    }

    private void checkAndRequestPermissions() {
        String[] permissions = new String[]{
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.CALL_PHONE
        };

        boolean needPrompt = false;
        for (String p : permissions) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needPrompt = true;
                break;
            }
        }

        if (needPrompt) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();

                if ("tel".equals(scheme) || "mailto".equals(scheme) || "sms".equals(scheme) || "whatsapp".equals(scheme)) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (progressBar != null) progressBar.setVisibility(View.GONE);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, true);
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (progressBar != null) {
                    progressBar.setProgress(newProgress);
                    if (newProgress >= 100) {
                        progressBar.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (uploadMessageAboveL != null) {
                    uploadMessageAboveL.onReceiveValue(null);
                }
                uploadMessageAboveL = filePathCallback;

                Intent intent = fileChooserParams.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    uploadMessageAboveL = null;
                    Toast.makeText(MainActivity.this, "Cannot open file chooser", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });
    }

    private void loadApp() {
        webView.loadUrl(APP_URL);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (webView != null) {
                    webView.reload();
                }
            }
        }
    }
}`,
  },
  {
    id: 'build-gradle-app',
    name: 'app/build.gradle',
    path: 'android/app/build.gradle',
    category: 'android',
    description: 'Gradle App module configuration with compileSdk 34, namespace com.apniride.ambikapur, and Google Play services.',
    size: '1.8 KB',
    mimeType: 'text/plain',
    content: `apply plugin: 'com.android.application'

android {
    namespace "com.apniride.ambikapur"
    compileSdk 34

    defaultConfig {
        applicationId "com.apniride.ambikapur"
        minSdk 23
        targetSdk 34
        versionCode 100
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true

        manifestPlaceholders = [
            appName: "APNI RIDE",
            appScheme: "apniride"
        ]
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.debug
        }
        debug {
            applicationIdSuffix ".debug"
            debuggable true
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
}

dependencies {
    implementation fileTree(dir: 'libs', include: ['*.jar'])
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'androidx.coordinatorlayout:coordinatorlayout:1.2.0'
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.activity:activity:1.8.2'
    implementation 'androidx.webkit:webkit:1.10.0'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'com.google.android.gms:play-services-location:21.1.0'

    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
}`,
  },
  {
    id: 'capacitor-config',
    name: 'capacitor.config.json',
    path: 'capacitor.config.json',
    category: 'android',
    description: 'Capacitor cross-platform configuration file for compiling directly into native Android Studio project.',
    size: '0.4 KB',
    mimeType: 'application/json',
    content: `{
  "appId": "com.apniride.ambikapur",
  "appName": "APNI RIDE",
  "webDir": "dist",
  "bundledWebRuntime": false,
  "server": {
    "androidScheme": "https",
    "cleartext": true
  },
  "plugins": {
    "SplashScreen": {
      "launchShowDuration": 2000,
      "backgroundColor": "#0a1931",
      "showSpinner": true,
      "spinnerColor": "#facc15"
    },
    "Geolocation": {
      "requestPermissions": true
    }
  }
}`,
  },
  {
    id: 'package-json',
    name: 'package.json',
    path: 'package.json',
    category: 'core',
    description: 'Node.js and React project configuration with dependencies for Leaflet, Lucide icons, Motion, and Tailwind CSS.',
    size: '1.1 KB',
    mimeType: 'application/json',
    content: `{
  "name": "apni-ride-ambikapur",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --port=3000 --host=0.0.0.0",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "tsc --noEmit"
  },
  "dependencies": {
    "@google/genai": "^2.4.0",
    "@tailwindcss/vite": "^4.3.3",
    "@types/canvas-confetti": "^1.9.0",
    "@types/leaflet": "^1.9.22",
    "@vitejs/plugin-react": "^6.1.1",
    "canvas-confetti": "^1.9.4",
    "dotenv": "^17.2.3",
    "express": "^4.21.2",
    "leaflet": "^1.9.4",
    "lucide-react": "^0.546.0",
    "motion": "^12.23.24",
    "react": "^19.0.1",
    "react-dom": "^19.0.1",
    "vite": "^8.3.0"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^22.14.0",
    "@types/react": "^19.3.0",
    "@types/react-dom": "^19.3.0",
    "autoprefixer": "^10.4.21",
    "esbuild": "^0.25.0",
    "tailwindcss": "^4.3.3",
    "tsx": "^4.21.0",
    "typescript": "^7.0.2",
    "vite-plugin-pwa": "^2.0.0"
  }
}`,
  },
  {
    id: 'readme-md',
    name: 'README.md',
    path: 'README.md',
    category: 'core',
    description: 'Complete documentation and step-by-step instructions for Android Studio compilation, APK release, and local run.',
    size: '7.9 KB',
    mimeType: 'text/markdown',
    content: `# 🚖 APNI RIDE (अपनी राइड) – Complete Android & Web Mobility Platform
> **Tagline:** *"Aapki Ride, Aapka Safar"* (आपकी राइड, आपका सफर)  
> **Launch City:** Ambikapur, Chhattisgarh, India (RTO Code: CG-15)  
> **App Types:** Bike Taxi, Auto Rickshaw, and Car/Cab Booking Platform  
> **Package ID:** \`com.apniride.ambikapur\`  
> **Target SDK:** Android 14 (API Level 34)

## How to Build the Android APK in Android Studio:
1. Run \`npm install\` and \`npm run build\` to generate production web assets.
2. Open the \`android/\` folder inside Android Studio.
3. Allow Gradle to sync.
4. Click Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is ready at: \`android/app/build/outputs/apk/debug/app-debug.apk\`.
6. To generate a signed release APK or Google Play Store AAB bundle, click Build > Generate Signed Bundle / APK.`,
  },
  {
    id: 'logo-main',
    name: 'logo-main.svg',
    path: 'public/logo-main.svg',
    category: 'brand',
    description: 'Master Brand Logo with velocity emblem, APNI RIDE bold typography, CG-15 launch city badge, and bilingual tagline.',
    size: '3.6 KB',
    mimeType: 'image/svg+xml',
    content: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 240" width="100%" height="100%">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0a1931"/>
      <stop offset="60%" stop-color="#0c234a"/>
      <stop offset="100%" stop-color="#050d1a"/>
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffe156"/>
      <stop offset="50%" stop-color="#facc15"/>
      <stop offset="100%" stop-color="#eab308"/>
    </linearGradient>
    <linearGradient id="blueGlow" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8"/>
      <stop offset="100%" stop-color="#2563eb"/>
    </linearGradient>
    <filter id="shadow" x="-10%" y="-10%" width="130%" height="130%">
      <feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="#000" flood-opacity="0.5"/>
    </filter>
  </defs>
  <rect width="700" height="240" rx="24" fill="url(#bgGrad)"/>
  <rect x="2" y="2" width="696" height="236" rx="22" fill="none" stroke="#2563eb" stroke-opacity="0.3" stroke-width="2"/>
  <g transform="translate(45, 30)" filter="url(#shadow)">
    <path d="M 90 10 C 130 10, 165 42, 165 82 C 165 125, 90 170, 90 170 C 90 170, 15 125, 15 82 C 15 42, 50 10, 90 10 Z" fill="#0f2b59" stroke="#1e3a8a" stroke-width="3"/>
    <path d="M 60 160 L 90 25 L 120 160" stroke="#0a1931" stroke-width="32" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 60 160 L 90 25 L 120 160" stroke="#2563eb" stroke-width="24" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 70 160 L 90 55 L 110 160" stroke="#1d4ed8" stroke-width="14" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 90 55 L 90 160" stroke="#ffffff" stroke-width="4" stroke-dasharray="10 8" stroke-linecap="round"/>
    <path d="M 52 110 L 128 110" stroke="url(#goldGrad)" stroke-width="12" stroke-linecap="round"/>
    <polygon points="120,102 136,110 120,118" fill="#ffe156"/>
    <circle cx="90" cy="55" r="14" fill="url(#goldGrad)" stroke="#ffffff" stroke-width="3"/>
    <circle cx="90" cy="55" r="5" fill="#0a1931"/>
    <g transform="translate(130, 40)" opacity="0.9">
      <path d="M 2 14 C 4 8, 14 6, 20 6 C 26 6, 34 10, 36 14 C 34 16, 24 18, 2 14 Z" fill="url(#goldGrad)"/>
      <circle cx="8" cy="18" r="4" fill="#0a1931" stroke="#facc15" stroke-width="1.5"/>
      <circle cx="28" cy="18" r="4" fill="#0a1931" stroke="#facc15" stroke-width="1.5"/>
    </g>
  </g>
  <g transform="translate(235, 45)">
    <text x="0" y="70" font-family="system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif" font-weight="900" font-size="64" letter-spacing="3" fill="#ffffff">
      APNI
      <tspan dx="15" fill="url(#goldGrad)">RIDE</tspan>
    </text>
    <g transform="translate(370, 22)">
      <rect x="0" y="0" width="76" height="26" rx="6" fill="#1e3a8a" stroke="#3b82f6" stroke-width="1.5"/>
      <text x="38" y="18" font-family="system-ui, sans-serif" font-size="12" font-weight="800" fill="#93c5fd" text-anchor="middle" letter-spacing="1">CG-15</text>
    </g>
    <g transform="translate(0, 92)">
      <text x="0" y="16" font-family="system-ui, sans-serif" font-size="14" font-weight="700" fill="#94a3b8" letter-spacing="2">
        AAPKI RIDE, AAPKA SAFAR
        <tspan fill="#64748b" dx="8">•</tspan>
        <tspan fill="#facc15" dx="8">आपकी राइड, आपका सफर</tspan>
      </text>
    </g>
    <g transform="translate(0, 126)">
      <g transform="translate(0, 0)">
        <rect x="0" y="0" width="85" height="24" rx="12" fill="#1e293b" stroke="#334155" stroke-width="1"/>
        <text x="42.5" y="16" font-family="system-ui, sans-serif" font-size="11" font-weight="700" fill="#e2e8f0" text-anchor="middle">BIKE TAXI</text>
      </g>
      <g transform="translate(95, 0)">
        <rect x="0" y="0" width="110" height="24" rx="12" fill="#1e293b" stroke="#eab308" stroke-width="1"/>
        <text x="55" y="16" font-family="system-ui, sans-serif" font-size="11" font-weight="700" fill="#facc15" text-anchor="middle">AUTO RICKSHAW</text>
      </g>
      <g transform="translate(215, 0)">
        <rect x="0" y="0" width="80" height="24" rx="12" fill="#1e293b" stroke="#334155" stroke-width="1"/>
        <text x="40" y="16" font-family="system-ui, sans-serif" font-size="11" font-weight="700" fill="#e2e8f0" text-anchor="middle">CAR CAB</text>
      </g>
      <g transform="translate(305, 0)">
        <rect x="0" y="0" width="105" height="24" rx="12" fill="#0f172a" stroke="#2563eb" stroke-width="1"/>
        <circle cx="12" cy="12" r="4" fill="#22c55e"/>
        <text x="58" y="16" font-family="system-ui, sans-serif" font-size="11" font-weight="700" fill="#38bdf8" text-anchor="middle">AMBIKAPUR</text>
      </g>
    </g>
  </g>
</svg>`,
  },
  {
    id: 'icon-svg',
    name: 'icon.svg',
    path: 'public/icon.svg',
    category: 'brand',
    description: 'Android Squircle Application Launcher Icon (512x512) for Android phone home screen & Google Play.',
    size: '2.5 KB',
    mimeType: 'image/svg+xml',
    content: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="100%" height="100%">
  <defs>
    <linearGradient id="appBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#071224"/>
      <stop offset="50%" stop-color="#0a1931"/>
      <stop offset="100%" stop-color="#030812"/>
    </linearGradient>
    <linearGradient id="appGold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffe156"/>
      <stop offset="50%" stop-color="#facc15"/>
      <stop offset="100%" stop-color="#eab308"/>
    </linearGradient>
    <filter id="appShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="16" flood-color="#000" flood-opacity="0.6"/>
      <feDropShadow dx="0" dy="4" stdDeviation="8" flood-color="#2563eb" flood-opacity="0.4"/>
    </filter>
  </defs>
  <rect width="512" height="512" rx="115" fill="url(#appBg)"/>
  <rect x="6" y="6" width="500" height="500" rx="110" fill="none" stroke="#2563eb" stroke-opacity="0.35" stroke-width="4"/>
  <g transform="translate(106, 60)" filter="url(#appShadow)">
    <path d="M 150 15 C 225 15, 285 75, 285 150 C 285 230, 150 315, 150 315 C 150 315, 15 230, 15 150 C 15 75, 75 15, 150 15 Z" fill="#0d2449" stroke="#1d4ed8" stroke-width="6"/>
    <path d="M 95 300 L 150 45 L 205 300" stroke="#050c18" stroke-width="56" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 95 300 L 150 45 L 205 300" stroke="#2563eb" stroke-width="42" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 112 300 L 150 95 L 188 300" stroke="#1d4ed8" stroke-width="24" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 150 95 L 150 300" stroke="#ffffff" stroke-width="6" stroke-dasharray="16 12" stroke-linecap="round"/>
    <path d="M 80 205 L 220 205" stroke="url(#appGold)" stroke-width="22" stroke-linecap="round"/>
    <polygon points="205,190 235,205 205,220" fill="#ffe156"/>
    <circle cx="150" cy="95" r="24" fill="url(#appGold)" stroke="#ffffff" stroke-width="5"/>
    <circle cx="150" cy="95" r="9" fill="#0a1931"/>
  </g>
  <text x="256" y="445" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="44" letter-spacing="4" fill="#ffffff" text-anchor="middle">
    APNI <tspan fill="url(#appGold)">RIDE</tspan>
  </text>
  <text x="256" y="480" font-family="system-ui, sans-serif" font-weight="700" font-size="14" letter-spacing="3" fill="#60a5fa" text-anchor="middle">
    AMBIKAPUR • CG-15
  </text>
</svg>`,
  },
  {
    id: 'logo-transparent',
    name: 'logo-transparent.svg',
    path: 'public/logo-transparent.svg',
    category: 'brand',
    description: 'Transparent background brand mark suitable for overlays, navigation headers, and custom backgrounds.',
    size: '2.8 KB',
    mimeType: 'image/svg+xml',
    content: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 760 200" width="100%" height="100%">
  <defs>
    <linearGradient id="transGold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffe156"/>
      <stop offset="50%" stop-color="#facc15"/>
      <stop offset="100%" stop-color="#eab308"/>
    </linearGradient>
    <linearGradient id="transBlue" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8"/>
      <stop offset="100%" stop-color="#2563eb"/>
    </linearGradient>
  </defs>
  <g transform="translate(30, 20)">
    <path d="M 80 10 C 118 10, 150 40, 150 78 C 150 118, 80 160, 80 160 C 80 160, 10 118, 10 78 C 10 40, 42 10, 80 10 Z" fill="#0f2b59" stroke="#2563eb" stroke-width="3"/>
    <path d="M 52 150 L 80 25 L 108 150" stroke="#0a1931" stroke-width="28" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 52 150 L 80 25 L 108 150" stroke="#2563eb" stroke-width="20" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M 80 50 L 80 150" stroke="#ffffff" stroke-width="3.5" stroke-dasharray="8 6" stroke-linecap="round"/>
    <path d="M 45 105 L 115 105" stroke="url(#transGold)" stroke-width="10" stroke-linecap="round"/>
    <polygon points="108,98 122,105 108,112" fill="#ffe156"/>
    <circle cx="80" cy="50" r="12" fill="url(#transGold)" stroke="#ffffff" stroke-width="2.5"/>
    <circle cx="80" cy="50" r="4" fill="#0a1931"/>
  </g>
  <g transform="translate(210, 40)">
    <text x="0" y="65" font-family="system-ui, -apple-system, sans-serif" font-weight="900" font-size="64" letter-spacing="3" fill="#ffffff">
      APNI <tspan fill="url(#transGold)">RIDE</tspan>
    </text>
    <rect x="360" y="20" width="70" height="24" rx="6" fill="#1e3a8a" stroke="#3b82f6" stroke-width="1.2"/>
    <text x="395" y="36" font-family="system-ui, sans-serif" font-size="11" font-weight="800" fill="#93c5fd" text-anchor="middle">CG-15</text>
    <text x="0" y="105" font-family="system-ui, sans-serif" font-size="14" font-weight="700" fill="#94a3b8" letter-spacing="2">
      AAPKI RIDE, AAPKA SAFAR • <tspan fill="#facc15">आपकी राइड, आपका सफर</tspan>
    </text>
  </g>
</svg>`,
  },
  {
    id: 'ambikapur-locations',
    name: 'ambikapurLocations.ts',
    path: 'src/data/ambikapurLocations.ts',
    category: 'map',
    description: 'Complete database of Ambikapur colonies, mohallas, landmarks, schools, colleges, hospitals, and transit hubs with GPS coordinates.',
    size: '12.4 KB',
    mimeType: 'text/typescript',
    content: `export interface AmbikapurLocation {
  id: string;
  name: string;
  hindiName: string;
  category: 'colony' | 'mohalla' | 'market' | 'hospital' | 'education' | 'transit' | 'landmark' | 'religious' | 'village';
  lat: number;
  lng: number;
  address: string;
  landmark?: string;
  popular?: boolean;
}

export const AMBIKAPUR_CENTER = {
  lat: 23.1205,
  lng: 83.1979,
  zoom: 14,
  cityName: 'Ambikapur',
  district: 'Surguja',
  state: 'Chhattisgarh',
  pinCode: '497001',
};

// 45+ Mapped Localities across Ambikapur, Surguja
export const AMBIKAPUR_LOCATIONS: AmbikapurLocation[] = [
  {
    id: 'loc_ghadi_chowk',
    name: 'Ghadi Chowk',
    hindiName: 'घड़ी चौक',
    category: 'landmark',
    lat: 23.1205,
    lng: 83.1979,
    address: 'Central Circle, MG Road, Ambikapur',
    landmark: 'Iconic Clock Tower',
    popular: true,
  },
  {
    id: 'loc_bus_stand',
    name: 'Pratappur New Bus Stand',
    hindiName: 'प्रतापपुर नया बस स्टैंड',
    category: 'transit',
    lat: 23.1310,
    lng: 83.1895,
    address: 'Pratappur Road, Ambikapur',
    landmark: 'Intercity Bus Terminal',
    popular: true,
  },
  {
    id: 'loc_railway_station',
    name: 'Ambikapur Railway Station',
    hindiName: 'अम्बिकापुर रेलवे स्टेशन',
    category: 'transit',
    lat: 23.0955,
    lng: 83.2120,
    address: 'Station Road, Ambikapur (ABKP)',
    landmark: 'South East Central Railway',
    popular: true,
  },
  {
    id: 'loc_medical_college',
    name: 'Government Medical College Hospital',
    hindiName: 'शासकीय मेडिकल कॉलेज अस्पताल',
    category: 'hospital',
    lat: 23.1165,
    lng: 83.1880,
    address: 'Hospital Road, Ambikapur',
    landmark: 'District Hospital Complex',
    popular: true,
  },
  {
    id: 'loc_gandhi_chowk',
    name: 'Gandhi Chowk',
    hindiName: 'गांधी चौक',
    category: 'landmark',
    lat: 23.1235,
    lng: 83.1945,
    address: 'Main Market Road, Ambikapur',
    popular: true,
  },
  {
    id: 'loc_bramhroad',
    name: 'Bramh Road Market',
    hindiName: 'ब्रह्म रोड बाजार',
    category: 'market',
    lat: 23.1220,
    lng: 83.1990,
    address: 'Bramh Road, Central Ambikapur',
    popular: true,
  },
  {
    id: 'loc_kedar_pur',
    name: 'Kedarpur Colony',
    hindiName: 'केदारपुर कॉलोनी',
    category: 'colony',
    lat: 23.1110,
    lng: 83.2050,
    address: 'Kedarpur, Ambikapur',
    popular: true,
  },
  {
    id: 'loc_manipur',
    name: 'Manipur Mohalla',
    hindiName: 'मणिपुर मोहल्ला',
    category: 'mohalla',
    lat: 23.1290,
    lng: 83.2070,
    address: 'Manipur Police Station Road, Ambikapur',
    popular: true,
  },
  {
    id: 'loc_gandhinagar',
    name: 'Gandhinagar Residential Area',
    hindiName: 'गांधीनगर',
    category: 'colony',
    lat: 23.1380,
    lng: 83.1950,
    address: 'Gandhinagar, Ambikapur',
    popular: true,
  },
  {
    id: 'loc_mahamaya_temple',
    name: 'Mahamaya Mandir',
    hindiName: 'महामाया मंदिर',
    category: 'religious',
    lat: 23.1130,
    lng: 83.2200,
    address: 'Mahamaya Mandir Road, Ambikapur',
    popular: true,
  },
];`,
  },
];

/**
 * Downloads a string file directly to the user's browser with the specified filename and MIME type.
 */
export function downloadProjectFile(file: ProjectFile) {
  const blob = new Blob([file.content], { type: file.mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = file.name;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
