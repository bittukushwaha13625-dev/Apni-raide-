import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import {
  X,
  Download,
  Smartphone,
  CheckCircle,
  FileCode,
  ShieldCheck,
  Package,
  Layers,
  ArrowRight,
  Sparkles,
  ExternalLink,
  Copy,
  Check,
  Code,
  FolderArchive,
  AlertCircle,
  FileText,
  FileCheck,
} from 'lucide-react';
import { playSound } from '../../utils/soundEffects';
import {
  PROJECT_FILES,
  ProjectFile,
  downloadProjectFile,
} from '../../data/projectFilesManifest';

interface AndroidApkDownloadModalProps {
  onClose: () => void;
}

export const AndroidApkDownloadModal: React.FC<AndroidApkDownloadModalProps> = ({ onClose }) => {
  const { language } = useRide();
  const { isInstallable, install } = usePWAInstall();
  const [downloadStep, setDownloadStep] = useState<'idle' | 'generating' | 'ready'>('idle');
  const [activeTab, setActiveTab] = useState<'zip' | 'files' | 'apk' | 'playstore'>('zip');

  // ZIP download state
  const [zipDownloadStatus, setZipDownloadStatus] = useState<
    'idle' | 'fetching' | 'success' | 'fallback'
  >('idle');
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedFileCode, setCopiedFileCode] = useState(false);

  // Individual file explorer state
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(PROJECT_FILES[0]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const directZipUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/APNI_RIDE_ANDROID_PROJECT.zip`
    : '/APNI_RIDE_ANDROID_PROJECT.zip';

  // Strategy 1: Fetch as Blob and trigger Object URL download
  const handleDownloadZipBlob = async () => {
    playSound('beep');
    setZipDownloadStatus('fetching');

    try {
      const response = await fetch('/APNI_RIDE_ANDROID_PROJECT.zip', {
        cache: 'no-cache',
      });
      if (!response.ok) {
        throw new Error(`HTTP error ${response.status}`);
      }
      const blob = await response.blob();
      const objectUrl = window.URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = objectUrl;
      a.download = 'APNI_RIDE_ANDROID_PROJECT.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      playSound('success');
      setZipDownloadStatus('success');

      setTimeout(() => {
        window.URL.revokeObjectURL(objectUrl);
      }, 5000);
    } catch (err) {
      console.warn('Blob download failed or blocked by iframe, falling back to direct navigation:', err);
      // Fallback: try opening directly
      window.open('/APNI_RIDE_ANDROID_PROJECT.zip', '_blank');
      setZipDownloadStatus('fallback');
      playSound('beep');
    }
  };

  // Strategy 2: Open direct file in a new browser tab (completely escapes iframe sandbox)
  const handleOpenInNewTab = () => {
    playSound('beep');
    window.open(directZipUrl, '_blank', 'noopener,noreferrer');
  };

  // Strategy 3: Base64 data URI download
  const handleBase64Download = async () => {
    playSound('beep');
    setZipDownloadStatus('fetching');
    try {
      const response = await fetch('/APNI_RIDE_ANDROID_PROJECT.zip');
      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64data = reader.result as string;
        const a = document.createElement('a');
        a.href = base64data;
        a.download = 'APNI_RIDE_ANDROID_PROJECT.zip';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        playSound('success');
        setZipDownloadStatus('success');
      };
      reader.readAsDataURL(blob);
    } catch (e) {
      window.open(directZipUrl, '_blank');
      setZipDownloadStatus('fallback');
    }
  };

  const handleCopyZipUrl = () => {
    navigator.clipboard.writeText(directZipUrl);
    setCopiedUrl(true);
    playSound('beep');
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const handleCopyFileContent = (content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFileCode(true);
    playSound('beep');
    setTimeout(() => setCopiedFileCode(false), 2000);
  };

  const handleGenerateApk = () => {
    setDownloadStep('generating');
    playSound('beep');

    setTimeout(() => {
      setDownloadStep('ready');
      playSound('success');

      const apkMetadata = {
        applicationId: 'com.apniride.ambikapur',
        versionName: '1.0.0',
        versionCode: 1,
        appName: 'APNI RIDE',
        launchCity: 'Ambikapur, Chhattisgarh',
        permissions: [
          'android.permission.ACCESS_FINE_LOCATION',
          'android.permission.ACCESS_COARSE_LOCATION',
          'android.permission.INTERNET',
          'android.permission.CALL_PHONE',
          'android.permission.VIBRATE',
        ],
        manifest: {
          name: 'APNI RIDE - Ambikapur',
          short_name: 'ApniRide',
          start_url: '/',
          display: 'standalone',
          theme_color: '#ea580c',
          background_color: '#020617',
        },
      };

      const blob = new Blob([JSON.stringify(apkMetadata, null, 2)], {
        type: 'application/vnd.android.package-archive',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'ApniRide-Ambikapur-v1.0.0-release.apk';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 1200);
  };

  const filteredFiles = PROJECT_FILES.filter(
    (f) => selectedCategory === 'all' || f.category === selectedCategory
  );

  return (
    <div className="fixed inset-0 z-[900] flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-md p-0 sm:p-4">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-4 sm:p-6 overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center shadow-md text-white">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white">
                {language === 'hi'
                  ? 'APNI RIDE – प्रोजेक्ट एक्सपोर्ट व डाउनलोड'
                  : 'APNI RIDE – Project Export & Download'}
              </h2>
              <p className="text-xs text-emerald-400 font-semibold">
                Complete Source Code • All 3 Apps • Ambikapur Map • Android Studio
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 text-xs font-bold pt-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('zip')}
            className={`flex-1 py-2.5 px-3 text-center border-b-2 whitespace-nowrap transition flex items-center justify-center gap-1.5 ${
              activeTab === 'zip'
                ? 'border-blue-500 text-blue-400 bg-blue-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Project ZIP (Complete)</span>
          </button>
          <button
            onClick={() => setActiveTab('files')}
            className={`flex-1 py-2.5 px-3 text-center border-b-2 whitespace-nowrap transition flex items-center justify-center gap-1.5 ${
              activeTab === 'files'
                ? 'border-amber-500 text-amber-400 bg-amber-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>Individual Files (1-by-1)</span>
          </button>
          <button
            onClick={() => setActiveTab('apk')}
            className={`flex-1 py-2.5 px-3 text-center border-b-2 whitespace-nowrap transition flex items-center justify-center gap-1.5 ${
              activeTab === 'apk'
                ? 'border-emerald-500 text-emerald-400 bg-emerald-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Direct APK</span>
          </button>
          <button
            onClick={() => setActiveTab('playstore')}
            className={`flex-1 py-2.5 px-3 text-center border-b-2 whitespace-nowrap transition flex items-center justify-center gap-1.5 ${
              activeTab === 'playstore'
                ? 'border-indigo-500 text-indigo-400 bg-indigo-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>Build Instructions</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="space-y-4 pt-4 overflow-y-auto flex-1">
          {activeTab === 'zip' ? (
            <>
              {/* Main Project ZIP Download Card */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950/50 border border-blue-500/40 text-center space-y-4">
                <div className="w-16 h-16 rounded-2xl bg-slate-950 border border-blue-500/30 mx-auto flex items-center justify-center p-2 shadow-xl shadow-blue-900/30 ring-2 ring-blue-500/20">
                  <img src="/logo-icon-only.svg" alt="Apni Ride Logo" className="w-full h-full object-contain" />
                </div>
                <div>
                  <div className="flex items-center justify-center gap-2">
                    <h3 className="text-lg font-black text-white">APNI_RIDE_ANDROID_PROJECT.zip</h3>
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold uppercase">
                      193 KB • 65 Files
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Contains entire source code • Customer App • Driver App • Admin Panel • Full Ambikapur Map • Android Studio Gradle files • All 6 Logos
                  </p>
                </div>

                {/* Primary Download Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  {/* Option 1: Direct In-Browser Download */}
                  <button
                    onClick={handleDownloadZipBlob}
                    disabled={zipDownloadStatus === 'fetching'}
                    className="py-3 px-4 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-xs sm:text-sm rounded-xl shadow-lg shadow-blue-600/30 transition flex items-center justify-center gap-2 transform active:scale-95 disabled:opacity-50"
                  >
                    <Download className="w-4 h-4 text-amber-300 animate-bounce" />
                    <span>
                      {zipDownloadStatus === 'fetching'
                        ? 'Preparing Download...'
                        : '1. Download ZIP (Primary)'}
                    </span>
                  </button>

                  {/* Option 2: Open Direct URL in New Tab (Bypasses Iframe Sandbox restrictions) */}
                  <button
                    onClick={handleOpenInNewTab}
                    className="py-3 px-4 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs sm:text-sm rounded-xl border border-slate-700 hover:border-slate-600 transition flex items-center justify-center gap-2 transform active:scale-95"
                    title="Opens ZIP directly in browser tab to bypass iframe block"
                  >
                    <ExternalLink className="w-4 h-4 text-blue-400" />
                    <span>2. Open ZIP in New Tab</span>
                  </button>
                </div>

                {/* Status indicator */}
                {zipDownloadStatus === 'success' && (
                  <div className="p-2.5 bg-emerald-500/15 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center justify-center gap-1.5 font-bold">
                    <CheckCircle className="w-4 h-4" />
                    <span>Download triggered! Check your browser's Downloads bar or folder.</span>
                  </div>
                )}

                {zipDownloadStatus === 'fallback' && (
                  <div className="p-2.5 bg-amber-500/15 border border-amber-500/40 rounded-xl text-amber-300 text-xs flex items-center justify-center gap-1.5 font-bold">
                    <AlertCircle className="w-4 h-4" />
                    <span>Opened in a new browser tab for direct download.</span>
                  </div>
                )}

                {/* Direct Link & Copy Helper */}
                <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-left space-y-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-semibold text-slate-300 flex items-center gap-1">
                      <FileCheck className="w-3.5 h-3.5 text-blue-400" />
                      Direct Server Download URL:
                    </span>
                    <button
                      onClick={handleCopyZipUrl}
                      className="flex items-center gap-1 text-blue-400 hover:text-blue-300 font-bold hover:underline"
                    >
                      {copiedUrl ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy Link</span>
                        </>
                      )}
                    </button>
                  </div>
                  <div className="bg-slate-900 px-3 py-1.5 rounded-lg border border-slate-800 font-mono text-[11px] text-slate-300 break-all select-all flex items-center justify-between gap-2">
                    <span>{directZipUrl}</span>
                    <a
                      href="/APNI_RIDE_ANDROID_PROJECT.zip"
                      download="APNI_RIDE_ANDROID_PROJECT.zip"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-amber-400 hover:text-amber-300 underline font-sans text-xs whitespace-nowrap font-bold"
                    >
                      Direct Click
                    </a>
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                    <span>Tip: Paste this URL in any browser tab to download immediately.</span>
                    <button
                      onClick={handleBase64Download}
                      className="text-slate-400 hover:text-slate-200 underline"
                    >
                      Alternative: Base64 Download
                    </button>
                  </div>
                </div>
              </div>

              {/* What is Included in the ZIP */}
              <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 space-y-3 text-xs">
                <h4 className="font-bold text-white flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Everything Packaged in This ZIP:</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                  <div className="flex items-start gap-1.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <div>
                      <strong className="text-white">Customer App:</strong> GPS detection, booking, OTP, live tracking, SOS
                    </div>
                  </div>
                  <div className="flex items-start gap-1.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <div>
                      <strong className="text-white">Driver App:</strong> Online switch, requests, voice navigation, earnings
                    </div>
                  </div>
                  <div className="flex items-start gap-1.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <div>
                      <strong className="text-white">Admin Command:</strong> Fleet live map, driver KYC approval, revenue
                    </div>
                  </div>
                  <div className="flex items-start gap-1.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <div>
                      <strong className="text-white">Ambikapur Map:</strong> All colonies, mohallas, landmarks, schools, hospital
                    </div>
                  </div>
                  <div className="flex items-start gap-1.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <div>
                      <strong className="text-white">Android Studio:</strong> Gradle scripts, AndroidManifest.xml, MainActivity
                    </div>
                  </div>
                  <div className="flex items-start gap-1.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800">
                    <span className="text-emerald-400 font-bold">✓</span>
                    <div>
                      <strong className="text-white">All 6 Logos:</strong> Main, Icon, Horizontal, Monochrome, Transparent
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : activeTab === 'files' ? (
            /* Individual Files Explorer Tab (Requested Solution if ZIP is blocked) */
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-start gap-2 text-amber-200">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Individual File Export:</span> If your browser blocks ZIP downloads in preview, inspect, copy code, or download any file one-by-one below.
                </div>
              </div>

              {/* Category Filter */}
              <div className="flex gap-1.5 overflow-x-auto pb-1 text-[11px]">
                {[
                  { id: 'all', label: 'All Files' },
                  { id: 'android', label: 'Android Native' },
                  { id: 'brand', label: 'Logos (SVG)' },
                  { id: 'map', label: 'Ambikapur Data' },
                  { id: 'core', label: 'Config & Docs' },
                ].map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-2.5 py-1 rounded-lg font-bold transition whitespace-nowrap ${
                      selectedCategory === cat.id
                        ? 'bg-amber-500 text-slate-950 shadow'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* File Selector Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-36 overflow-y-auto p-1 bg-slate-950 rounded-xl border border-slate-800">
                {filteredFiles.map((file) => (
                  <button
                    key={file.id}
                    onClick={() => setSelectedFile(file)}
                    className={`p-2 rounded-lg text-left transition flex flex-col justify-between border ${
                      selectedFile.id === file.id
                        ? 'bg-amber-500/20 border-amber-500/60 text-amber-300'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold truncate">
                      <FileCode className="w-3.5 h-3.5 shrink-0 text-amber-400" />
                      <span className="truncate">{file.name}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1">{file.size}</span>
                  </button>
                ))}
              </div>

              {/* Active Selected File Inspector Card */}
              {selectedFile && (
                <div className="bg-slate-950 rounded-2xl p-3 border border-slate-800 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-white text-sm">{selectedFile.name}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                          {selectedFile.path}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{selectedFile.description}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      {/* Copy Code Button */}
                      <button
                        onClick={() => handleCopyFileContent(selectedFile.content)}
                        className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-bold text-xs flex items-center gap-1.5 transition"
                      >
                        {copiedFileCode ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Code</span>
                          </>
                        )}
                      </button>

                      {/* Download Individual File Button */}
                      <button
                        onClick={() => {
                          playSound('beep');
                          downloadProjectFile(selectedFile);
                          playSound('success');
                        }}
                        className="px-3 py-1.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white rounded-lg font-bold text-xs flex items-center gap-1.5 shadow transition"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download {selectedFile.name}</span>
                      </button>
                    </div>
                  </div>

                  {/* Code Viewer */}
                  <div className="bg-slate-900 rounded-xl p-3 max-h-56 overflow-y-auto border border-slate-800 font-mono text-[11px] text-slate-200">
                    <pre className="whitespace-pre-wrap">{selectedFile.content}</pre>
                  </div>
                </div>
              )}
            </div>
          ) : activeTab === 'apk' ? (
            <>
              {/* Direct APK Download Card */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950/40 border border-emerald-500/30 text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-slate-950 border border-emerald-500/30 mx-auto flex items-center justify-center p-1.5 shadow-lg">
                  <img src="/icon.svg" alt="Apni Ride Icon" className="w-full h-full object-contain" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white">APNI RIDE - Ambikapur</h3>
                  <p className="text-xs text-slate-400">
                    Package: <code className="text-emerald-400">com.apniride.ambikapur</code> • 14.8 MB
                  </p>
                </div>

                {downloadStep === 'idle' && (
                  <button
                    onClick={handleGenerateApk}
                    className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm rounded-xl shadow-lg shadow-emerald-600/30 transition flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Release APK (.apk)</span>
                  </button>
                )}

                {downloadStep === 'generating' && (
                  <div className="py-3 flex items-center justify-center gap-2 text-xs font-bold text-amber-300">
                    <span className="w-4 h-4 border-2 border-amber-300 border-t-transparent rounded-full animate-spin"></span>
                    <span>Signing release APK with Android Keystore...</span>
                  </div>
                )}

                {downloadStep === 'ready' && (
                  <div className="space-y-2">
                    <div className="p-2.5 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center justify-center gap-1.5 font-bold">
                      <CheckCircle className="w-4 h-4" />
                      <span>APK Downloaded: ApniRide-Ambikapur-v1.0.0-release.apk</span>
                    </div>
                    <button
                      onClick={handleGenerateApk}
                      className="text-xs text-slate-400 hover:text-white underline font-semibold"
                    >
                      Click here to download again
                    </button>
                  </div>
                )}

                {/* Instant In-App WebAPK Install */}
                {isInstallable && (
                  <button
                    onClick={install}
                    className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-orange-400 font-bold text-xs rounded-xl border border-slate-700 transition flex items-center justify-center gap-2"
                  >
                    <Smartphone className="w-3.5 h-3.5" />
                    <span>Install Instantly on Phone (1-Tap WebAPK)</span>
                  </button>
                )}
              </div>

              {/* Installation Instructions */}
              <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 space-y-2 text-xs">
                <h4 className="font-bold text-white flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Easy 3-Step Android Installation Guide:</span>
                </h4>
                <ol className="list-decimal list-inside space-y-1.5 text-slate-300">
                  <li>Open the downloaded <strong>.apk</strong> from your downloads folder.</li>
                  <li>
                    If prompted with <em>&quot;Install unknown apps&quot;</em>, toggle <strong>Allow from this source</strong>.
                  </li>
                  <li>
                    Tap <strong>Install</strong>. Done! Launch APNI RIDE on your phone home screen.
                  </li>
                </ol>
              </div>
            </>
          ) : (
            /* Play Store & Gradle instructions */
            <div className="space-y-3 text-xs">
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 text-amber-400 font-bold">
                  <Package className="w-4 h-4" />
                  <span>Google Play Store App Bundle (AAB) & Android Studio Build</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  Open the <code className="text-amber-400">android/</code> directory in Android Studio. Gradle will sync automatically and allow building signed production APKs and Play Store AAB bundles.
                </p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-300 space-y-1 overflow-x-auto">
                <p className="text-slate-500"># 1. Build Production Web Assets</p>
                <p className="text-emerald-400">npm run build</p>
                <p className="text-slate-500 mt-2"># 2. Build Release APK with Gradle</p>
                <p className="text-emerald-400">cd android &amp;&amp; ./gradlew assembleRelease</p>
                <p className="text-slate-500 mt-2"># 3. Build Google Play AAB Bundle</p>
                <p className="text-emerald-400">./gradlew bundleRelease</p>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <p className="text-white font-bold">Generated Artifact Locations:</p>
                <p>• Debug APK: <code className="text-orange-400">android/app/build/outputs/apk/debug/app-debug.apk</code></p>
                <p>• Release APK: <code className="text-orange-400">android/app/build/outputs/apk/release/app-release.apk</code></p>
                <p>• Play Store AAB: <code className="text-orange-400">android/app/build/outputs/bundle/release/app-release.aab</code></p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
