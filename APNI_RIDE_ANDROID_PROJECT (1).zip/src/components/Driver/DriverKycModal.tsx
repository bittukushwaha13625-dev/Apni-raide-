import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import {
  X,
  ShieldCheck,
  FileText,
  Upload,
  CheckCircle,
  AlertCircle,
  CreditCard,
  Truck,
} from 'lucide-react';

interface DriverKycModalProps {
  onClose: () => void;
}

export const DriverKycModal: React.FC<DriverKycModalProps> = ({ onClose }) => {
  const { currentDriver, driverSubmitKyc, language } = useRide();

  const [aadhaar, setAadhaar] = useState(currentDriver.aadhaarNumber);
  const [dl, setDl] = useState(currentDriver.dlNumber);
  const [vehicleNo, setVehicleNo] = useState(currentDriver.vehicleNumber);
  const [model, setModel] = useState(currentDriver.vehicleModel);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    driverSubmitKyc(aadhaar, dl, vehicleNo);
    setIsSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[700] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 overflow-hidden flex flex-col max-h-[85vh] animate-in slide-in-from-bottom duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-600/20 text-orange-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {language === 'hi' ? 'ड्राइवर KYC व दस्तावेज सत्यापन' : 'Driver Partner KYC & Documents'}
              </h2>
              <p className="text-[11px] text-slate-400">Ambikapur RTO & Identity Compliance</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white">
              {language === 'hi' ? 'दस्तावेज जमा हो गए हैं!' : 'Documents Submitted Successfully!'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'hi'
                ? 'एडमिन द्वारा 1-2 घंटे में सत्यापन पूर्ण कर दिया जाएगा।'
                : 'Apni Ride Ambikapur admin team is reviewing your documents.'}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 pt-4 overflow-y-auto flex-1">
            {/* Status chip */}
            <div
              className={`p-3 rounded-xl border flex items-center justify-between text-xs ${
                currentDriver.kycStatus === 'verified'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-amber-500/10 border-amber-500/30 text-amber-300'
              }`}
            >
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                <span className="font-bold">
                  KYC Status: {currentDriver.kycStatus.toUpperCase()}
                </span>
              </div>
              <span className="text-[11px] opacity-80">Ambikapur Police Verified</span>
            </div>

            {/* Aadhaar */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Aadhaar Card Number (12 Digits)
              </label>
              <div className="relative">
                <CreditCard className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={aadhaar}
                  onChange={(e) => setAadhaar(e.target.value)}
                  placeholder="XXXX-XXXX-XXXX"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            {/* DL */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Driving Licence Number (Commercial / Transport)
              </label>
              <div className="relative">
                <FileText className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={dl}
                  onChange={(e) => setDl(e.target.value)}
                  placeholder="CG-15-YYYY-XXXXXXX"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            {/* Vehicle Details */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Vehicle Plate (RTO)
                </label>
                <input
                  type="text"
                  required
                  value={vehicleNo}
                  onChange={(e) => setVehicleNo(e.target.value)}
                  placeholder="CG 15 AB 4821"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white uppercase focus:outline-none focus:border-orange-500"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Model & Make
                </label>
                <input
                  type="text"
                  required
                  value={model}
                  onChange={(e) => setModel(e.target.value)}
                  placeholder="e.g. Hero Splendor"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            {/* Upload document simulated chips */}
            <div className="p-3 bg-slate-950 rounded-xl border border-dashed border-slate-700 text-center space-y-1">
              <Upload className="w-5 h-5 mx-auto text-orange-400" />
              <p className="text-xs font-bold text-white">Upload RC Book & Insurance Photo</p>
              <p className="text-[10px] text-slate-400">PNG, JPG, PDF up to 10MB (Stored securely)</p>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold text-xs rounded-xl transition shadow shadow-orange-600/30"
            >
              {language === 'hi' ? 'दस्तावेज जमा करें' : 'Submit for Verification'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
