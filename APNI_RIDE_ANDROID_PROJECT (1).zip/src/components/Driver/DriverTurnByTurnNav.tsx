import React, { useState, useEffect } from 'react';
import { useRide } from '../../context/RideContext';
import { RouteOption, TurnInstruction } from '../../types/ride';
import {
  Volume2,
  VolumeX,
  Navigation,
  ArrowRight,
  CornerUpLeft,
  CornerUpRight,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  Compass,
} from 'lucide-react';
import {
  toggleVoiceMute,
  getVoiceMutedState,
  speakNavigationInstruction,
} from '../../services/voiceNavigationService';
import { playSound } from '../../utils/soundEffects';

interface DriverTurnByTurnNavProps {
  route: RouteOption;
  onRecalculate?: () => void;
}

export const DriverTurnByTurnNav: React.FC<DriverTurnByTurnNavProps> = ({
  route,
  onRecalculate,
}) => {
  const { currentRide, language } = useRide();
  const [currentStepIdx, setCurrentStepIdx] = useState(0);
  const [isMuted, setIsMuted] = useState(getVoiceMutedState());
  const [speed, setSpeed] = useState(32);

  const instructions = route.turnInstructions || [];
  const currentStep: TurnInstruction = instructions[currentStepIdx] || instructions[0];

  // Voice announcement whenever turn instruction changes
  useEffect(() => {
    if (currentStep) {
      const textToSpeak = language === 'hi' ? currentStep.instructionHi : currentStep.instruction;
      speakNavigationInstruction(textToSpeak, language);
    }
  }, [currentStepIdx, language]);

  // Simulate progress through turn instructions as trip proceeds
  useEffect(() => {
    if (!currentRide || currentRide.status !== 'IN_PROGRESS') return;

    const interval = setInterval(() => {
      setCurrentStepIdx((prev) => {
        if (prev < instructions.length - 1) {
          playSound('beep');
          return prev + 1;
        }
        return prev;
      });

      // Realistic speed variation
      setSpeed(Math.floor(25 + Math.random() * 15));
    }, 7000);

    return () => clearInterval(interval);
  }, [currentRide, instructions.length]);

  const handleToggleVoice = () => {
    const muted = toggleVoiceMute();
    setIsMuted(muted);
    playSound('beep');
  };

  const getManeuverIcon = (maneuver: TurnInstruction['maneuver']) => {
    switch (maneuver) {
      case 'turn-left':
        return <CornerUpLeft className="w-7 h-7 text-emerald-400 stroke-[3]" />;
      case 'turn-right':
        return <CornerUpRight className="w-7 h-7 text-emerald-400 stroke-[3]" />;
      case 'roundabout':
        return <RotateCcw className="w-7 h-7 text-amber-400 stroke-[3]" />;
      case 'arrive':
        return <CheckCircle className="w-7 h-7 text-emerald-400 stroke-[3]" />;
      default:
        return <Navigation className="w-7 h-7 text-emerald-400 stroke-[3]" />;
    }
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 shadow-2xl space-y-2 text-white">
      {/* Top Banner: Turn instruction & Maneuver */}
      <div className="flex items-center justify-between gap-3 bg-gradient-to-r from-emerald-950/80 to-slate-900 p-3 rounded-xl border border-emerald-500/40">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-emerald-600/30 border border-emerald-500/50 flex items-center justify-center shrink-0">
            {getManeuverIcon(currentStep?.maneuver)}
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400">
              IN {currentStep?.distanceMeters} METERS
            </span>
            <h3 className="text-sm font-extrabold text-white leading-snug">
              {language === 'hi' ? currentStep?.instructionHi : currentStep?.instruction}
            </h3>
            <p className="text-[11px] text-slate-400 font-semibold mt-0.5">
              Road: {currentStep?.roadName}
            </p>
          </div>
        </div>

        {/* Voice Mute Button */}
        <button
          onClick={handleToggleVoice}
          aria-label={isMuted ? 'Unmute Voice Guidance' : 'Mute Voice Guidance'}
          className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 hover:text-white transition shrink-0"
          title={isMuted ? 'Unmute Voice' : 'Mute Voice'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400 animate-pulse" />}
        </button>
      </div>

      {/* Speedometer & Recalculate Row */}
      <div className="flex items-center justify-between text-xs px-1 pt-1">
        <div className="flex items-center gap-3">
          <div className="flex items-baseline gap-1">
            <span className="font-mono text-xl font-black text-white">{speed}</span>
            <span className="text-[10px] font-bold text-slate-400 uppercase">km/h</span>
          </div>
          <span className="text-slate-600">•</span>
          <span className="text-emerald-400 font-bold flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            Smooth Traffic
          </span>
        </div>

        {onRecalculate && (
          <button
            onClick={onRecalculate}
            className="flex items-center gap-1 text-[11px] font-bold text-orange-400 hover:text-orange-300 underline"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Recalculate Route</span>
          </button>
        )}
      </div>
    </div>
  );
};
