import React, { useEffect, useState } from 'react';
import { useRide } from '../../context/RideContext';
import { Bike, Navigation, MapPin, X, Check, Clock, ShieldCheck, AlertCircle } from 'lucide-react';
import { playSound } from '../../utils/soundEffects';

export const DriverIncomingRequestModal: React.FC = () => {
  const {
    incomingRideRequest,
    driverAcceptRide,
    driverRejectRide,
    language,
  } = useRide();

  const [timeLeft, setTimeLeft] = useState(15);

  useEffect(() => {
    if (!incomingRideRequest) return;
    setTimeLeft(15);
    playSound('alert');

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          driverRejectRide();
          return 0;
        }
        if (prev % 3 === 0) {
          playSound('alert');
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [incomingRideRequest]);

  if (!incomingRideRequest) return null;

  const fare = incomingRideRequest.finalFare;
  const netEarnings = fare - incomingRideRequest.driverCommission;

  return (
    <div className="fixed inset-0 z-[800] flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-md p-0 sm:p-4">
      <div className="w-full max-w-md bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-orange-500 rounded-t-3xl sm:rounded-3xl shadow-[0_0_60px_rgba(249,115,22,0.4)] p-5 overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Countdown Timer Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-orange-500 animate-ping"></span>
            <h2 className="text-base font-black text-white tracking-wide">
              {language === 'hi' ? 'नई राइड का अनुरोध!' : 'NEW RIDE REQUEST!'}
            </h2>
          </div>
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/20 text-orange-400 font-mono font-bold text-xs border border-orange-500/40">
            <Clock className="w-3.5 h-3.5" />
            <span>{timeLeft}s</span>
          </div>
        </div>

        {/* Earning & Distance Spotlight */}
        <div className="my-4 p-4 rounded-2xl bg-gradient-to-r from-emerald-600/20 via-teal-600/10 to-transparent border border-emerald-500/30 flex items-center justify-between">
          <div>
            <p className="text-[11px] text-slate-300 uppercase tracking-wider font-semibold">
              {language === 'hi' ? 'आपकी शुद्ध कमाई (कमीशन बाद)' : 'Your Net Earning'}
            </p>
            <p className="text-3xl font-black text-emerald-400">₹{netEarnings}</p>
            <p className="text-[10px] text-slate-400">Total Customer Fare: ₹{fare} (15% platform fee)</p>
          </div>
          <div className="text-right">
            <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-800 text-orange-400 border border-orange-500/30">
              {incomingRideRequest.vehicleCategory.toUpperCase()}
            </span>
            <p className="text-xs text-slate-300 font-bold mt-1">
              {incomingRideRequest.distanceKm} km trip
            </p>
          </div>
        </div>

        {/* Pickup & Destination */}
        <div className="bg-slate-950/80 rounded-2xl p-3 border border-slate-800 space-y-2 text-xs">
          <div className="flex items-start gap-2.5">
            <div className="w-3 h-3 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20 mt-1 shrink-0"></div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400">Pickup Location</p>
              <p className="font-bold text-white text-sm">
                {language === 'hi' ? incomingRideRequest.pickup.nameHi : incomingRideRequest.pickup.name}
              </p>
              <p className="text-[11px] text-slate-400">{incomingRideRequest.pickup.address}</p>
            </div>
          </div>

          <div className="border-t border-slate-800/80 pt-2 flex items-start gap-2.5">
            <div className="w-3 h-3 rounded-full bg-rose-500 ring-4 ring-rose-500/20 mt-1 shrink-0"></div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400">Drop Destination</p>
              <p className="font-bold text-white text-sm">
                {language === 'hi' ? incomingRideRequest.destination.nameHi : incomingRideRequest.destination.name}
              </p>
              <p className="text-[11px] text-slate-400">{incomingRideRequest.destination.address}</p>
            </div>
          </div>
        </div>

        {/* Passenger Info */}
        <div className="flex items-center justify-between text-xs text-slate-400 py-3 px-1">
          <span>Passenger: <strong className="text-slate-200">{incomingRideRequest.customerName}</strong></span>
          <span>Payment: <strong className="text-emerald-400 uppercase">{incomingRideRequest.paymentMethod}</strong></span>
        </div>

        {/* Accept & Reject Buttons */}
        <div className="grid grid-cols-2 gap-3 pt-1">
          <button
            onClick={driverRejectRide}
            className="py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-slate-300 font-extrabold text-sm border border-slate-700 transition flex items-center justify-center gap-1.5"
          >
            <X className="w-4 h-4" />
            <span>{language === 'hi' ? 'अस्वीकार करें' : 'Decline'}</span>
          </button>

          <button
            onClick={driverAcceptRide}
            className="py-3.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-95 text-white font-extrabold text-sm shadow-lg shadow-emerald-600/30 transition flex items-center justify-center gap-1.5"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>{language === 'hi' ? 'स्वीकार करें' : 'ACCEPT RIDE'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
