import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { DriverChatModal } from '../Customer/DriverChatModal';
import { DriverTurnByTurnNav } from './DriverTurnByTurnNav';
import {
  Navigation,
  Phone,
  MessageSquare,
  ShieldAlert,
  KeyRound,
  CheckCircle,
  Flag,
  MapPin,
  Clock,
  Sparkles,
} from 'lucide-react';
import { playSound } from '../../utils/soundEffects';

export const DriverActiveRideView: React.FC = () => {
  const {
    currentRide,
    driverArrivedAtPickup,
    driverStartRide,
    driverCompleteRide,
    language,
    triggerSos,
  } = useRide();

  const [enteredOtp, setEnteredOtp] = useState('');
  const [otpError, setOtpError] = useState('');
  const [showChat, setShowChat] = useState(false);

  if (!currentRide || currentRide.status === 'SEARCHING') return null;

  const status = currentRide.status;
  const netEarnings = currentRide.finalFare - currentRide.driverCommission;

  const handleVerifyOtp = () => {
    if (enteredOtp.length !== 4) {
      setOtpError(language === 'hi' ? '4 अंकों का कोड दर्ज करें' : 'Enter 4-digit code');
      return;
    }
    const result = driverStartRide(enteredOtp);
    if (!result.success) {
      setOtpError(result.error || 'Invalid OTP');
    } else {
      setOtpError('');
    }
  };

  // Mock route option for turn-by-turn navigation HUD
  const activeRoute = currentRide.selectedRoute || {
    id: 'active-turn-route',
    name: 'Via Ring Road Bypass',
    nameHi: 'रिंग रोड बायपास से',
    viaRoad: 'Via Ring Road & Station Approach',
    viaRoadHi: 'रिंग रोड व स्टेशन मार्ग होकर',
    distanceKm: currentRide.distanceKm,
    durationMinutes: currentRide.durationMinutes,
    trafficLevel: 'smooth',
    isRecommended: true,
    polyline: [],
    turnInstructions: [
      {
        stepIndex: 1,
        instruction: `Drive straight towards ${status === 'ARRIVING' ? currentRide.pickup.name : currentRide.destination.name}`,
        instructionHi: `${status === 'ARRIVING' ? currentRide.pickup.nameHi : currentRide.destination.nameHi} की ओर सीधे आगे बढ़ें`,
        distanceMeters: 250,
        maneuver: 'straight',
        coordinate: [currentRide.pickup.lat, currentRide.pickup.lng],
        roadName: 'Main Link Road',
      },
      {
        stepIndex: 2,
        instruction: 'Turn right onto Ambikapur Ring Road Bypass',
        instructionHi: 'अम्बिकापुर रिंग रोड बायपास पर दाएं मुड़ें',
        distanceMeters: 800,
        maneuver: 'turn-right',
        coordinate: [23.1300, 83.1950],
        roadName: 'Ring Road (NH 343)',
      },
      {
        stepIndex: 3,
        instruction: 'Continue straight through intersection',
        instructionHi: 'चौराहे से सीधे आगे बढ़ते रहें',
        distanceMeters: 600,
        maneuver: 'straight',
        coordinate: [23.1250, 83.1900],
        roadName: 'Central Highway',
      },
      {
        stepIndex: 4,
        instruction: 'Destination will be on your left',
        instructionHi: 'गंतव्य आपके बाईं ओर होगा',
        distanceMeters: 100,
        maneuver: 'arrive',
        coordinate: [currentRide.destination.lat, currentRide.destination.lng],
        roadName: currentRide.destination.name,
      },
    ],
  };

  return (
    <>
      <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl shadow-2xl p-4 md:p-5 space-y-3 max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-200">
        {/* Navigation Phase Badge */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-600/20 text-orange-400 flex items-center justify-center font-bold">
              <Navigation className="w-4 h-4 animate-spin-slow" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-bold text-slate-400">
                {language === 'hi' ? 'सक्रिय राइड नेविगेशन' : 'Active Ride Dispatch'}
              </p>
              <h3 className="text-sm font-extrabold text-white">
                {status === 'ARRIVING' && (language === 'hi' ? 'पिकअप की ओर प्रस्थान करें' : 'Drive to Pickup Point')}
                {status === 'ARRIVED' && (language === 'hi' ? 'पिकअप पर पहुंचे - OTP लें' : 'At Pickup - Ask Customer PIN')}
                {status === 'IN_PROGRESS' && (language === 'hi' ? 'गंतव्य की ओर यात्रा जारी' : 'Heading to Drop Destination')}
                {status === 'COMPLETED' && (language === 'hi' ? 'राइड संपन्न!' : 'Ride Completed!')}
              </h3>
            </div>
          </div>

          <button
            onClick={triggerSos}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-600/20 border border-rose-500/40 text-rose-400 text-xs font-bold active:scale-95 transition"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>SOS</span>
          </button>
        </div>

        {/* Turn-by-Turn Navigation HUD during Arriving and In_Progress */}
        {(status === 'ARRIVING' || status === 'IN_PROGRESS') && (
          <DriverTurnByTurnNav
            route={activeRoute}
            onRecalculate={() => {
              playSound('beep');
            }}
          />
        )}

        {/* Turn-by-turn Navigation Instruction Box */}
        <div className="bg-slate-950/80 rounded-2xl p-3 border border-slate-800 space-y-1.5 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-300">
              {status === 'ARRIVING' ? 'Target: Pickup' : 'Target: Dropoff'}
            </span>
            <span className="text-emerald-400 font-bold">
              {currentRide.distanceKm} km • Est. {currentRide.durationMinutes} min
            </span>
          </div>
          <p className="text-sm font-bold text-white flex items-center gap-1.5">
            <MapPin className="w-4 h-4 text-orange-400 shrink-0" />
            <span className="truncate">
              {status === 'ARRIVING' ? currentRide.pickup.name : currentRide.destination.name}
            </span>
          </p>
          <p className="text-[11px] text-slate-400">
            {status === 'ARRIVING' ? currentRide.pickup.address : currentRide.destination.address}
          </p>
        </div>

        {/* Passenger Info & Quick Call/Chat */}
        <div className="flex items-center justify-between bg-slate-950/50 p-3 rounded-2xl border border-slate-800">
          <div>
            <p className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>{currentRide.customerName}</span>
              <span className="text-[10px] text-emerald-400 font-medium">★ 4.9</span>
            </p>
            <p className="text-[11px] text-slate-400">
              Payment: <strong className="text-emerald-400 uppercase">{currentRide.paymentMethod}</strong> • Earn: ₹{netEarnings}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={`tel:${currentRide.customerPhone}`}
              className="w-9 h-9 rounded-xl bg-emerald-600/20 hover:bg-emerald-600 border border-emerald-500/40 text-emerald-400 hover:text-white flex items-center justify-center transition"
              title="Call Customer"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              onClick={() => setShowChat(true)}
              className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition"
              title="Chat with Customer"
            >
              <MessageSquare className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* State specific Driver Action */}
        {status === 'ARRIVING' && (
          <button
            onClick={driverArrivedAtPickup}
            className="w-full py-3.5 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 active:scale-98 text-white font-black text-sm rounded-2xl shadow-lg shadow-orange-600/30 transition flex items-center justify-center gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            <span>
              {language === 'hi' ? 'मैं पिकअप पर पहुँच गया हूँ' : 'I Have Arrived at Pickup'}
            </span>
          </button>
        )}

        {status === 'ARRIVED' && (
          <div className="bg-slate-950 rounded-2xl p-3 border border-orange-500/40 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-amber-300 flex items-center gap-1.5">
                <KeyRound className="w-4 h-4" />
                {language === 'hi' ? 'ग्राहक से 4-अंकीय OTP पूछें' : 'Enter Customer Safety PIN'}
              </span>
              <span className="text-[11px] text-slate-400">
                (Customer PIN is: {currentRide.startOtp})
              </span>
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                maxLength={4}
                value={enteredOtp}
                onChange={(e) => setEnteredOtp(e.target.value.replace(/\D/g, ''))}
                placeholder="0 0 0 0"
                className="w-32 text-center font-mono font-black text-xl tracking-widest bg-slate-900 border border-slate-700 rounded-xl px-2 py-2 text-white focus:outline-none focus:border-orange-500"
              />
              <button
                onClick={handleVerifyOtp}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-bold text-xs rounded-xl transition"
              >
                {language === 'hi' ? 'सत्यापित कर राइड शुरू करें' : 'Verify & Start Ride'}
              </button>
            </div>
            {otpError && <p className="text-rose-400 text-xs font-semibold">{otpError}</p>}
          </div>
        )}

        {status === 'IN_PROGRESS' && (
          <button
            onClick={driverCompleteRide}
            className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-98 text-white font-black text-sm rounded-2xl shadow-lg shadow-emerald-600/30 transition flex items-center justify-center gap-2"
          >
            <Flag className="w-4 h-4" />
            <span>
              {language === 'hi' ? 'राइड पूर्ण करें (पहुँच गए)' : 'Complete Ride & Collect Fare'}
            </span>
          </button>
        )}

        {status === 'COMPLETED' && (
          <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-center space-y-1">
            <p className="font-black text-emerald-400 text-sm">
              {language === 'hi' ? 'राइड सफलतापूर्वक संपन्न हुई!' : 'Ride Completed Successfully!'}
            </p>
            <p className="text-xs text-slate-300">
              ₹{netEarnings} added to your pilot wallet balance.
            </p>
          </div>
        )}
      </div>

      {showChat && <DriverChatModal onClose={() => setShowChat(false)} />}
    </>
  );
};
