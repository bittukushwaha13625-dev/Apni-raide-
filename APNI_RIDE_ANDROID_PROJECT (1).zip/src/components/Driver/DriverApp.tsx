import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { LiveRideMap } from '../Map/LiveRideMap';
import { DriverIncomingRequestModal } from './DriverIncomingRequestModal';
import { DriverActiveRideView } from './DriverActiveRideView';
import { DriverKycModal } from './DriverKycModal';
import { DriverEarningsView } from './DriverEarningsView';
import {
  Power,
  Wallet,
  ShieldCheck,
  Star,
  Clock,
  Navigation,
  Car,
  Bike,
  Sparkles,
} from 'lucide-react';

export const DriverApp: React.FC = () => {
  const {
    currentDriver,
    toggleDriverOnline,
    currentRide,
    incomingRideRequest,
    language,
  } = useRide();

  const [showKyc, setShowKyc] = useState(false);
  const [showEarnings, setShowEarnings] = useState(false);

  const isRideActive = currentRide && currentRide.status !== 'SEARCHING';

  return (
    <div className="relative h-full flex flex-col bg-slate-950 overflow-hidden">
      {/* Driver Floating Top Bar */}
      <div className="absolute top-3 left-3 right-3 z-30 flex items-center justify-between pointer-events-none">
        {/* Pilot Identity & Online Toggle */}
        <div className="pointer-events-auto flex items-center gap-2 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 p-1.5 pr-3 rounded-full shadow-lg">
          <img
            src={currentDriver.photo}
            alt={currentDriver.name}
            className="w-8 h-8 rounded-full object-cover border-2 border-orange-500"
          />
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-xs text-white">
                {currentDriver.name.split(' ')[0]}
              </span>
              <span className="text-[10px] text-amber-400 font-bold">
                ★ {currentDriver.rating}
              </span>
            </div>
            <p className="text-[9px] text-orange-400 font-mono">
              {currentDriver.vehicleNumber}
            </p>
          </div>
        </div>

        {/* Go Online / Offline Toggle Button */}
        <button
          onClick={toggleDriverOnline}
          className={`pointer-events-auto flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-black shadow-lg transition active:scale-95 ${
            currentDriver.isOnline
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
          }`}
        >
          <Power className="w-3.5 h-3.5" />
          <span>{currentDriver.isOnline ? 'ONLINE' : 'OFFLINE'}</span>
        </button>
      </div>

      {/* Map Area */}
      <div className="flex-1 relative min-h-[300px]">
        <LiveRideMap showAllDrivers={false} />
      </div>

      {/* Bottom Floating Area: Active Ride OR Standby Dashboard */}
      <div className="relative z-20 shrink-0">
        {isRideActive ? (
          <DriverActiveRideView />
        ) : (
          <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl shadow-2xl p-4 space-y-3">
            {/* Online Status Message */}
            <div className="flex items-center justify-between text-xs px-1">
              <div className="flex items-center gap-2">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    currentDriver.isOnline
                      ? 'bg-emerald-400 animate-pulse'
                      : 'bg-slate-600'
                  }`}
                />
                <span className="font-semibold text-slate-200">
                  {currentDriver.isOnline
                    ? language === 'hi'
                      ? 'आप ऑनलाइन हैं - राइड का इंतजार है'
                      : 'You are Online • Ready for Rides'
                    : language === 'hi'
                    ? 'आप ऑफलाइन हैं - ड्यूटी शुरू करने के लिए ऑन करें'
                    : 'You are Offline • Turn on to receive bookings'}
                </span>
              </div>
              <span className="text-[10px] uppercase font-bold text-slate-400">
                {currentDriver.vehicleCategory.toUpperCase()}
              </span>
            </div>

            {/* Quick Stat Pill Row */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setShowEarnings(true)}
                className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-orange-500 text-left transition flex items-center justify-between group"
              >
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">Today&apos;s Earnings</p>
                  <p className="text-xl font-black text-emerald-400">
                    ₹{currentDriver.earningsToday}
                  </p>
                </div>
                <div className="w-8 h-8 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center group-hover:scale-105 transition">
                  <Wallet className="w-4 h-4" />
                </div>
              </button>

              <button
                onClick={() => setShowKyc(true)}
                className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-orange-500 text-left transition flex items-center justify-between group"
              >
                <div>
                  <p className="text-[10px] uppercase font-bold text-slate-400">KYC Status</p>
                  <p className="text-xs font-bold text-white capitalize">
                    {currentDriver.kycStatus}
                  </p>
                  <p className="text-[10px] text-orange-400 font-semibold">Docs Verified</p>
                </div>
                <div className="w-8 h-8 rounded-xl bg-orange-600/20 text-orange-400 flex items-center justify-center group-hover:scale-105 transition">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </button>
            </div>

            {/* Ambikapur Hotspot Tips for Driver */}
            <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span>High demand: <strong>Ghadi Chowk & Station Road</strong></span>
              <span className="text-orange-400 font-semibold">1.2x Surge</span>
            </div>
          </div>
        )}
      </div>

      {/* Incoming Request Alert Modal */}
      {incomingRideRequest && <DriverIncomingRequestModal />}

      {/* KYC Modal */}
      {showKyc && <DriverKycModal onClose={() => setShowKyc(false)} />}

      {/* Earnings Modal */}
      {showEarnings && <DriverEarningsView onClose={() => setShowEarnings(false)} />}
    </div>
  );
};
