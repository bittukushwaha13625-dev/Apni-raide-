import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import {
  X,
  Wallet,
  TrendingUp,
  ArrowDownLeft,
  CheckCircle,
  Building,
  CreditCard,
  Calendar,
  Sparkles,
} from 'lucide-react';
import { playSound } from '../../utils/soundEffects';

interface DriverEarningsViewProps {
  onClose: () => void;
}

export const DriverEarningsView: React.FC<DriverEarningsViewProps> = ({ onClose }) => {
  const { currentDriver, language } = useRide();
  const [withdrawAmount, setWithdrawAmount] = useState<string>('500');
  const [isSuccess, setIsSuccess] = useState(false);

  const handleWithdraw = () => {
    playSound('success');
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-[700] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 overflow-hidden flex flex-col max-h-[85vh] animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center font-bold">
              ₹
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {language === 'hi' ? 'ड्राइवर कमाई व वॉलेट' : 'Driver Partner Earnings'}
              </h2>
              <p className="text-[11px] text-slate-400">Ambikapur Payouts & Commission</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 pt-4 overflow-y-auto flex-1">
          {/* Main Wallet Card */}
          <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950/40 rounded-2xl p-4 border border-emerald-500/30">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">
                  Withdrawable Wallet Balance
                </p>
                <h3 className="text-3xl font-black text-emerald-400 mt-1">
                  ₹{currentDriver.walletBalance}
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                Auto-Settled Daily
              </span>
            </div>

            {/* Withdraw form */}
            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-2">
              <input
                type="number"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                placeholder="Amount"
                className="w-24 bg-slate-950 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white"
              />
              <button
                onClick={handleWithdraw}
                className="flex-1 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5"
              >
                <ArrowDownLeft className="w-3.5 h-3.5" />
                <span>Instant Transfer to Bank / UPI</span>
              </button>
            </div>

            {isSuccess && (
              <p className="text-emerald-400 text-[11px] font-semibold mt-2 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                Transfer initiated to Ambikapur ICICI Bank / GPay!
              </p>
            )}
          </div>

          {/* Earnings Grid */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <p className="text-[10px] text-slate-400 uppercase font-semibold">Today</p>
              <p className="text-base font-extrabold text-white mt-0.5">₹{currentDriver.earningsToday}</p>
              <p className="text-[10px] text-emerald-400 font-medium">8 Rides</p>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <p className="text-[10px] text-slate-400 uppercase font-semibold">This Week</p>
              <p className="text-base font-extrabold text-white mt-0.5">₹6,420</p>
              <p className="text-[10px] text-emerald-400 font-medium">48 Rides</p>
            </div>

            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <p className="text-[10px] text-slate-400 uppercase font-semibold">This Month</p>
              <p className="text-base font-extrabold text-white mt-0.5">₹{currentDriver.totalEarnings}</p>
              <p className="text-[10px] text-emerald-400 font-medium">210 Rides</p>
            </div>
          </div>

          {/* Commission Transparency Card */}
          <div className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs space-y-1.5 text-slate-300">
            <p className="font-bold text-white flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-orange-400" />
              <span>Transparent 15% Platform Commission</span>
            </p>
            <p className="text-[11px] text-slate-400">
              You take home 85% of every single fare. No hidden fees or arbitrary deductions in Ambikapur.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
