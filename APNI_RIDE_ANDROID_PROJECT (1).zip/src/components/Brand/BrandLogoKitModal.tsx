import React, { useState } from 'react';
import {
  X,
  Download,
  Copy,
  Check,
  Smartphone,
  Car,
  IdCard,
  CreditCard,
  ExternalLink,
  Sparkles,
  Layers,
  Palette,
  ShieldCheck,
} from 'lucide-react';

interface LogoVersion {
  id: string;
  title: string;
  titleHi: string;
  tag: string;
  filePath: string;
  fileName: string;
  desc: string;
  dimensions: string;
  bgPreview: 'dark' | 'light' | 'checkered';
  useCases: string[];
}

const LOGO_VERSIONS: LogoVersion[] = [
  {
    id: 'main',
    title: '1. Main Brand Logo with APNI RIDE & Tagline',
    titleHi: 'मुख्य ब्रांड लोगो (टैगलाइन सहित)',
    tag: 'Primary Brand Mark',
    filePath: '/logo-main.svg',
    fileName: 'apni-ride-logo-main.svg',
    desc: 'The complete master brand lockup featuring the stylized letter "A" mobility emblem, GPS pin core, electric yellow speed arrow, radial speed rings, and bilingual tagline "Aapki Ride, Aapka Safar".',
    dimensions: '600 × 680 px (Vector SVG)',
    bgPreview: 'dark',
    useCases: [
      'App Splash Screen & Onboarding',
      'Marketing Banners & Billboards in Ambikapur',
      'Investor & Partner Presentations',
      'Official Website Hero Section',
    ],
  },
  {
    id: 'app-icon',
    title: '2. Android Application Squircle Icon',
    titleHi: 'एंड्रॉइड ऐप आइकन',
    tag: 'Android Mobile Launcher',
    filePath: '/icon.svg',
    fileName: 'apni-ride-android-icon.svg',
    desc: 'Optimized adaptive squircle icon tailored for the Android home screen, Google Play Store listing, notification tray, and quick-settings tile.',
    dimensions: '512 × 512 px (Adaptive Squircle)',
    bgPreview: 'dark',
    useCases: [
      'Android Home Screen Launcher',
      'Google Play Store 512x512 High-Res Icon',
      'Android Notification Bar',
      'PWA Mobile Homescreen Shortcut',
    ],
  },
  {
    id: 'icon-only',
    title: '3. Icon-Only Symbol (Letter "A" Speed Mark)',
    titleHi: 'आइकन सिंबल (स्टैंडअलोन)',
    tag: 'Standalone Emblem',
    filePath: '/logo-icon-only.svg',
    fileName: 'apni-ride-emblem-icon-only.svg',
    desc: 'Pure standalone graphic emblem combining the letter "A", highway perspective vanishing into the horizon, GPS destination pinhead, and electric yellow velocity chevron.',
    dimensions: '512 × 512 px (Isolated SVG)',
    bgPreview: 'checkered',
    useCases: [
      'Social Media Avatars (WhatsApp, Instagram, X)',
      'Bike Fuel Tank Badges & Helmet Decals',
      'Driver Steering Wheel Emblem',
      'App Favicon & Navigation Header',
    ],
  },
  {
    id: 'horizontal',
    title: '4. Horizontal Logo (Navbar & Fleet Decals)',
    titleHi: 'हॉरिजॉन्टल लोगो (नेवबार व वाहन स्टीकर)',
    tag: 'Wide Header & Decal',
    filePath: '/logo-horizontal.svg',
    fileName: 'apni-ride-logo-horizontal.svg',
    desc: 'Wide-aspect ratio layout with emblem on the left, high-contrast bold APNI RIDE typography, category badges (BIKE, AUTO, CAB), Ambikapur geo marker, and bilingual motto.',
    dimensions: '820 × 220 px (Vector SVG)',
    bgPreview: 'dark',
    useCases: [
      'Website & App Header Navigation',
      'Car Door Magnetic Vinyl Stickers',
      'Auto Rickshaw Rear Windshield Decal',
      'Driver Receipt Headers & Invoices',
    ],
  },
  {
    id: 'monochrome',
    title: '5. Monochrome / Black & White Version',
    titleHi: 'ब्लैक एंड व्हाइट / मोनोक्रोम लोगो',
    tag: 'Receipts & Uniform Embroidery',
    filePath: '/logo-monochrome.svg',
    fileName: 'apni-ride-logo-monochrome.svg',
    desc: 'High-contrast single-color monochrome mark engineered with negative space, ensuring maximum legibility on thermal print paper, laser cutting, and thread embroidery.',
    dimensions: '600 × 640 px (Vector SVG)',
    bgPreview: 'light',
    useCases: [
      'Driver Uniform Chest & Cap Embroidery',
      'Bluetooth Thermal Printer Ride Receipts',
      'Official Government Paperwork & Stamps',
      'Newspaper Classifieds & Single-Color Print',
    ],
  },
  {
    id: 'transparent',
    title: '6. Transparent Background Version',
    titleHi: 'पारदर्शी बैकग्राउंड लोगो',
    tag: 'Versatile Alpha Overlay',
    filePath: '/logo-transparent.svg',
    fileName: 'apni-ride-logo-transparent.svg',
    desc: 'Clean zero-background transparency format with dual-tone navy and electric yellow typography designed to float seamlessly over maps, photos, and video overlays.',
    dimensions: '760 × 200 px (Transparent SVG)',
    bgPreview: 'checkered',
    useCases: [
      'Overlay on Live Leaflet / Google Maps',
      'Promotional Video & Reel Watermarks',
      'Light & Dark Background Merchandise',
      'Business Cards & Stationery',
    ],
  },
];

const BRAND_PALETTE = [
  {
    name: 'Deep Royal Blue',
    nameHi: 'रॉयल ब्लू',
    hex: '#0a1931',
    accentHex: '#1d4ed8',
    role: 'Primary Authority & Security',
    desc: 'Represents technological trust, safety of female riders, and round-the-clock reliability.',
  },
  {
    name: 'Bright Electric Yellow',
    nameHi: 'इलेक्ट्रिक येलो',
    hex: '#facc15',
    accentHex: '#eab308',
    role: 'Mobility, Speed & Energy',
    desc: 'Pays homage to Indian auto-rickshaw heritage and dynamic forward velocity.',
  },
  {
    name: 'Crisp Pure White',
    nameHi: 'व्हाइट',
    hex: '#ffffff',
    accentHex: '#e2e8f0',
    role: 'Contrast & Highway Markers',
    desc: 'Used for apex highlights, lane dividers, and high-readability typography.',
  },
  {
    name: 'Dark Charcoal Void',
    nameHi: 'डार्क चारकोल',
    hex: '#070c16',
    accentHex: '#0f172a',
    role: 'Modern Tech Foundation',
    desc: 'Gives sleek depth and high-contrast night visibility in Android dark mode.',
  },
];

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const BrandLogoKitModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [selectedVersion, setSelectedVersion] = useState<LogoVersion>(LOGO_VERSIONS[0]);
  const [activeTab, setActiveTab] = useState<'logos' | 'mockups' | 'palette'>('logos');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [downloading, setDownloading] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownload = async (version: LogoVersion) => {
    try {
      setDownloading(version.id);
      const res = await fetch(version.filePath);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = version.fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      // Fallback
      window.open(version.filePath, '_blank');
    } finally {
      setTimeout(() => setDownloading(null), 600);
    }
  };

  const handleCopySvg = async (version: LogoVersion) => {
    try {
      const res = await fetch(version.filePath);
      const text = await res.text();
      await navigator.clipboard.writeText(text);
      setCopiedId(version.id);
      setTimeout(() => setCopiedId(null), 2500);
    } catch (err) {
      console.error('Failed to copy SVG', err);
    }
  };

  const copyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedId(hex);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 md:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-gradient-to-r from-slate-950 via-slate-900 to-blue-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-blue-600 via-blue-700 to-slate-950 p-1 flex items-center justify-center shadow-lg shadow-blue-900/40 border border-blue-400/30">
              <img src="/logo-icon-only.svg" alt="Apni Ride Emblem" className="w-8 h-8 object-contain" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black text-white tracking-tight">APNI RIDE Brand Identity</h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  Official Assets
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                &quot;Aapki Ride, Aapka Safar&quot; • आपकी राइड, आपका सफर • Ambikapur, Chhattisgarh
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-6 pt-3 pb-2 border-b border-slate-800 bg-slate-950/60">
          <button
            onClick={() => setActiveTab('logos')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === 'logos'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>6 Logo Versions ({LOGO_VERSIONS.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('mockups')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === 'mockups'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Real-World Mockups</span>
          </button>

          <button
            onClick={() => setActiveTab('palette')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition ${
              activeTab === 'palette'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Palette className="w-4 h-4 text-emerald-400" />
            <span>Color Palette & Specs</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'logos' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Selector List */}
              <div className="lg:col-span-5 space-y-2.5">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
                  Select Logo Format
                </p>
                <div className="space-y-2">
                  {LOGO_VERSIONS.map((ver) => {
                    const isSelected = selectedVersion.id === ver.id;
                    return (
                      <button
                        key={ver.id}
                        onClick={() => setSelectedVersion(ver)}
                        className={`w-full text-left p-3 rounded-2xl border transition flex items-center justify-between group ${
                          isSelected
                            ? 'bg-gradient-to-r from-blue-900/50 to-slate-800/80 border-blue-500 shadow-md shadow-blue-900/20'
                            : 'bg-slate-800/40 border-slate-700/60 hover:bg-slate-800 hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center p-1.5 shrink-0 overflow-hidden">
                            <img
                              src={ver.filePath}
                              alt={ver.title}
                              className="w-full h-full object-contain"
                            />
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white group-hover:text-blue-300 transition">
                              {ver.title}
                            </div>
                            <div className="text-[11px] text-slate-400 mt-0.5">{ver.tag}</div>
                          </div>
                        </div>

                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                            isSelected
                              ? 'bg-blue-500 text-white'
                              : 'bg-slate-800 text-slate-400 group-hover:text-slate-200'
                          }`}
                        >
                          View
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Right Display Card */}
              <div className="lg:col-span-7 bg-slate-950/70 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-3 mb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-black text-white">{selectedVersion.title}</h3>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-400/30">
                          {selectedVersion.dimensions}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                        {selectedVersion.desc}
                      </p>
                    </div>
                  </div>

                  {/* Visual Preview Box */}
                  <div
                    className={`relative w-full h-64 rounded-2xl flex items-center justify-center p-6 border shadow-inner overflow-hidden ${
                      selectedVersion.bgPreview === 'light'
                        ? 'bg-slate-100 border-slate-300'
                        : selectedVersion.bgPreview === 'checkered'
                        ? 'bg-[linear-gradient(45deg,#1e293b_25%,transparent_25%),linear-gradient(-45deg,#1e293b_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#1e293b_75%),linear-gradient(-45deg,transparent_75%,#1e293b_75%)] bg-[size:16px_16px] bg-slate-950 border-slate-800'
                        : 'bg-slate-950 border-slate-800'
                    }`}
                  >
                    <img
                      src={selectedVersion.filePath}
                      alt={selectedVersion.title}
                      className="max-h-full max-w-full object-contain drop-shadow-xl"
                    />

                    <div className="absolute bottom-2 right-2 px-2 py-1 rounded bg-black/60 backdrop-blur text-[10px] text-slate-300 font-mono">
                      {selectedVersion.fileName}
                    </div>
                  </div>

                  {/* Use Cases */}
                  <div className="mt-4">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                      Recommended Applications:
                    </p>
                    <div className="grid grid-cols-2 gap-2">
                      {selectedVersion.useCases.map((uc, i) => (
                        <div
                          key={i}
                          className="flex items-center gap-1.5 text-xs text-slate-300 bg-slate-900/80 px-2.5 py-1.5 rounded-xl border border-slate-800"
                        >
                          <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                          <span className="truncate">{uc}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3 mt-6 pt-4 border-t border-slate-800/80">
                  <button
                    onClick={() => handleDownload(selectedVersion)}
                    disabled={downloading === selectedVersion.id}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-blue-600/30 transition active:scale-95 disabled:opacity-50"
                  >
                    <Download className="w-4 h-4" />
                    <span>
                      {downloading === selectedVersion.id ? 'Downloading...' : 'Download SVG File'}
                    </span>
                  </button>

                  <button
                    onClick={() => handleCopySvg(selectedVersion)}
                    className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition active:scale-95"
                  >
                    {copiedId === selectedVersion.id ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span>Copy SVG Code</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'mockups' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Mockup 1: Android Smartphone Launcher */}
              <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Smartphone className="w-4 h-4 text-blue-400" />
                    <h4 className="text-sm font-black text-white">Android Smartphone Home Screen</h4>
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    High-contrast squircle adaptive app icon displaying perfectly on Google Pixel and Samsung One UI home screens.
                  </p>

                  <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col items-center justify-center space-y-4">
                    <div className="flex items-center justify-center gap-6">
                      {/* APNI RIDE App Icon */}
                      <div className="flex flex-col items-center gap-1.5">
                        <div className="w-16 h-16 rounded-2xl overflow-hidden shadow-xl shadow-blue-600/30 ring-2 ring-blue-500/30 transform hover:scale-105 transition">
                          <img src="/icon.svg" alt="Apni Ride Icon" className="w-full h-full object-cover" />
                        </div>
                        <span className="text-[11px] font-bold text-white tracking-wide">APNI RIDE</span>
                      </div>

                      {/* Standalone Emblem Icon */}
                      <div className="flex flex-col items-center gap-1.5 opacity-85">
                        <div className="w-16 h-16 rounded-2xl bg-slate-950 border border-slate-700 p-2 flex items-center justify-center shadow-lg">
                          <img src="/logo-icon-only.svg" alt="Emblem" className="w-full h-full object-contain" />
                        </div>
                        <span className="text-[11px] font-medium text-slate-400">Driver Partner</span>
                      </div>
                    </div>

                    <div className="text-[10px] text-slate-400 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                      Google Play Store Ready • 512x512 Adaptive Icon
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-mono">/public/icon.svg</span>
                  <button
                    onClick={() => handleDownload(LOGO_VERSIONS[1])}
                    className="text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" /> Download Icon
                  </button>
                </div>
              </div>

              {/* Mockup 2: Vehicle Decal & Magnet */}
              <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Car className="w-4 h-4 text-amber-400" />
                    <h4 className="text-sm font-black text-white">Fleet Vehicle Decal (Car, Auto & Bike)</h4>
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    High-visibility horizontal livery with Ambikapur CG-15 service tags for vehicle doors, rear windshields, and fuel tanks.
                  </p>

                  <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col items-center justify-center">
                    <div className="w-full max-w-sm rounded-xl overflow-hidden shadow-2xl border border-slate-700">
                      <img src="/logo-horizontal.svg" alt="Horizontal Decal" className="w-full h-auto object-cover" />
                    </div>

                    <div className="mt-3 flex items-center gap-3 text-[11px] text-slate-400 font-medium">
                      <span>• Weatherproof Vinyl</span>
                      <span>• 3M Reflective Yellow</span>
                      <span>• Night Visibility</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-mono">/public/logo-horizontal.svg</span>
                  <button
                    onClick={() => handleDownload(LOGO_VERSIONS[3])}
                    className="text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" /> Download Decal
                  </button>
                </div>
              </div>

              {/* Mockup 3: Driver Partner Uniform & ID Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <IdCard className="w-4 h-4 text-emerald-400" />
                    <h4 className="text-sm font-black text-white">Ambikapur Driver ID & Uniform Patch</h4>
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    Monochrome and royal blue embroidery layout engineered for driver jackets, caps, and official RTO badge cards.
                  </p>

                  <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-around gap-4">
                    {/* Uniform Patch */}
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-20 h-20 rounded-full bg-blue-950 border-2 border-amber-400 p-2 flex items-center justify-center shadow-lg">
                        <img src="/logo-icon-only.svg" alt="Patch" className="w-14 h-14 object-contain" />
                      </div>
                      <span className="text-[10px] font-bold text-slate-300">Embroidery Patch</span>
                    </div>

                    {/* Monochrome Print Badge */}
                    <div className="flex flex-col items-center gap-1">
                      <div className="w-24 h-28 bg-white rounded-lg p-2 flex flex-col items-center justify-between border border-slate-400 shadow-md text-black">
                        <img src="/logo-monochrome.svg" alt="ID Card Logo" className="w-full h-12 object-contain" />
                        <div className="text-[8px] font-black text-center border-t border-slate-300 w-full pt-1">
                          DRIVER PARTNER<br />CG-15-AMB
                        </div>
                      </div>
                      <span className="text-[10px] font-bold text-slate-300">Monochrome ID</span>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-mono">/public/logo-monochrome.svg</span>
                  <button
                    onClick={() => handleDownload(LOGO_VERSIONS[4])}
                    className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" /> Download B&W
                  </button>
                </div>
              </div>

              {/* Mockup 4: Premium Corporate Business Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <CreditCard className="w-4 h-4 text-indigo-400" />
                    <h4 className="text-sm font-black text-white">Corporate Business Card & Referral Voucher</h4>
                  </div>
                  <p className="text-xs text-slate-400 mb-4">
                    Matte Royal Blue card front featuring the Master Brand logo and gold-foil electric yellow accents.
                  </p>

                  <div className="w-full bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-center">
                    <div className="w-72 h-40 bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 border-2 border-amber-400/50 rounded-xl p-3 shadow-2xl flex flex-col justify-between">
                      <div className="flex items-center justify-between">
                        <img src="/logo-transparent.svg" alt="Card Logo" className="h-7 w-auto object-contain" />
                        <span className="text-[9px] font-bold text-amber-400 tracking-wider">CG-15</span>
                      </div>

                      <div className="text-left">
                        <div className="text-xs font-black text-white">APNI RIDE MOBILITY</div>
                        <div className="text-[9px] text-slate-400">Ambikapur, Chhattisgarh • India</div>
                      </div>

                      <div className="flex justify-between items-center pt-2 border-t border-slate-800 text-[8px] text-slate-400 font-mono">
                        <span>Aapki Ride, Aapka Safar</span>
                        <span className="text-amber-400 font-bold">www.apniride.in</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-mono">/public/logo-main.svg</span>
                  <button
                    onClick={() => handleDownload(LOGO_VERSIONS[0])}
                    className="text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" /> Download Main Logo
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'palette' && (
            <div className="space-y-6">
              {/* Color Swatches */}
              <div>
                <h4 className="text-sm font-black text-white mb-3">Official Brand Color Palette</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {BRAND_PALETTE.map((c) => (
                    <div
                      key={c.hex}
                      className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between"
                    >
                      <div>
                        <div
                          className="w-full h-20 rounded-xl shadow-inner mb-3 border border-white/10 flex items-end justify-end p-2"
                          style={{ backgroundColor: c.hex }}
                        >
                          <span
                            className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded ${
                              c.hex === '#ffffff' ? 'bg-black text-white' : 'bg-white text-black'
                            }`}
                          >
                            {c.hex}
                          </span>
                        </div>
                        <div className="text-sm font-black text-white">{c.name}</div>
                        <div className="text-[11px] text-amber-400 font-medium mb-1">{c.nameHi}</div>
                        <div className="text-[11px] font-semibold text-slate-300">{c.role}</div>
                        <p className="text-[10px] text-slate-400 mt-2 leading-relaxed">{c.desc}</p>
                      </div>

                      <button
                        onClick={() => copyHex(c.hex)}
                        className="mt-3 w-full py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-[11px] font-bold text-slate-300 border border-slate-700 transition flex items-center justify-center gap-1"
                      >
                        {copiedId === c.hex ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400">Copied HEX</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy HEX: {c.hex}</span>
                          </>
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Typography & Brand Messaging */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Typography System
                  </h5>
                  <div className="space-y-3">
                    <div>
                      <div className="text-xs font-semibold text-slate-400">Brand Wordmark</div>
                      <div className="text-2xl font-black text-white tracking-wide">
                        APNI <span className="text-amber-400">RIDE</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        Font: Plus Jakarta Sans / Inter ExtraBold (Weight: 900)
                      </div>
                    </div>

                    <div>
                      <div className="text-xs font-semibold text-slate-400">Vehicle Categories</div>
                      <div className="text-sm font-extrabold text-blue-400 tracking-widest">
                        BIKE • AUTO • CAR TAXI
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Official Tagline & City Identity
                  </h5>
                  <div className="space-y-3">
                    <div>
                      <div className="text-xs font-semibold text-slate-400">English Tagline</div>
                      <div className="text-base font-bold text-white">
                        &quot;Aapki Ride, Aapka Safar&quot;
                      </div>
                    </div>

                    <div>
                      <div className="text-xs font-semibold text-slate-400">Hindi Tagline</div>
                      <div className="text-base font-bold text-amber-300">
                        &quot;आपकी राइड, आपका सफर&quot;
                      </div>
                    </div>

                    <div>
                      <div className="text-xs font-semibold text-slate-400">Launch City</div>
                      <div className="text-xs font-bold text-slate-300">
                        Ambikapur, Surguja District, Chhattisgarh (CG-15)
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>All 6 SVG brand assets are vector-crisp and ready for production deployment.</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold transition"
          >
            Close Brand Kit
          </button>
        </div>
      </div>
    </div>
  );
};
