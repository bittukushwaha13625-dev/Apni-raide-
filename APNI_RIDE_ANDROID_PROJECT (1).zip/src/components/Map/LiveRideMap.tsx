import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { useRide } from '../../context/RideContext';
import {
  AMBIKAPUR_CENTER,
  AMBIKAPUR_LOCATIONS,
  AMBIKAPUR_SERVICE_BOUNDARY,
} from '../../data/ambikapurLocations';
import { reverseGeocodeAmbikapur, searchLocalAmbikapur } from '../../services/geocodingService';
import { calculateAmbikapurRoutes } from '../../services/routingService';
import { LocationCategory, LocationPoint, MapLayerStyle, RouteOption } from '../../types/ride';
import { ReportMapIssueModal } from '../Common/ReportMapIssueModal';
import { NearbyPlacesDrawer } from '../Customer/NearbyPlacesDrawer';
import { SavedPlacesModal } from '../Customer/SavedPlacesModal';
import {
  Navigation,
  Compass,
  Layers,
  MapPin,
  Search,
  Crosshair,
  Flag,
  RotateCcw,
  AlertCircle,
  Eye,
  Check,
  Zap,
  Bookmark,
  Maximize2,
  Minimize2,
  Sliders,
  Shield,
} from 'lucide-react';
import { playSound } from '../../utils/soundEffects';

interface LiveRideMapProps {
  className?: string;
  showAllDrivers?: boolean;
  interactive?: boolean;
  onSelectPickupFromMap?: (point: LocationPoint) => void;
  onSelectDropFromMap?: (point: LocationPoint) => void;
}

export const LiveRideMap: React.FC<LiveRideMapProps> = ({
  className = 'h-full w-full',
  showAllDrivers = true,
  onSelectPickupFromMap,
  onSelectDropFromMap,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  // Layer groups
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const routeLayerRef = useRef<L.LayerGroup | null>(null);
  const driverMarkerRef = useRef<L.Marker | null>(null);
  const otherDriversLayerRef = useRef<L.LayerGroup | null>(null);
  const poiLayerRef = useRef<L.LayerGroup | null>(null);
  const userGpsMarkerRef = useRef<L.Marker | null>(null);
  const userGpsCircleRef = useRef<L.Circle | null>(null);
  const pickupMarkerRef = useRef<L.Marker | null>(null);
  const dropMarkerRef = useRef<L.Marker | null>(null);
  const boundaryPolygonRef = useRef<L.Polygon | null>(null);

  const {
    currentRide,
    driverPosition,
    drivers,
    popularLocations,
    language,
    requestRide,
    draftPickup,
    draftDestination,
    setDraftPickup,
    setDraftDestination,
  } = useRide();

  // Map state
  const [mapStyle, setMapStyle] = useState<MapLayerStyle>('streets');
  const [selectedPoiCategory, setSelectedPoiCategory] = useState<LocationCategory | 'all'>('all');
  const [showPoiMenu, setShowPoiMenu] = useState(false);
  const [availableRoutes, setAvailableRoutes] = useState<RouteOption[]>([]);
  const [selectedRouteId, setSelectedRouteId] = useState<string>('route-fastest');
  const [showReportModal, setShowReportModal] = useState(false);
  const [showNearbyDrawer, setShowNearbyDrawer] = useState(false);
  const [showSavedPlacesModal, setShowSavedPlacesModal] = useState(false);
  const [showServiceBoundary, setShowServiceBoundary] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const [lastClickedCoords, setLastClickedCoords] = useState<{ lat: number; lng: number }>({
    lat: AMBIKAPUR_CENTER.lat,
    lng: AMBIKAPUR_CENTER.lng,
  });

  // Search overlay state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<LocationPoint[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Tile provider URLs
  const getTileUrl = (style: MapLayerStyle) => {
    switch (style) {
      case 'satellite':
        // High-resolution Esri World Imagery (Real aerial satellite photos of Ambikapur)
        return 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      case 'terrain':
        // OpenTopoMap Terrain with contour lines & topography
        return 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png';
      case 'night':
        // CartoDB Dark Matter
        return 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
      default:
        // CartoDB Voyager Streets - Highly readable with Hindi/English street and colony names
        return 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
    }
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [AMBIKAPUR_CENTER.lat, AMBIKAPUR_CENTER.lng],
      zoom: 14,
      zoomControl: false,
      attributionControl: false,
      maxBounds: [
        [23.00, 83.05], // South-West Ambikapur buffer
        [23.25, 83.35], // North-East Ambikapur buffer
      ],
      minZoom: 11,
      maxZoom: 19,
    });

    const tileLayer = L.tileLayer(getTileUrl('streets'), {
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(map);

    tileLayerRef.current = tileLayer;

    // Layer groups
    poiLayerRef.current = L.layerGroup().addTo(map);
    routeLayerRef.current = L.layerGroup().addTo(map);
    otherDriversLayerRef.current = L.layerGroup().addTo(map);

    L.control.zoom({ position: 'bottomright' }).addTo(map);

    // Map Tap / Click handler for reverse geocoding
    map.on('click', async (e: L.LeafletMouseEvent) => {
      const { lat, lng } = e.latlng;
      setLastClickedCoords({ lat, lng });

      // Automatically reverse geocode tapped point
      const point = await reverseGeocodeAmbikapur(lat, lng);
      playSound('beep');

      // Bind a quick action popup directly at the tapped location
      const popup = L.popup({ className: 'custom-map-click-popup' })
        .setLatLng([lat, lng])
        .setContent(`
          <div class="p-2 font-sans text-xs">
            <p class="font-bold text-slate-900">${point.name}</p>
            <p class="text-[11px] text-slate-600 mb-2">${point.address}</p>
            <div class="flex gap-1.5">
              <button id="tap-set-pickup" class="px-2.5 py-1 bg-emerald-600 text-white rounded-lg font-bold text-[10px] shadow">Set as Pickup</button>
              <button id="tap-set-drop" class="px-2.5 py-1 bg-rose-600 text-white rounded-lg font-bold text-[10px] shadow">Set as Drop</button>
            </div>
          </div>
        `)
        .openOn(map);

      setTimeout(() => {
        const btnPickup = document.getElementById('tap-set-pickup');
        const btnDrop = document.getElementById('tap-set-drop');

        if (btnPickup) {
          btnPickup.onclick = () => {
            setDraftPickup(point);
            if (onSelectPickupFromMap) onSelectPickupFromMap(point);
            map.closePopup();
            playSound('success');
          };
        }
        if (btnDrop) {
          btnDrop.onclick = () => {
            setDraftDestination(point);
            if (onSelectDropFromMap) onSelectDropFromMap(point);
            map.closePopup();
            playSound('success');
          };
        }
      }, 50);
    });

    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Tile Layer on Style Change
  useEffect(() => {
    if (!mapInstanceRef.current) return;

    if (tileLayerRef.current) {
      tileLayerRef.current.remove();
    }

    const newTile = L.tileLayer(getTileUrl(mapStyle), {
      maxZoom: 19,
      subdomains: 'abcd',
    }).addTo(mapInstanceRef.current);

    tileLayerRef.current = newTile;
    newTile.bringToBack();
  }, [mapStyle]);

  // Service Area Boundary Polygon Overlay
  useEffect(() => {
    if (!mapInstanceRef.current) return;

    if (boundaryPolygonRef.current) {
      boundaryPolygonRef.current.remove();
      boundaryPolygonRef.current = null;
    }

    if (showServiceBoundary) {
      boundaryPolygonRef.current = L.polygon(AMBIKAPUR_SERVICE_BOUNDARY, {
        color: '#f97316',
        weight: 3,
        dashArray: '6, 6',
        fillColor: '#f97316',
        fillOpacity: 0.08,
      }).addTo(mapInstanceRef.current);

      boundaryPolygonRef.current.bindPopup(
        '<b>APNI RIDE Ambikapur Service Zone</b><br>Licensed Municipal & Rural Perimeter'
      );
    }
  }, [showServiceBoundary]);

  // Update POI Landmarks based on Filter Category
  useEffect(() => {
    if (!mapInstanceRef.current || !poiLayerRef.current) return;

    poiLayerRef.current.clearLayers();

    const pointsToRender =
      selectedPoiCategory === 'all'
        ? AMBIKAPUR_LOCATIONS
        : AMBIKAPUR_LOCATIONS.filter((l) => l.category === selectedPoiCategory);

    pointsToRender.forEach((loc) => {
      const getPoiSymbol = (cat: LocationCategory) => {
        switch (cat) {
          case 'hospital': return '🏥';
          case 'police': return '👮';
          case 'petrol': return '⛽';
          case 'pharmacy': return '💊';
          case 'bank': return '🏧';
          case 'temple': return '🛕';
          case 'school': return '🏫';
          case 'transit': return '🚆';
          case 'hotel': return '🏨';
          case 'commercial': return '🛍️';
          case 'govt': return '🏛️';
          case 'village': return '🌾';
          default: return '📍';
        }
      };

      const icon = L.divIcon({
        className: 'custom-poi-marker',
        html: `
          <div class="cursor-pointer group flex flex-col items-center">
            <div class="w-7 h-7 rounded-full bg-slate-900/95 border border-slate-700 shadow-md flex items-center justify-center text-xs group-hover:scale-125 group-hover:border-orange-500 transition-transform">
              ${getPoiSymbol(loc.category)}
            </div>
            <span class="mt-0.5 px-1.5 py-0.2 rounded bg-black/85 text-[9px] font-bold text-white whitespace-nowrap shadow opacity-85 group-hover:opacity-100 group-hover:bg-orange-600 transition">
              ${language === 'hi' ? loc.nameHi : loc.name}
            </span>
          </div>
        `,
        iconSize: [28, 42],
        iconAnchor: [14, 21],
      });

      const marker = L.marker([loc.lat, loc.lng], { icon });
      marker.bindPopup(`
        <div class="p-1 font-sans text-xs">
          <p class="font-extrabold text-slate-900">${language === 'hi' ? loc.nameHi : loc.name}</p>
          <p class="text-slate-600 text-[11px]">${loc.address}</p>
          <div class="mt-2 flex gap-1">
            <button id="set-pickup-${loc.id}" class="px-2 py-1 bg-emerald-600 text-white rounded text-[10px] font-bold">Set Pickup</button>
            <button id="set-drop-${loc.id}" class="px-2 py-1 bg-rose-600 text-white rounded text-[10px] font-bold">Set Drop</button>
          </div>
        </div>
      `);

      marker.on('popupopen', () => {
        const btnPickup = document.getElementById(`set-pickup-${loc.id}`);
        const btnDrop = document.getElementById(`set-drop-${loc.id}`);

        if (btnPickup) {
          btnPickup.onclick = () => {
            setDraftPickup(loc);
            if (onSelectPickupFromMap) onSelectPickupFromMap(loc);
            marker.closePopup();
            playSound('beep');
          };
        }
        if (btnDrop) {
          btnDrop.onclick = () => {
            setDraftDestination(loc);
            if (onSelectDropFromMap) onSelectDropFromMap(loc);
            marker.closePopup();
            playSound('beep');
          };
        }
      });

      poiLayerRef.current?.addLayer(marker);
    });
  }, [selectedPoiCategory, language]);

  // Update nearby idle drivers
  useEffect(() => {
    if (!mapInstanceRef.current || !otherDriversLayerRef.current) return;

    otherDriversLayerRef.current.clearLayers();

    if (showAllDrivers) {
      drivers
        .filter((d) => d.isOnline)
        .forEach((driver) => {
          if (currentRide?.driverId === driver.id) return;

          const getSymbol = () => {
            if (driver.vehicleCategory === 'bike') return '🏍️';
            if (driver.vehicleCategory === 'auto') return '🛺';
            return '🚗';
          };

          const icon = L.divIcon({
            className: 'custom-driver-pin',
            html: `
              <div class="relative group cursor-pointer">
                <div class="w-9 h-9 rounded-full bg-slate-900 border-2 border-orange-500 shadow-md flex items-center justify-center text-sm transform hover:scale-110 transition-transform">
                  ${getSymbol()}
                </div>
              </div>
            `,
            iconSize: [36, 36],
            iconAnchor: [18, 18],
          });

          const marker = L.marker([driver.lat, driver.lng], { icon });
          marker.bindPopup(`
            <div class="p-1 font-sans text-xs">
              <p class="font-bold text-slate-900">${driver.name}</p>
              <p class="text-slate-600">${driver.vehicleModel} • ${driver.vehicleNumber}</p>
              <p class="text-orange-600 font-semibold mt-1">★ ${driver.rating} • Available in Ambikapur</p>
            </div>
          `);
          otherDriversLayerRef.current?.addLayer(marker);
        });
    }
  }, [drivers, showAllDrivers, currentRide]);

  // Calculate and draw Route Options + Draggable Pickup & Drop Markers
  useEffect(() => {
    if (!mapInstanceRef.current || !routeLayerRef.current) return;

    const map = mapInstanceRef.current;
    routeLayerRef.current.clearLayers();

    // Use current active ride endpoints OR the draft locations
    const p = currentRide ? currentRide.pickup : draftPickup;
    const d = currentRide ? currentRide.destination : draftDestination;

    // Clean up old markers
    if (pickupMarkerRef.current) pickupMarkerRef.current.remove();
    if (dropMarkerRef.current) dropMarkerRef.current.remove();

    calculateAmbikapurRoutes(p, d).then((routes) => {
      setAvailableRoutes(routes);

      routes.forEach((route) => {
        const isSelected = route.id === selectedRouteId;

        const polyline = L.polyline(route.polyline, {
          color: isSelected ? '#ea580c' : '#64748b',
          weight: isSelected ? 6 : 4,
          opacity: isSelected ? 0.95 : 0.45,
          dashArray: isSelected ? undefined : '6, 8',
          lineCap: 'round',
        });

        polyline.on('click', () => {
          setSelectedRouteId(route.id);
          playSound('beep');
        });

        routeLayerRef.current?.addLayer(polyline);
      });

      // Draggable Pickup Marker (Green)
      const pickupIcon = L.divIcon({
        className: 'custom-pickup-marker',
        html: `
          <div class="relative flex items-center justify-center cursor-grab active:cursor-grabbing">
            <span class="animate-ping absolute inline-flex h-9 w-9 rounded-full bg-emerald-400 opacity-60"></span>
            <div class="w-8 h-8 rounded-full bg-emerald-600 border-2 border-white shadow-xl flex items-center justify-center text-white text-xs font-black">
              P
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const pMarker = L.marker([p.lat, p.lng], {
        icon: pickupIcon,
        draggable: !currentRide, // Draggable before ride confirms
      }).addTo(map);

      pMarker.on('dragend', async (e: L.DragEndEvent) => {
        const { lat, lng } = e.target.getLatLng();
        const resolved = await reverseGeocodeAmbikapur(lat, lng);
        setDraftPickup(resolved);
        if (onSelectPickupFromMap) onSelectPickupFromMap(resolved);
        playSound('success');
      });

      pickupMarkerRef.current = pMarker;

      // Draggable Dropoff Marker (Red)
      const dropIcon = L.divIcon({
        className: 'custom-drop-marker',
        html: `
          <div class="relative flex items-center justify-center cursor-grab active:cursor-grabbing">
            <div class="w-8 h-8 rounded-full bg-rose-600 border-2 border-white shadow-xl flex items-center justify-center text-white text-xs font-black">
              D
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const dMarker = L.marker([d.lat, d.lng], {
        icon: dropIcon,
        draggable: !currentRide,
      }).addTo(map);

      dMarker.on('dragend', async (e: L.DragEndEvent) => {
        const { lat, lng } = e.target.getLatLng();
        const resolved = await reverseGeocodeAmbikapur(lat, lng);
        setDraftDestination(resolved);
        if (onSelectDropFromMap) onSelectDropFromMap(resolved);
        playSound('success');
      });

      dropMarkerRef.current = dMarker;

      // Fit map view
      const bounds = L.latLngBounds([
        [p.lat, p.lng],
        [d.lat, d.lng],
      ]);
      map.fitBounds(bounds, { padding: [60, 60], maxZoom: 15 });
    });
  }, [currentRide, draftPickup, draftDestination, selectedRouteId]);

  // Update Driver Moving Marker with Dynamic Heading
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (!driverMarkerRef.current) {
      const getVehicleSymbol = () => {
        const cat = currentRide?.vehicleCategory || 'bike';
        if (cat === 'bike') return '🏍️';
        if (cat === 'auto') return '🛺';
        return '🚗';
      };

      const icon = L.divIcon({
        className: 'active-driver-marker',
        html: `
          <div class="relative flex items-center justify-center" style="transform: rotate(${driverPosition.heading}deg);">
            <div class="w-12 h-12 rounded-full bg-gradient-to-tr from-orange-600 to-amber-500 border-2 border-white shadow-2xl flex items-center justify-center text-xl text-white transform hover:scale-110 transition">
              ${getVehicleSymbol()}
            </div>
            <div class="absolute -top-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-slate-900 animate-ping"></div>
          </div>
        `,
        iconSize: [48, 48],
        iconAnchor: [24, 24],
      });

      driverMarkerRef.current = L.marker([driverPosition.lat, driverPosition.lng], {
        icon,
        zIndexOffset: 1000,
      }).addTo(map);
    } else {
      driverMarkerRef.current.setLatLng([driverPosition.lat, driverPosition.lng]);
    }
  }, [driverPosition, currentRide]);

  // Current GPS Detection handler
  const handleDetectGPS = () => {
    if (!navigator.geolocation || !mapInstanceRef.current) {
      alert('Geolocation is not supported on this device');
      return;
    }

    playSound('beep');
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude, accuracy } = pos.coords;
        const map = mapInstanceRef.current;
        if (!map) return;

        if (userGpsMarkerRef.current) userGpsMarkerRef.current.remove();
        if (userGpsCircleRef.current) userGpsCircleRef.current.remove();

        const gpsIcon = L.divIcon({
          className: 'user-gps-dot',
          html: `
            <div class="relative flex items-center justify-center">
              <span class="animate-ping absolute inline-flex h-8 w-8 rounded-full bg-blue-400 opacity-60"></span>
              <div class="w-4 h-4 rounded-full bg-blue-600 border-2 border-white shadow-lg"></div>
            </div>
          `,
          iconSize: [16, 16],
          iconAnchor: [8, 8],
        });

        userGpsMarkerRef.current = L.marker([latitude, longitude], { icon: gpsIcon }).addTo(map);
        userGpsCircleRef.current = L.circle([latitude, longitude], {
          radius: Math.min(accuracy, 200),
          color: '#3b82f6',
          fillColor: '#3b82f6',
          fillOpacity: 0.12,
        }).addTo(map);

        map.setView([latitude, longitude], 15, { animate: true });

        // Update pickup to user location
        const userPoint = await reverseGeocodeAmbikapur(latitude, longitude);
        setDraftPickup(userPoint);
        if (onSelectPickupFromMap) onSelectPickupFromMap(userPoint);
        playSound('success');
      },
      () => {
        mapInstanceRef.current?.setView([AMBIKAPUR_CENTER.lat, AMBIKAPUR_CENTER.lng], 15, {
          animate: true,
        });
      },
      { enableHighAccuracy: true, timeout: 5000 }
    );
  };

  const handleSearchChange = (val: string) => {
    setSearchQuery(val);
    if (val.trim().length > 0) {
      const results = searchLocalAmbikapur(val);
      setSearchResults(results.slice(0, 7));
      setIsSearching(true);
    } else {
      setSearchResults([]);
      setIsSearching(false);
    }
  };

  const handleSelectSearchResult = (point: LocationPoint) => {
    setSearchQuery(language === 'hi' ? point.nameHi : point.name);
    setIsSearching(false);
    playSound('beep');

    if (mapInstanceRef.current) {
      mapInstanceRef.current.setView([point.lat, point.lng], 16, { animate: true });
    }
  };

  return (
    <div
      className={`relative overflow-hidden bg-slate-900 ${
        isFullscreen ? 'fixed inset-0 z-[1000]' : className
      }`}
    >
      {/* Map DOM */}
      <div ref={mapContainerRef} className="h-full w-full z-0" />

      {/* Top Floating Search Bar directly on Map */}
      <div className="absolute top-3 left-3 right-14 z-[400] max-w-md">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
            placeholder={
              language === 'hi'
                ? 'सड़क, मोहल्ला, दुकान या कॉलोनी खोजें...'
                : 'Search street, colony, mohalla, shop in Ambikapur...'
            }
            className="w-full pl-10 pr-4 py-2 bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-2xl text-xs text-white placeholder-slate-400 shadow-xl focus:outline-none focus:border-orange-500 transition"
          />
        </div>

        {/* Live Search Autocomplete Popup */}
        {isSearching && searchResults.length > 0 && (
          <div className="absolute top-11 left-0 right-0 bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-2xl shadow-2xl p-1.5 space-y-1 max-h-56 overflow-y-auto">
            {searchResults.map((res) => (
              <button
                key={res.id}
                onClick={() => handleSelectSearchResult(res)}
                className="w-full flex items-start gap-2.5 p-2 rounded-xl text-left hover:bg-slate-800 transition"
              >
                <MapPin className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                <div className="truncate">
                  <p className="text-xs font-bold text-white truncate">
                    {language === 'hi' ? res.nameHi : res.name}
                  </p>
                  <p className="text-[10px] text-slate-400 truncate">{res.address}</p>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Map Control Buttons */}
      <div className="absolute top-3 right-3 z-[400] flex flex-col gap-2">
        {/* Current GPS Detector */}
        <button
          onClick={handleDetectGPS}
          aria-label="Find Current GPS Location"
          className="w-10 h-10 rounded-xl bg-slate-900/95 backdrop-blur-md border border-slate-700 shadow-xl flex items-center justify-center text-slate-200 hover:text-blue-400 hover:border-blue-500 transition active:scale-95"
          title="Detect Current GPS Location"
        >
          <Crosshair className="w-5 h-5 text-blue-400" />
        </button>

        {/* Layer Style Switcher (Streets, Satellite, Terrain, Night) */}
        <button
          onClick={() => {
            const styles: MapLayerStyle[] = ['streets', 'satellite', 'terrain', 'night'];
            const curIdx = styles.indexOf(mapStyle);
            const next = styles[(curIdx + 1) % styles.length];
            setMapStyle(next);
            playSound('beep');
          }}
          className="w-10 h-10 rounded-xl bg-slate-900/95 backdrop-blur-md border border-slate-700 shadow-xl flex items-center justify-center text-slate-200 hover:text-orange-400 hover:border-orange-500 transition active:scale-95"
          title={`Layer: ${mapStyle.toUpperCase()} (Click to toggle)`}
        >
          <Layers className="w-5 h-5 text-orange-400" />
        </button>

        {/* Explore Nearby Places Drawer */}
        <button
          onClick={() => setShowNearbyDrawer(true)}
          className="w-10 h-10 rounded-xl bg-slate-900/95 backdrop-blur-md border border-slate-700 shadow-xl flex items-center justify-center text-slate-200 hover:text-orange-400 transition active:scale-95 text-xs font-bold"
          title="Explore Nearby Places in Ambikapur"
        >
          <Compass className="w-5 h-5 text-amber-400 animate-spin-slow" />
        </button>

        {/* Saved Addresses (Home, Office, Favorites) */}
        <button
          onClick={() => setShowSavedPlacesModal(true)}
          className="w-10 h-10 rounded-xl bg-slate-900/95 backdrop-blur-md border border-slate-700 shadow-xl flex items-center justify-center text-slate-200 hover:text-orange-400 transition active:scale-95 text-xs font-bold"
          title="Saved Addresses"
        >
          <Bookmark className="w-4 h-4 text-emerald-400" />
        </button>

        {/* Service Boundary Polygon Toggle */}
        <button
          onClick={() => {
            setShowServiceBoundary(!showServiceBoundary);
            playSound('beep');
          }}
          className={`w-10 h-10 rounded-xl backdrop-blur-md border shadow-xl flex items-center justify-center transition active:scale-95 ${
            showServiceBoundary
              ? 'bg-orange-600 text-white border-orange-500'
              : 'bg-slate-900/95 text-slate-300 border-slate-700 hover:text-orange-400'
          }`}
          title="Toggle Ambikapur Service Perimeter"
        >
          <Shield className="w-4 h-4 text-orange-400" />
        </button>

        {/* Fullscreen Map Toggle */}
        <button
          onClick={() => setIsFullscreen(!isFullscreen)}
          className="w-10 h-10 rounded-xl bg-slate-900/95 backdrop-blur-md border border-slate-700 shadow-xl flex items-center justify-center text-slate-200 hover:text-white transition active:scale-95"
          title="Toggle Fullscreen Map"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        {/* Report Map Issue */}
        <button
          onClick={() => setShowReportModal(true)}
          className="w-10 h-10 rounded-xl bg-slate-900/95 backdrop-blur-md border border-slate-700 shadow-xl flex items-center justify-center text-slate-300 hover:text-rose-400 hover:border-rose-500 transition active:scale-95 text-xs font-bold"
          title="Report Missing Road or Map Issue"
        >
          ⚠️
        </button>
      </div>

      {/* Alternative Routes Comparison Pills */}
      {availableRoutes.length > 1 && (
        <div className="absolute top-14 left-3 right-14 z-[400] flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
          {availableRoutes.map((route) => {
            const isSelected = route.id === selectedRouteId;
            return (
              <button
                key={route.id}
                onClick={() => {
                  setSelectedRouteId(route.id);
                  playSound('beep');
                }}
                className={`whitespace-nowrap flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold shadow-xl border backdrop-blur-md transition ${
                  isSelected
                    ? 'bg-orange-600 text-white border-orange-400 ring-2 ring-orange-500/30'
                    : 'bg-slate-900/90 text-slate-300 border-slate-700 hover:border-slate-500'
                }`}
              >
                <span>{language === 'hi' ? route.nameHi : route.name}</span>
                <span className="text-[10px] opacity-90">
                  {route.distanceKm} km • {route.durationMinutes} min
                </span>
              </button>
            );
          })}
        </div>
      )}

      {/* Draggable Pin Hint Toast */}
      {!currentRide && (
        <div className="absolute bottom-2 left-3 z-[400] bg-slate-950/85 backdrop-blur-md border border-slate-800 px-3 py-1.5 rounded-full text-[10px] text-slate-300 flex items-center gap-1.5 shadow">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>
            {language === 'hi'
              ? 'टिप: पिन को ड्रैग करके ठीक अपने गेट पर सेट करें'
              : 'Tip: Drag Green (P) or Red (D) pin anywhere on map'}
          </span>
        </div>
      )}

      {/* Nearby Places Drawer */}
      {showNearbyDrawer && (
        <NearbyPlacesDrawer
          onClose={() => setShowNearbyDrawer(false)}
          onSelectPlace={(place, action) => {
            if (action === 'pickup') {
              setDraftPickup(place);
              if (onSelectPickupFromMap) onSelectPickupFromMap(place);
            } else if (action === 'drop') {
              setDraftDestination(place);
              if (onSelectDropFromMap) onSelectDropFromMap(place);
            }
            if (mapInstanceRef.current) {
              mapInstanceRef.current.setView([place.lat, place.lng], 16, { animate: true });
            }
          }}
        />
      )}

      {/* Saved Places Modal */}
      {showSavedPlacesModal && (
        <SavedPlacesModal
          onClose={() => setShowSavedPlacesModal(false)}
          onSelectPlace={(place) => {
            setDraftDestination(place);
            if (mapInstanceRef.current) {
              mapInstanceRef.current.setView([place.lat, place.lng], 16, { animate: true });
            }
          }}
        />
      )}

      {/* Report Map Issue Modal */}
      {showReportModal && (
        <ReportMapIssueModal
          coordinates={lastClickedCoords}
          onClose={() => setShowReportModal(false)}
        />
      )}
    </div>
  );
};
