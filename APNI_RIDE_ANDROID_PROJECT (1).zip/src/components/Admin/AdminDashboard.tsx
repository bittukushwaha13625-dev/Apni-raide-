import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { LiveRideMap } from '../Map/LiveRideMap';
import {
  Users,
  Car,
  TrendingUp,
  ShieldCheck,
  ShieldAlert,
  Sliders,
  Tag,
  CheckCircle,
  XCircle,
  Download,
  AlertTriangle,
  RefreshCw,
  Search,
  Check,
} from 'lucide-react';
import { VehicleCategory } from '../../types/ride';
import { playSound } from '../../utils/soundEffects';

export const AdminDashboard: React.FC = () => {
  const {
    adminStats,
    drivers,
    adminApproveDriver,
    adminRejectDriver,
    vehicleOptions,
    adminUpdateFare,
    sosAlerts,
    resolveSos,
    promoCodes,
    currentRide,
    language,
  } = useRide();

  const [activeAdminTab, setActiveAdminTab] = useState<'overview' | 'drivers' | 'fares' | 'sos' | 'promos' | 'map_control'>('overview');
  const [driverSearch, setDriverSearch] = useState('');
  const [editingFareCat, setEditingFareCat] = useState<VehicleCategory | null>(null);
  const [newBase, setNewBase] = useState<number>(20);
  const [newPerKm, setNewPerKm] = useState<number>(7);

  // Map Reports & Service Areas
  const [mapReports, setMapReports] = useState<any[]>([
    {
      id: 'mr-1',
      reporterName: 'Manoj Yadav (Pilot CG-15-T-7712)',
      reporterPhone: '+91 94062 88123',
      issueType: 'missing_road',
      landmark: 'Behind Kedarpur High School',
      description: 'New 20ft paved road connecting Kedarpur directly to Ring Road bypass.',
      coordinates: { lat: 23.1185, lng: 83.1890 },
      timestamp: Date.now() - 3600000 * 4,
      status: 'pending',
    },
    {
      id: 'mr-2',
      reporterName: 'Sunita Sharma (Rider)',
      reporterPhone: '+91 98271 55012',
      issueType: 'new_colony',
      landmark: 'Namnakala Phase 2 Extension',
      description: 'Added 40 newly constructed residences along with Sai Mandir road.',
      coordinates: { lat: 23.1330, lng: 83.2110 },
      timestamp: Date.now() - 3600000 * 12,
      status: 'pending',
    },
    {
      id: 'mr-3',
      reporterName: 'Rameshwar Sahu (Pilot CG-15-AB-4821)',
      reporterPhone: '+91 98261 45892',
      issueType: 'closed_road',
      landmark: 'Gudri Market Entrance',
      description: 'One-way restriction enforced by Ambikapur Traffic Police during market hours.',
      coordinates: { lat: 23.1220, lng: 83.1970 },
      timestamp: Date.now() - 3600000 * 24,
      status: 'approved',
    },
  ]);

  const [vehicleAvailability, setVehicleAvailability] = useState({
    bike: true,
    auto: true,
    mini: true,
    sedan: true,
  });

  const pendingDrivers = drivers.filter((d) => d.kycStatus === 'pending');
  const filteredDrivers = drivers.filter(
    (d) =>
      d.name.toLowerCase().includes(driverSearch.toLowerCase()) ||
      d.vehicleNumber.toLowerCase().includes(driverSearch.toLowerCase()) ||
      d.phone.includes(driverSearch)
  );

  const handleSaveFare = (cat: VehicleCategory) => {
    adminUpdateFare(cat, newBase, newPerKm);
    setEditingFareCat(null);
    playSound('success');
  };

  const handleExportData = () => {
    const data = {
      exportTimestamp: new Date().toISOString(),
      city: 'Ambikapur, Chhattisgarh (CG-15)',
      stats: adminStats,
      vehicleRates: vehicleOptions,
      registeredDrivers: drivers,
      activeRides: currentRide ? [currentRide] : [],
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `apni-ride-ambikapur-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    playSound('success');
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 overflow-y-auto">
      {/* Admin Subheader Bar */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-lg font-black text-white flex items-center gap-2">
            <span>APNI RIDE • ADMIN COMMAND CENTER</span>
            <span className="px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-400 text-xs font-bold border border-orange-500/30">
              Ambikapur HQ
            </span>
          </h1>
          <p className="text-xs text-slate-400">
            Real-time operations, revenue monitoring & RTO fleet compliance
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportData}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition"
            title="Download full database JSON backup"
          >
            <Download className="w-3.5 h-3.5 text-orange-400" />
            <span>Database Backup</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex border-b border-slate-800 bg-slate-900/60 px-4 text-xs font-bold overflow-x-auto">
        <button
          onClick={() => setActiveAdminTab('overview')}
          className={`py-3 px-3 border-b-2 transition whitespace-nowrap ${
            activeAdminTab === 'overview'
              ? 'border-orange-500 text-orange-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {language === 'hi' ? 'अवलोकन व लाइव मैप' : 'Overview & Live Map'}
        </button>

        <button
          onClick={() => setActiveAdminTab('drivers')}
          className={`py-3 px-3 border-b-2 transition flex items-center gap-1.5 whitespace-nowrap ${
            activeAdminTab === 'drivers'
              ? 'border-orange-500 text-orange-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>{language === 'hi' ? 'ड्राइवर व KYC' : 'Drivers & KYC'}</span>
          {pendingDrivers.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-amber-500 text-slate-950 font-bold text-[10px]">
              {pendingDrivers.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveAdminTab('fares')}
          className={`py-3 px-3 border-b-2 transition whitespace-nowrap ${
            activeAdminTab === 'fares'
              ? 'border-orange-500 text-orange-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {language === 'hi' ? 'किराया व कमीशन' : 'Fares & Rates'}
        </button>

        <button
          onClick={() => setActiveAdminTab('sos')}
          className={`py-3 px-3 border-b-2 transition flex items-center gap-1.5 whitespace-nowrap ${
            activeAdminTab === 'sos'
              ? 'border-orange-500 text-orange-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>{language === 'hi' ? 'SOS अलर्ट्स' : 'SOS Emergency Logs'}</span>
          {sosAlerts.filter((s) => s.status === 'active').length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white font-bold text-[10px] animate-pulse">
              {sosAlerts.filter((s) => s.status === 'active').length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveAdminTab('promos')}
          className={`py-3 px-3 border-b-2 transition whitespace-nowrap ${
            activeAdminTab === 'promos'
              ? 'border-orange-500 text-orange-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          {language === 'hi' ? 'कूपन कोड्स' : 'Promo Codes'}
        </button>

        <button
          onClick={() => setActiveAdminTab('map_control')}
          className={`py-3 px-3 border-b-2 transition flex items-center gap-1.5 whitespace-nowrap ${
            activeAdminTab === 'map_control'
              ? 'border-orange-500 text-orange-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>{language === 'hi' ? 'मैप कंट्रोल व सीमाएं' : 'Map Control & Reports'}</span>
          {mapReports.filter((r) => r.status === 'pending').length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-orange-500 text-white font-bold text-[10px]">
              {mapReports.filter((r) => r.status === 'pending').length}
            </span>
          )}
        </button>
      </div>

      {/* Main Tab Panels */}
      <div className="flex-1 p-4 md:p-6 space-y-6">
        {activeAdminTab === 'overview' && (
          <div className="space-y-6">
            {/* KPI Metric Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Total Gross Revenue</span>
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                </div>
                <p className="text-2xl font-black text-emerald-400 mt-2">
                  ₹{adminStats.dailyRevenue.toLocaleString('en-IN')}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">
                  Commission Net: ₹{adminStats.platformProfit.toLocaleString('en-IN')}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Total Rides Completed</span>
                  <Car className="w-4 h-4 text-orange-400" />
                </div>
                <p className="text-2xl font-black text-white mt-2">
                  {adminStats.totalRides.toLocaleString('en-IN')}
                </p>
                <p className="text-[11px] text-emerald-400 mt-1">
                  {currentRide ? '1 Live Active Ride' : '0 In Progress'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Registered Drivers</span>
                  <Users className="w-4 h-4 text-blue-400" />
                </div>
                <p className="text-2xl font-black text-white mt-2">
                  {drivers.length} Pilots
                </p>
                <p className="text-[11px] text-slate-400 mt-1">
                  {drivers.filter((d) => d.isOnline).length} Currently Online
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800">
                <div className="flex items-center justify-between text-slate-400 text-xs">
                  <span>Registered Customers</span>
                  <Users className="w-4 h-4 text-purple-400" />
                </div>
                <p className="text-2xl font-black text-white mt-2">
                  {adminStats.totalCustomers.toLocaleString('en-IN')}
                </p>
                <p className="text-[11px] text-slate-400 mt-1">Across Surguja region</p>
              </div>
            </div>

            {/* Live City Fleet Map */}
            <div className="bg-slate-900 rounded-3xl border border-slate-800 overflow-hidden shadow-2xl">
              <div className="p-3.5 bg-slate-850 border-b border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
                  <h2 className="text-sm font-bold text-white">
                    Live Ambikapur City Fleet Map (OpenStreetMap)
                  </h2>
                </div>
                <span className="text-xs text-slate-400">
                  Showing active pilots across Ghadi Chowk, Ring Road & Railway Station
                </span>
              </div>
              <div className="h-[420px] w-full">
                <LiveRideMap showAllDrivers={true} />
              </div>
            </div>
          </div>
        )}

        {/* Drivers & KYC Approvals Tab */}
        {activeAdminTab === 'drivers' && (
          <div className="space-y-4">
            {/* Search */}
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={driverSearch}
                  onChange={(e) => setDriverSearch(e.target.value)}
                  placeholder="Search by driver name, vehicle plate (CG 15...) or phone..."
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>

            {/* Pending Approvals Spotlight */}
            {pendingDrivers.length > 0 && (
              <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl space-y-3">
                <h3 className="text-xs font-extrabold uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Pending KYC Document Verifications ({pendingDrivers.length})</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {pendingDrivers.map((d) => (
                    <div
                      key={d.id}
                      className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={d.photo}
                          alt={d.name}
                          className="w-11 h-11 rounded-xl object-cover border border-amber-500"
                        />
                        <div>
                          <p className="font-bold text-white text-xs">{d.name}</p>
                          <p className="text-[11px] text-amber-400 font-mono">{d.vehicleNumber}</p>
                          <p className="text-[10px] text-slate-400">
                            DL: {d.dlNumber} • Aadhaar: {d.aadhaarNumber}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => adminApproveDriver(d.id)}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition"
                        >
                          Approve
                        </button>
                        <button
                          onClick={() => adminRejectDriver(d.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition"
                        >
                          Reject
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* All Drivers Table */}
            <div className="bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-850 text-slate-400 uppercase text-[10px] font-bold border-b border-slate-800">
                    <tr>
                      <th className="p-3">Pilot Name</th>
                      <th className="p-3">Vehicle Details</th>
                      <th className="p-3">Rating</th>
                      <th className="p-3">KYC Status</th>
                      <th className="p-3">Duty Status</th>
                      <th className="p-3">Total Earnings</th>
                      <th className="p-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {filteredDrivers.map((d) => (
                      <tr key={d.id} className="hover:bg-slate-850/50">
                        <td className="p-3 font-semibold text-white flex items-center gap-2">
                          <img
                            src={d.photo}
                            alt={d.name}
                            className="w-7 h-7 rounded-full object-cover"
                          />
                          <span>{d.name}</span>
                        </td>
                        <td className="p-3 font-mono text-orange-400">
                          {d.vehicleNumber} ({d.vehicleModel})
                        </td>
                        <td className="p-3 text-amber-400 font-bold">★ {d.rating}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                              d.kycStatus === 'verified'
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                                : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                            }`}
                          >
                            {d.kycStatus}
                          </span>
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              d.isOnline ? 'text-emerald-400 bg-emerald-500/10' : 'text-slate-500 bg-slate-800'
                            }`}
                          >
                            {d.isOnline ? 'Online' : 'Offline'}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-white">₹{d.totalEarnings}</td>
                        <td className="p-3 text-right">
                          {d.kycStatus === 'verified' ? (
                            <button
                              onClick={() => adminRejectDriver(d.id)}
                              className="text-rose-400 hover:text-rose-300 font-bold"
                            >
                              Suspend
                            </button>
                          ) : (
                            <button
                              onClick={() => adminApproveDriver(d.id)}
                              className="text-emerald-400 hover:text-emerald-300 font-bold"
                            >
                              Approve
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Fare & Commission Setting Tab */}
        {activeAdminTab === 'fares' && (
          <div className="space-y-4">
            <div className="p-4 bg-slate-900 rounded-2xl border border-slate-800 flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-white">Platform Commission Structure</h3>
                <p className="text-xs text-slate-400 mt-0.5">Fixed 15% platform fee on all rides in Ambikapur</p>
              </div>
              <span className="text-2xl font-black text-orange-400">15.0%</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {vehicleOptions.map((v) => {
                const isEditing = editingFareCat === v.id;

                return (
                  <div key={v.id} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">
                          {v.id === 'bike' ? '🏍️' : v.id === 'auto' ? '🛺' : '🚗'}
                        </span>
                        <div>
                          <h4 className="font-bold text-white text-sm">{v.name}</h4>
                          <p className="text-[11px] text-slate-400">{v.tagline}</p>
                        </div>
                      </div>

                      {!isEditing && (
                        <button
                          onClick={() => {
                            setEditingFareCat(v.id);
                            setNewBase(v.baseFare);
                            setNewPerKm(v.perKmRate);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-orange-400"
                        >
                          Edit Rate
                        </button>
                      )}
                    </div>

                    {isEditing ? (
                      <div className="p-3 bg-slate-950 rounded-xl border border-orange-500/40 space-y-3">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">
                              Base Fare (₹)
                            </label>
                            <input
                              type="number"
                              value={newBase}
                              onChange={(e) => setNewBase(Number(e.target.value))}
                              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-slate-400 font-bold block mb-1">
                              Per KM Rate (₹)
                            </label>
                            <input
                              type="number"
                              value={newPerKm}
                              onChange={(e) => setNewPerKm(Number(e.target.value))}
                              className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white"
                            />
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <button
                            onClick={() => handleSaveFare(v.id)}
                            className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg"
                          >
                            Save Changes
                          </button>
                          <button
                            onClick={() => setEditingFareCat(null)}
                            className="px-3 py-1.5 bg-slate-800 text-slate-300 font-bold text-xs rounded-lg"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="grid grid-cols-3 gap-2 text-center text-xs pt-1">
                        <div className="p-2 bg-slate-950 rounded-xl border border-slate-800">
                          <span className="text-[10px] text-slate-400 block">Base Fare</span>
                          <span className="font-extrabold text-white">₹{v.baseFare}</span>
                        </div>
                        <div className="p-2 bg-slate-950 rounded-xl border border-slate-800">
                          <span className="text-[10px] text-slate-400 block">Rate / KM</span>
                          <span className="font-extrabold text-white">₹{v.perKmRate}</span>
                        </div>
                        <div className="p-2 bg-slate-950 rounded-xl border border-slate-800">
                          <span className="text-[10px] text-slate-400 block">Minimum</span>
                          <span className="font-extrabold text-white">₹{v.minFare}</span>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* SOS Emergency Logs Tab */}
        {activeAdminTab === 'sos' && (
          <div className="space-y-4">
            <div className="p-4 bg-rose-950/30 border border-rose-800/60 rounded-2xl flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-rose-500 animate-pulse" />
                <div>
                  <h3 className="text-sm font-bold text-white">Ambikapur Rapid SOS Response Console</h3>
                  <p className="text-xs text-slate-400">Integrated with 112 Emergency Dispatch</p>
                </div>
              </div>
              <span className="text-xs font-bold text-rose-400">
                {sosAlerts.filter((s) => s.status === 'active').length} Active Alerts
              </span>
            </div>

            {sosAlerts.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-xs bg-slate-900 rounded-2xl border border-slate-800">
                <CheckCircle className="w-8 h-8 mx-auto mb-2 text-emerald-500" />
                <p className="text-white font-bold">No Emergency Incidents Reported</p>
                <p className="text-slate-500 mt-0.5">All rides in Ambikapur are running safely.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {sosAlerts.map((sos) => (
                  <div
                    key={sos.id}
                    className="p-4 bg-slate-900 rounded-2xl border border-rose-500/40 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-white flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                        <span>Passenger: {sos.customerName} ({sos.customerPhone})</span>
                      </p>
                      <p className="text-slate-400 mt-1">
                        Vehicle: {sos.vehicleNumber || 'CG 15 AB 4821'} • Location: {sos.location.name}
                      </p>
                      <p className="text-amber-400 font-mono text-[11px] mt-0.5">
                        Coordinates: {sos.location.lat.toFixed(4)}, {sos.location.lng.toFixed(4)}
                      </p>
                    </div>

                    <div>
                      {sos.status === 'active' ? (
                        <button
                          onClick={() => resolveSos(sos.id)}
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                        >
                          Mark Resolved
                        </button>
                      ) : (
                        <span className="text-slate-500 font-semibold">Resolved</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Promo Codes Tab */}
        {activeAdminTab === 'promos' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {promoCodes.map((p) => (
                <div key={p.code} className="p-4 bg-slate-900 rounded-2xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-lg bg-orange-500/20 text-orange-400 font-mono font-black text-sm border border-orange-500/40">
                      {p.code}
                    </span>
                    <span className="text-xs font-bold text-emerald-400">
                      {p.discountPercent}% OFF
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 font-medium">{p.description}</p>
                  <p className="text-[10px] text-slate-500">
                    Max Discount: ₹{p.maxDiscount} • Min Ride: ₹{p.minRideAmount}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Map Control & Geographic Reports Tab */}
        {activeAdminTab === 'map_control' && (
          <div className="space-y-6">
            {/* Service Boundary Status */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>Ambikapur Licensed Service Zone</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                    Active (18 km radius)
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Boundaries: Gangapur (North), Darima Airport (South-East), Silphili (South), Mendra Kalan (South-West)
                </p>
              </div>
              <div className="flex gap-2 text-xs font-semibold">
                <span className="px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-300">
                  Municipal Area: 100% Mapped
                </span>
              </div>
            </div>

            {/* Vehicle Category Dispatch Availability */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
                Live Vehicle Availability & Dispatch Controls
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { id: 'bike', label: 'Bike Taxi', icon: '🏍️' },
                  { id: 'auto', label: 'Auto Rickshaw', icon: '🛺' },
                  { id: 'mini', label: 'Mini Cab', icon: '🚗' },
                  { id: 'sedan', label: 'Prime Sedan', icon: '🚘' },
                ].map((v) => {
                  const isEnabled = (vehicleAvailability as any)[v.id];
                  return (
                    <div
                      key={v.id}
                      className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{v.icon}</span>
                        <span className="text-xs font-bold text-white">{v.label}</span>
                      </div>
                      <button
                        onClick={() => {
                          setVehicleAvailability((prev) => ({
                            ...prev,
                            [v.id]: !isEnabled,
                          }));
                          playSound('beep');
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition ${
                          isEnabled
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {isEnabled ? 'ACTIVE' : 'PAUSED'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Community Map Reports & Missing Roads Console */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-400">
                    User & Driver Map Reports ({mapReports.length})
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Verification console for missing roads, new colonies, and traffic restrictions
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                {mapReports.map((report) => (
                  <div
                    key={report.id}
                    className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            report.issueType === 'missing_road'
                              ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                              : report.issueType === 'new_colony'
                              ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                              : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          }`}
                        >
                          {report.issueType.replace('_', ' ')}
                        </span>
                        <span className="font-bold text-white">{report.landmark}</span>
                      </div>
                      <p className="text-slate-300 mt-1">{report.description}</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        Reported by: {report.reporterName} • Lat: {report.coordinates.lat.toFixed(4)}, Lng: {report.coordinates.lng.toFixed(4)}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {report.status === 'pending' ? (
                        <>
                          <button
                            onClick={() => {
                              setMapReports((prev) =>
                                prev.map((r) =>
                                  r.id === report.id ? { ...r, status: 'approved' } : r
                                )
                              );
                              playSound('success');
                            }}
                            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition"
                          >
                            Approve into Map
                          </button>
                          <button
                            onClick={() => {
                              setMapReports((prev) =>
                                prev.map((r) =>
                                  r.id === report.id ? { ...r, status: 'rejected' } : r
                                )
                              );
                              playSound('beep');
                            }}
                            className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-rose-400 font-bold text-xs rounded-lg transition"
                          >
                            Reject
                          </button>
                        </>
                      ) : (
                        <span
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase ${
                            report.status === 'approved'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {report.status}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
