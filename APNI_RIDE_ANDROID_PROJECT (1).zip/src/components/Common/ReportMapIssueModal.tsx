import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { X, MapPin, AlertCircle, CheckCircle, Send, PlusCircle } from 'lucide-react';
import { playSound } from '../../utils/soundEffects';

interface ReportMapIssueModalProps {
  onClose: () => void;
  coordinates?: { lat: number; lng: number };
}

export const ReportMapIssueModal: React.FC<ReportMapIssueModalProps> = ({
  onClose,
  coordinates = { lat: 23.1235, lng: 83.1965 },
}) => {
  const { language } = useRide();
  const [issueType, setIssueType] = useState<'missing_road' | 'wrong_landmark' | 'closed_road' | 'new_colony'>('missing_road');
  const [landmarkName, setLandmarkName] = useState('');
  const [description, setDescription] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playSound('success');
    setSubmitted(true);
    setTimeout(() => {
      onClose();
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-[800] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-600/20 text-orange-400 flex items-center justify-center font-bold">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {language === 'hi' ? 'सड़क या स्थान की रिपोर्ट करें' : 'Report Map Issue / Missing Road'}
              </h2>
              <p className="text-[11px] text-slate-400">Ambikapur Open City Mapping</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {submitted ? (
          <div className="py-8 text-center space-y-3">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white">
              {language === 'hi' ? 'रिपोर्ट दर्ज कर ली गई है!' : 'Thank you for your report!'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'hi'
                ? 'हमारी टीम 24 घंटे में अम्बिकापुर मैप डेटा को अपडेट कर देगी।'
                : 'Our local GIS mapping team will verify and update the Ambikapur map database.'}
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5 pt-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {language === 'hi' ? 'समस्या का प्रकार' : 'Issue Category'}
              </label>
              <select
                value={issueType}
                onChange={(e) => setIssueType(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
              >
                <option value="missing_road">Missing Road / Lane / Gali (सड़क नहीं दिख रही)</option>
                <option value="new_colony">New Colony / Mohalla (नई कॉलोनी)</option>
                <option value="wrong_landmark">Incorrect Landmark / Shop Name (गलत नाम)</option>
                <option value="closed_road">Closed Road / Diversion (सड़क बंद या निर्माण)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {language === 'hi' ? 'कॉलोनी, मोहल्ला या स्थान का नाम' : 'Colony, Mohalla or Landmark Name'}
              </label>
              <input
                type="text"
                required
                value={landmarkName}
                onChange={(e) => setLandmarkName(e.target.value)}
                placeholder="e.g. Kedarpur Gali No 4, Ring Road Cut"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {language === 'hi' ? 'विवरण' : 'Details / Directions'}
              </label>
              <textarea
                required
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the missing road or correct name..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 resize-none"
              />
            </div>

            <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[11px] text-slate-400">
              <span className="font-semibold text-orange-400">Target Coordinates: </span>
              <span className="font-mono">{coordinates.lat.toFixed(5)}, {coordinates.lng.toFixed(5)}</span>
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-bold text-xs rounded-xl shadow shadow-orange-600/30 transition flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{language === 'hi' ? 'रिपोर्ट सबमिट करें' : 'Submit Map Report'}</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
