import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { PWAInstallButton } from './PWAInstallButton';
import { BrandLogoKitModal } from '../Brand/BrandLogoKitModal';
import {
  Car,
  Bike,
  Shield,
  Smartphone,
  Languages,
  DownloadCloud,
  Bell,
  MapPin,
  Sparkles,
} from 'lucide-react';

export const Header: React.FC = () => {
  const [showBrandKitModal, setShowBrandKitModal] = useState(false);
  const {
    language,
    setLanguage,
    activeRole,
    setActiveRole,
    isDevicePreview,
    setIsDevicePreview,
    setShowApkModal,
    currentRide,
    incomingRideRequest,
    currentDriver,
    sosAlerts,
  } = useRide();

  const activeSosCount = sosAlerts.filter((s) => s.status === 'active').length;

  return (
    <>
      <header className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 px-3 md:px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Brand & City Badge */}
          <div className="flex items-center gap-3">
            <div
              className="flex items-center gap-2 cursor-pointer group"
              onClick={() => setActiveRole('customer')}
              title="APNI RIDE - Home"
            >
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900 border border-blue-500/40 p-1 flex items-center justify-center shadow-lg shadow-blue-950/60 group-hover:scale-105 transition transform">
                <img src="/logo-icon-only.svg" alt="Apni Ride Logo" className="w-8 h-8 object-contain" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-base tracking-tight text-white">
                    APNI <span className="text-amber-400">RIDE</span>
                  </span>
                  <span className="text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    CG-15
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 flex items-center gap-1 font-medium">
                  <MapPin className="w-2.5 h-2.5 text-amber-400" />
                  Ambikapur, Chhattisgarh
                </p>
              </div>
            </div>
          </div>

        {/* Role Switcher (Customer / Driver / Admin) */}
        <div className="flex items-center bg-slate-900 p-1 rounded-2xl border border-slate-800 shadow-inner">
          <button
            onClick={() => setActiveRole('customer')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
              activeRole === 'customer'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Car className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? 'ग्राहक ऐप' : 'Customer'}</span>
            {currentRide && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            )}
          </button>

          <button
            onClick={() => setActiveRole('driver')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition relative ${
              activeRole === 'driver'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bike className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? 'ड्राइवर पार्टनर' : 'Driver'}</span>
            {currentDriver.isOnline && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            )}
            {incomingRideRequest && (
              <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-rose-600 text-[9px] font-bold text-white animate-bounce">
                1
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveRole('admin')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition relative ${
              activeRole === 'admin'
                ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>{language === 'hi' ? 'एडमिन' : 'Admin'}</span>
            {activeSosCount > 0 && (
              <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-rose-600 text-[9px] font-bold text-white animate-pulse">
                SOS
              </span>
            )}
          </button>
        </div>

        {/* Language, APK Download & Preview Actions */}
        <div className="flex items-center gap-2">
          {/* Language Toggle */}
          <button
            onClick={() => setLanguage(language === 'hi' ? 'en' : 'hi')}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 text-xs font-semibold transition"
            title="Switch Language"
          >
            <Languages className="w-3.5 h-3.5 text-orange-400" />
            <span>{language === 'hi' ? 'English' : 'हिन्दी'}</span>
          </button>

          {/* Android Phone Frame Mockup Toggle */}
          <button
            onClick={() => setIsDevicePreview((prev) => !prev)}
            className={`hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition ${
              isDevicePreview
                ? 'bg-orange-600/20 border-orange-500/50 text-orange-300'
                : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
            title="Toggle Android Device Frame"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>{isDevicePreview ? 'Phone' : 'Full'}</span>
          </button>

          {/* Official Brand Logo Kit Showcase Button */}
          <button
            onClick={() => setShowBrandKitModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-md shadow-blue-600/25 active:scale-95 transition"
            title="APNI RIDE Brand Identity & 6 Logo Formats"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span className="hidden sm:inline">Brand Kit</span>
          </button>

          {/* Download Android Project ZIP & APK Button */}
          <button
            onClick={() => setShowApkModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-md shadow-emerald-600/20 active:scale-95 transition"
            title="Download APNI_RIDE_ANDROID_PROJECT.zip & Android APK"
          >
            <DownloadCloud className="w-3.5 h-3.5 text-amber-200" />
            <span className="hidden xs:inline">Project ZIP / APK</span>
          </button>

          {/* PWA In-App Install Prompt */}
          <PWAInstallButton />
        </div>
      </div>
    </header>

    {/* Brand Logo Kit Modal */}
    <BrandLogoKitModal
      isOpen={showBrandKitModal}
      onClose={() => setShowBrandKitModal(false)}
    />
  </>
  );
};
