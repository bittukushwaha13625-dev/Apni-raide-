import React from 'react';
import { Wifi, Battery, Smartphone } from 'lucide-react';

interface DeviceFrameProps {
  children: React.ReactNode;
  enabled: boolean;
  onToggle: () => void;
}

export const DeviceFrame: React.FC<DeviceFrameProps> = ({ children, enabled, onToggle }) => {
  if (!enabled) {
    return <div className="h-full w-full">{children}</div>;
  }

  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] p-2 md:p-6 bg-slate-950/80">
      {/* Android Device Container */}
      <div className="relative w-full max-w-[412px] h-[860px] max-h-[92vh] bg-slate-900 rounded-[48px] p-3 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.9)] border-[6px] border-slate-700/80 flex flex-col overflow-hidden">
        {/* Device Side Buttons Styling */}
        <div className="absolute -left-[10px] top-28 w-[4px] h-14 bg-slate-600 rounded-l-md"></div>
        <div className="absolute -left-[10px] top-48 w-[4px] h-24 bg-slate-600 rounded-l-md"></div>
        <div className="absolute -right-[10px] top-36 w-[4px] h-20 bg-slate-600 rounded-r-md"></div>

        {/* Android Status Bar */}
        <div className="w-full h-8 px-6 flex items-center justify-between text-xs text-slate-300 font-medium select-none shrink-0 z-50 bg-slate-950/90 rounded-t-[36px]">
          <span className="font-semibold text-[13px]">{timeStr}</span>
          {/* Front Camera Notch */}
          <div className="w-3.5 h-3.5 rounded-full bg-black border border-slate-800 shadow-inner"></div>
          <div className="flex items-center gap-1.5 text-slate-400">
            <span className="text-[10px] font-bold text-orange-400">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <Battery className="w-4 h-4 text-emerald-400" />
          </div>
        </div>

        {/* Screen Content */}
        <div className="relative flex-1 w-full bg-slate-950 overflow-hidden flex flex-col">
          {children}
        </div>

        {/* Android Bottom Navigation Pill */}
        <div className="w-full h-6 flex items-center justify-center bg-slate-950 shrink-0 rounded-b-[36px]">
          <div className="w-32 h-1 bg-slate-500 rounded-full opacity-60 hover:opacity-100 transition-opacity"></div>
        </div>
      </div>

      {/* Frame Exit Bar */}
      <div className="mt-3 flex items-center gap-3 text-xs text-slate-400">
        <span>Android Phone Simulation Mode (412x860)</span>
        <button
          onClick={onToggle}
          className="text-orange-400 hover:text-orange-300 underline font-semibold flex items-center gap-1"
        >
          <Smartphone className="w-3.5 h-3.5" /> Exit Frame (Full Width)
        </button>
      </div>
    </div>
  );
};
