import React, { useState } from 'react';
import { LocationCategory, LocationPoint } from '../../types/ride';
import { useRide } from '../../context/RideContext';
import { AMBIKAPUR_LOCATIONS } from '../../data/ambikapurLocations';
import { searchLocalAmbikapur } from '../../services/geocodingService';
import {
  Search,
  MapPin,
  X,
  Navigation,
  Building2,
  Train,
  Hospital,
  Sparkles,
  School,
  Fuel,
  CreditCard,
  Church,
  TreePine,
} from 'lucide-react';

interface LocationPickerModalProps {
  type: 'pickup' | 'drop';
  currentPoint: LocationPoint;
  onSelect: (point: LocationPoint) => void;
  onClose: () => void;
  onChooseOnMap?: () => void;
}

export const LocationPickerModal: React.FC<LocationPickerModalProps> = ({
  type,
  currentPoint,
  onSelect,
  onClose,
  onChooseOnMap,
}) => {
  const { language } = useRide();
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<LocationCategory | 'all'>('all');

  const rawResults = query.trim() ? searchLocalAmbikapur(query) : AMBIKAPUR_LOCATIONS;

  const filtered = rawResults.filter((loc) => {
    if (selectedCategory === 'all') return true;
    return loc.category === selectedCategory;
  });

  const getCategoryIcon = (category: LocationCategory) => {
    switch (category) {
      case 'transit':
        return <Train className="w-4 h-4 text-amber-400" />;
      case 'hospital':
        return <Hospital className="w-4 h-4 text-rose-400" />;
      case 'commercial':
        return <Building2 className="w-4 h-4 text-blue-400" />;
      case 'school':
        return <School className="w-4 h-4 text-purple-400" />;
      case 'petrol':
        return <Fuel className="w-4 h-4 text-emerald-400" />;
      case 'bank':
        return <CreditCard className="w-4 h-4 text-cyan-400" />;
      case 'temple':
        return <span className="text-sm">🛕</span>;
      case 'village':
        return <TreePine className="w-4 h-4 text-lime-400" />;
      default:
        return <Sparkles className="w-4 h-4 text-orange-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-[600] flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh] animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div
              className={`w-3 h-3 rounded-full ${
                type === 'pickup' ? 'bg-emerald-500' : 'bg-rose-500'
              }`}
            />
            <h2 className="text-base font-bold text-white">
              {type === 'pickup'
                ? language === 'hi'
                  ? 'पिकअप स्थान चुनें'
                  : 'Select Pickup Location'
                : language === 'hi'
                ? 'ड्रॉप स्थान चुनें'
                : 'Select Drop Location'}
            </h2>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Input */}
        <div className="p-3 border-b border-slate-800/80 bg-slate-950/60">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                language === 'hi'
                  ? 'मोहल्ला, कॉलोनी, अस्पताल, पेट्रोल पंप, दुकान खोजें...'
                  : 'Search colony, mohalla, hospital, petrol pump, ATM in Ambikapur...'
              }
              className="w-full pl-10 pr-4 py-2.5 bg-slate-850 border border-slate-700 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 transition"
            />
          </div>

          {/* Category Chips Filter */}
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar pt-2.5">
            {[
              { id: 'all', label: 'All' },
              { id: 'mohalla', label: '🏘️ Mohallas & Colonies' },
              { id: 'hospital', label: '🏥 Hospitals' },
              { id: 'petrol', label: '⛽ Petrol' },
              { id: 'bank', label: '🏧 Banks / ATMs' },
              { id: 'transit', label: '🚆 Station & Bus Stand' },
              { id: 'school', label: '🏫 Colleges & Schools' },
              { id: 'temple', label: '🛕 Temples' },
              { id: 'village', label: '🌾 Suburbs' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as any)}
                className={`whitespace-nowrap px-2.5 py-1 rounded-full text-[11px] font-semibold transition ${
                  selectedCategory === cat.id
                    ? 'bg-orange-600 text-white'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Action Row: Use Current GPS / Tap on Map */}
        <div className="grid grid-cols-2 gap-2 p-2.5 border-b border-slate-800/60 bg-slate-950/40">
          <button
            onClick={() => {
              onSelect(currentPoint);
              onClose();
            }}
            className="flex items-center gap-2 p-2 rounded-xl bg-slate-850 hover:bg-slate-800 text-left transition group border border-slate-800"
          >
            <div className="w-7 h-7 rounded-lg bg-orange-600/20 text-orange-400 flex items-center justify-center shrink-0">
              <Navigation className="w-3.5 h-3.5" />
            </div>
            <div className="truncate">
              <p className="text-xs font-bold text-orange-400 truncate">
                {language === 'hi' ? 'वर्तमान GPS' : 'Current GPS'}
              </p>
              <p className="text-[10px] text-slate-400 truncate">Detect location</p>
            </div>
          </button>

          <button
            onClick={() => {
              if (onChooseOnMap) onChooseOnMap();
              onClose();
            }}
            className="flex items-center gap-2 p-2 rounded-xl bg-slate-850 hover:bg-slate-800 text-left transition group border border-slate-800"
          >
            <div className="w-7 h-7 rounded-lg bg-emerald-600/20 text-emerald-400 flex items-center justify-center shrink-0">
              <MapPin className="w-3.5 h-3.5" />
            </div>
            <div className="truncate">
              <p className="text-xs font-bold text-emerald-400 truncate">
                {language === 'hi' ? 'मैप पर चुनें' : 'Choose on Map'}
              </p>
              <p className="text-[10px] text-slate-400 truncate">Drag &amp; drop pin</p>
            </div>
          </button>
        </div>

        {/* Locations List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1 divide-y divide-slate-800/40">
          <p className="px-3 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            {language === 'hi' ? 'स्थान सूची (अम्बिकापुर)' : 'Ambikapur Directory'} ({filtered.length})
          </p>

          {filtered.map((loc) => {
            const isSelected = loc.id === currentPoint.id;
            return (
              <button
                key={loc.id}
                onClick={() => {
                  onSelect(loc);
                  onClose();
                }}
                className={`w-full flex items-start gap-3 p-2.5 rounded-xl text-left transition ${
                  isSelected
                    ? 'bg-orange-500/10 border border-orange-500/30'
                    : 'hover:bg-slate-800/60'
                }`}
              >
                <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                  {getCategoryIcon(loc.category)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-bold text-white truncate">
                      {language === 'hi' ? loc.nameHi : loc.name}
                    </p>
                    {loc.colony && (
                      <span className="text-[10px] text-orange-400 bg-orange-500/10 px-1.5 py-0.2 rounded font-semibold ml-2 shrink-0">
                        {loc.colony}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">
                    {language === 'hi' ? loc.addressHi : loc.address}
                  </p>
                </div>
              </button>
            );
          })}

          {filtered.length === 0 && (
            <div className="py-8 text-center text-slate-400 text-xs">
              {language === 'hi'
                ? 'कोई स्थान नहीं मिला। कृपया दूसरा नाम खोजें या मैप पर पिन रखें।'
                : 'No locations matched your search. Try another query or place pin on map.'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
