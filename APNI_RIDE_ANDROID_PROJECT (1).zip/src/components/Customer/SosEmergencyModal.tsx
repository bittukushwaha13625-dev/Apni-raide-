import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { ShieldAlert, Phone, Send, X, AlertTriangle, CheckCircle, Navigation } from 'lucide-react';

interface SosEmergencyModalProps {
  onClose: () => void;
}

export const SosEmergencyModal: React.FC<SosEmergencyModalProps> = ({ onClose }) => {
  const { currentRide, driverPosition, triggerSos, language } = useRide();
  const [beaconSent, setBeaconSent] = useState(false);

  const handleBroadcastSos = () => {
    triggerSos();
    setBeaconSent(true);
  };

  return (
    <div className="fixed inset-0 z-[800] flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-md p-0 sm:p-4">
      <div className="w-full max-w-md bg-gradient-to-b from-rose-950 via-slate-900 to-slate-950 border-2 border-rose-600 rounded-t-3xl sm:rounded-3xl shadow-[0_0_50px_rgba(225,29,72,0.4)] p-5 overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-rose-800/60">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-rose-600/30 text-rose-400 border border-rose-500 flex items-center justify-center animate-pulse">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-white">
                {language === 'hi' ? 'आपातकालीन सुरक्षा (SOS)' : 'Emergency SOS Center'}
              </h2>
              <p className="text-[11px] text-rose-300">Ambikapur Rapid Police Response</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800/80 text-slate-300 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 pt-4">
          {/* Warning banner */}
          <div className="p-3 bg-rose-900/30 border border-rose-600/50 rounded-xl flex items-start gap-2.5 text-xs text-rose-200">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-rose-300">
                {language === 'hi'
                  ? 'तत्काल सहायता हेतु 112 डायल करें'
                  : 'Instant Chhattisgarh Police Dispatch'}
              </p>
              <p className="text-[11px] text-slate-300 mt-0.5">
                {language === 'hi'
                  ? 'बटन दबाते ही आपकी लाइव जीपीएस लोकेशन व वाहन विवरण कंट्रोल रूम को भेज दिया जाएगा।'
                  : 'Triggering emergency alerts your live GPS coordinates, driver details, and vehicle number to authorities.'}
              </p>
            </div>
          </div>

          {/* Current ride details being transmitted */}
          {currentRide && (
            <div className="bg-slate-950/80 rounded-xl p-3 border border-slate-800 text-xs space-y-1">
              <p className="text-[10px] uppercase font-bold text-slate-400">Transmitted Incident Data</p>
              <p className="text-white font-semibold">
                Vehicle: {currentRide.driver?.vehicleNumber || 'CG 15 AB 4821'} ({currentRide.driver?.vehicleModel})
              </p>
              <p className="text-slate-300">Driver: {currentRide.driver?.name} ({currentRide.driver?.phone})</p>
              <p className="text-amber-400 font-mono text-[11px] flex items-center gap-1 mt-1">
                <Navigation className="w-3 h-3" />
                GPS: {driverPosition.lat.toFixed(4)}° N, {driverPosition.lng.toFixed(4)}° E (Ambikapur)
              </p>
            </div>
          )}

          {/* Quick SOS Calls */}
          <div className="grid grid-cols-2 gap-3">
            <a
              href="tel:112"
              className="p-3.5 rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-black text-center shadow-lg shadow-rose-600/40 transition flex flex-col items-center justify-center gap-1"
            >
              <Phone className="w-5 h-5 animate-bounce" />
              <span className="text-sm">Call 112 (Police)</span>
              <span className="text-[10px] font-normal opacity-90">Toll Free Response</span>
            </a>

            <a
              href="tel:+917774222044"
              className="p-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 active:scale-95 text-white font-bold text-center border border-slate-700 transition flex flex-col items-center justify-center gap-1"
            >
              <Phone className="w-5 h-5 text-orange-400" />
              <span className="text-xs">SP Office Ambikapur</span>
              <span className="text-[10px] text-slate-400">07774-222044</span>
            </a>
          </div>

          {/* Broadcast alert to Admin & Emergency contacts */}
          <div>
            {beaconSent ? (
              <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>
                  {language === 'hi'
                    ? 'अलर्ट प्रसारित हो गया है! एडमिन व टीम सक्रिय है।'
                    : 'SOS Beacon active! Admin Center has been alerted.'}
                </span>
              </div>
            ) : (
              <button
                onClick={handleBroadcastSos}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-600 to-rose-600 hover:from-amber-500 hover:to-rose-500 active:scale-95 text-white font-bold text-xs shadow transition flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>
                  {language === 'hi'
                    ? 'एडमिन व परिजनों को लाइव लोकेशन भेजें'
                    : 'Broadcast Live GPS Beacon to Admin'}
                </span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
