import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { LiveRideMap } from '../Map/LiveRideMap';
import { BookingPanel } from './BookingPanel';
import { ActiveRideTracker } from './ActiveRideTracker';
import { CustomerProfileModal } from './CustomerProfileModal';
import { SosEmergencyModal } from './SosEmergencyModal';
import { ShieldAlert, User, Bell, Sparkles } from 'lucide-react';

export const CustomerApp: React.FC = () => {
  const {
    currentRide,
    customer,
    language,
    setDraftPickup,
    setDraftDestination,
  } = useRide();
  const [showProfile, setShowProfile] = useState(false);
  const [showSos, setShowSos] = useState(false);

  return (
    <div className="relative h-full flex flex-col bg-slate-950 overflow-hidden">
      {/* Top Floating App Bar */}
      <div className="absolute top-3 left-3 right-3 z-30 flex items-center justify-between pointer-events-none">
        {/* Customer Mini Avatar Profile Pill */}
        <button
          onClick={() => setShowProfile(true)}
          className="pointer-events-auto flex items-center gap-2 bg-slate-900/90 backdrop-blur-md border border-slate-700/80 px-3 py-1.5 rounded-full shadow-lg text-xs font-semibold text-white hover:border-orange-500 transition active:scale-95"
        >
          <img
            src={customer.photo}
            alt={customer.name}
            className="w-6 h-6 rounded-full object-cover border border-orange-500"
          />
          <span className="hidden sm:inline">{customer.name.split(' ')[0]}</span>
          <span className="text-emerald-400 font-bold">₹{customer.walletBalance}</span>
        </button>

        {/* Floating Quick SOS Pill */}
        <button
          onClick={() => setShowSos(true)}
          className="pointer-events-auto flex items-center gap-1.5 bg-rose-600 hover:bg-rose-500 text-white px-3 py-1.5 rounded-full shadow-lg shadow-rose-600/40 text-xs font-extrabold active:scale-95 transition"
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>SOS 112</span>
        </button>
      </div>

      {/* Map View Area */}
      <div className="flex-1 relative min-h-[300px]">
        <LiveRideMap
          onSelectPickupFromMap={(point) => setDraftPickup(point)}
          onSelectDropFromMap={(point) => setDraftDestination(point)}
        />
      </div>

      {/* Bottom Floating Control Panel: Booking or Active Ride */}
      <div className="relative z-20 shrink-0">
        {currentRide ? <ActiveRideTracker /> : <BookingPanel />}
      </div>

      {/* Modals */}
      {showProfile && <CustomerProfileModal onClose={() => setShowProfile(false)} />}
      {showSos && <SosEmergencyModal onClose={() => setShowSos(false)} />}
    </div>
  );
};
