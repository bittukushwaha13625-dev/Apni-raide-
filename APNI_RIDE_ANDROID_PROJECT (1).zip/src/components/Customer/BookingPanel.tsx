import React, { useState } from 'react';
import { LocationPoint, PromoCode, VehicleCategory } from '../../types/ride';
import { useRide } from '../../context/RideContext';
import { LocationPickerModal } from './LocationPickerModal';
import {
  MapPin,
  ArrowUpDown,
  Tag,
  CreditCard,
  Banknote,
  Wallet,
  Clock,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  Check,
} from 'lucide-react';

export const BookingPanel: React.FC = () => {
  const {
    popularLocations,
    vehicleOptions,
    promoCodes,
    requestRide,
    language,
    customer,
    draftPickup,
    draftDestination,
    setDraftPickup,
    setDraftDestination,
  } = useRide();

  const pickup = draftPickup;
  const setPickup = setDraftPickup;
  const destination = draftDestination;
  const setDestination = setDraftDestination;

  const [selectedVehicle, setSelectedVehicle] = useState<VehicleCategory>('bike');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi' | 'wallet'>('upi');
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [promoInput, setPromoInput] = useState('');
  const [promoError, setPromoError] = useState('');
  const [showPromoBox, setShowPromoBox] = useState(false);

  // Modal states
  const [pickingType, setPickingType] = useState<'pickup' | 'drop' | null>(null);

  // Schedule later state
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledTime, setScheduledTime] = useState('Today, 10:30 PM');

  // Calculate rough distance
  const calculateDistanceKm = () => {
    const R = 6371;
    const dLat = ((destination.lat - pickup.lat) * Math.PI) / 180;
    const dLon = ((destination.lng - pickup.lng) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((pickup.lat * Math.PI) / 180) *
        Math.cos((destination.lat * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return Math.max(1.5, Number((R * c).toFixed(1)));
  };

  const distanceKm = calculateDistanceKm();

  // Fare calculations for selected vehicle
  const currentVehicleObj = vehicleOptions.find((v) => v.id === selectedVehicle) || vehicleOptions[0];
  const distanceFare = Math.round(distanceKm * currentVehicleObj.perKmRate);
  const baseFare = currentVehicleObj.baseFare;
  const rawFare = Math.max(currentVehicleObj.minFare, baseFare + distanceFare);
  const discountAmount = appliedPromo
    ? Math.min(appliedPromo.maxDiscount, Math.round((rawFare * appliedPromo.discountPercent) / 100))
    : 0;
  const finalFare = Math.max(15, rawFare - discountAmount);

  // Swap pickup & destination
  const handleSwapLocations = () => {
    const temp = pickup;
    setPickup(destination);
    setDestination(temp);
  };

  const handleApplyPromo = (code: string) => {
    const found = promoCodes.find((p) => p.code.toUpperCase() === code.trim().toUpperCase());
    if (found) {
      setAppliedPromo(found);
      setPromoError('');
    } else {
      setPromoError(language === 'hi' ? 'अमान्य कूपन कोड' : 'Invalid promo code');
    }
  };

  const handleBook = () => {
    requestRide(
      pickup,
      destination,
      selectedVehicle,
      paymentMethod,
      appliedPromo,
      isScheduled,
      isScheduled ? scheduledTime : undefined
    );
  };

  return (
    <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl shadow-2xl p-4 md:p-6 space-y-4 max-h-[82vh] overflow-y-auto">
      {/* Pickup & Drop Form */}
      <div className="bg-slate-950/80 rounded-2xl p-3 border border-slate-800 relative space-y-2">
        {/* Pickup button */}
        <div
          onClick={() => setPickingType('pickup')}
          className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-800/60 cursor-pointer transition group"
        >
          <div className="w-3.5 h-3.5 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20 shrink-0"></div>
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
              {language === 'hi' ? 'पिकअप (कहाँ से)' : 'Pickup'}
            </p>
            <p className="text-sm font-bold text-white truncate group-hover:text-orange-400 transition">
              {language === 'hi' ? pickup.nameHi : pickup.name}
            </p>
          </div>
        </div>

        {/* Divider & Swap Button */}
        <div className="relative border-t border-slate-800/80 my-1">
          <button
            onClick={handleSwapLocations}
            aria-label="Swap pickup and destination"
            className="absolute right-4 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center text-slate-300 hover:text-orange-400 transition shadow"
            title="Swap Locations"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Destination button */}
        <div
          onClick={() => setPickingType('drop')}
          className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-800/60 cursor-pointer transition group"
        >
          <div className="w-3.5 h-3.5 rounded-full bg-rose-500 ring-4 ring-rose-500/20 shrink-0"></div>
          <div className="flex-1 min-w-0">
            <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
              {language === 'hi' ? 'ड्रॉप (कहाँ तक)' : 'Destination'}
            </p>
            <p className="text-sm font-bold text-white truncate group-hover:text-orange-400 transition">
              {language === 'hi' ? destination.nameHi : destination.name}
            </p>
          </div>
        </div>
      </div>

      {/* Distance & Route preview bar */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span className="flex items-center gap-1.5 font-medium">
          <Clock className="w-3.5 h-3.5 text-orange-400" />
          {distanceKm} km • Est. {Math.round(distanceKm * 2.5)} mins
        </span>
        <button
          onClick={() => setIsScheduled(!isScheduled)}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold transition ${
            isScheduled
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              : 'bg-slate-800 text-slate-300 hover:text-white'
          }`}
        >
          <Clock className="w-3 h-3" />
          {isScheduled
            ? language === 'hi'
              ? 'शेड्यूल किया गया'
              : 'Scheduled'
            : language === 'hi'
            ? 'बाद के लिए शेड्यूल?'
            : 'Schedule Ride?'}
        </button>
      </div>

      {isScheduled && (
        <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center justify-between text-xs">
          <div>
            <p className="font-bold text-amber-300">
              {language === 'hi' ? 'राइड शेड्यूल का समय' : 'Scheduled Pickup Time'}
            </p>
            <p className="text-slate-300 mt-0.5">{scheduledTime}</p>
          </div>
          <select
            value={scheduledTime}
            onChange={(e) => setScheduledTime(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-white rounded-lg px-2 py-1 text-xs focus:outline-none"
          >
            <option value="Today, in 30 mins">In 30 mins</option>
            <option value="Today, in 1 hour">In 1 hour</option>
            <option value="Tomorrow Morning, 07:00 AM">Tomorrow 7:00 AM (Station train)</option>
            <option value="Tomorrow, 10:00 AM">Tomorrow 10:00 AM</option>
          </select>
        </div>
      )}

      {/* Vehicle Category Selector (Bike, Auto, Mini, Sedan) */}
      <div className="space-y-2">
        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          {language === 'hi' ? 'सवारी का प्रकार चुनें' : 'Choose Vehicle'}
        </p>
        <div className="grid grid-cols-2 gap-2.5">
          {vehicleOptions.map((v) => {
            const isSelected = selectedVehicle === v.id;
            const fareEst = Math.max(v.minFare, v.baseFare + Math.round(distanceKm * v.perKmRate));

            const getIcon = () => {
              if (v.id === 'bike') return '🏍️';
              if (v.id === 'auto') return '🛺';
              if (v.id === 'mini') return '🚗';
              return '🚘';
            };

            return (
              <div
                key={v.id}
                onClick={() => setSelectedVehicle(v.id)}
                className={`relative p-3 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-gradient-to-br from-orange-600/20 to-amber-600/10 border-orange-500 shadow-md shadow-orange-500/10 ring-1 ring-orange-500'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                {isSelected && (
                  <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-orange-500 flex items-center justify-center text-white">
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </div>
                )}
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-2xl">{getIcon()}</span>
                  <div>
                    <h3 className="font-bold text-xs text-white">
                      {language === 'hi' ? v.nameHi : v.name}
                    </h3>
                    <p className="text-[10px] text-emerald-400 font-semibold">{v.etaMinutes} min away</p>
                  </div>
                </div>

                <div className="flex items-baseline justify-between mt-2 pt-1 border-t border-slate-800/80">
                  <span className="text-[10px] text-slate-400">{v.capacity} Seat</span>
                  <span className="text-sm font-extrabold text-white">₹{fareEst}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Promo Code & Discounts */}
      <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800 text-xs">
        <div
          onClick={() => setShowPromoBox(!showPromoBox)}
          className="flex items-center justify-between cursor-pointer"
        >
          <div className="flex items-center gap-2 text-slate-200 font-semibold">
            <Tag className="w-4 h-4 text-orange-400" />
            <span>
              {appliedPromo
                ? `${appliedPromo.code} Applied (₹${discountAmount} OFF)`
                : language === 'hi'
                ? 'कूपन व ऑफर्स'
                : 'Offers & Promo Codes'}
            </span>
          </div>
          <ChevronRight
            className={`w-4 h-4 text-slate-400 transition-transform ${
              showPromoBox ? 'rotate-90' : ''
            }`}
          />
        </div>

        {showPromoBox && (
          <div className="mt-3 pt-3 border-t border-slate-800 space-y-2">
            <div className="flex gap-2">
              <input
                type="text"
                value={promoInput}
                onChange={(e) => setPromoInput(e.target.value)}
                placeholder="Enter promo code (e.g. APNI50)"
                className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white uppercase focus:outline-none focus:border-orange-500"
              />
              <button
                onClick={() => handleApplyPromo(promoInput)}
                className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-lg transition"
              >
                {language === 'hi' ? 'लागू करें' : 'Apply'}
              </button>
            </div>

            {promoError && <p className="text-rose-400 text-[11px]">{promoError}</p>}

            {/* Quick Promo Chips */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {promoCodes.map((p) => (
                <button
                  key={p.code}
                  onClick={() => handleApplyPromo(p.code)}
                  className={`px-2 py-1 rounded-md text-[10px] font-bold border transition ${
                    appliedPromo?.code === p.code
                      ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                      : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:border-orange-500'
                  }`}
                >
                  {p.code} • {p.discountPercent}% OFF
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Payment Method Selector */}
      <div className="space-y-1.5">
        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">
          {language === 'hi' ? 'भुगतान का तरीका' : 'Payment Mode'}
        </p>
        <div className="grid grid-cols-3 gap-2">
          <button
            onClick={() => setPaymentMethod('upi')}
            className={`p-2.5 rounded-xl border text-center transition ${
              paymentMethod === 'upi'
                ? 'bg-orange-600/20 border-orange-500 text-orange-300 font-bold'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <CreditCard className="w-4 h-4 mx-auto mb-1 text-orange-400" />
            <span className="text-[11px] block">UPI / QR</span>
          </button>

          <button
            onClick={() => setPaymentMethod('cash')}
            className={`p-2.5 rounded-xl border text-center transition ${
              paymentMethod === 'cash'
                ? 'bg-orange-600/20 border-orange-500 text-orange-300 font-bold'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Banknote className="w-4 h-4 mx-auto mb-1 text-emerald-400" />
            <span className="text-[11px] block">{language === 'hi' ? 'कैश' : 'Cash'}</span>
          </button>

          <button
            onClick={() => setPaymentMethod('wallet')}
            className={`p-2.5 rounded-xl border text-center transition ${
              paymentMethod === 'wallet'
                ? 'bg-orange-600/20 border-orange-500 text-orange-300 font-bold'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            <Wallet className="w-4 h-4 mx-auto mb-1 text-yellow-400" />
            <span className="text-[11px] block">₹{customer.walletBalance} Wallet</span>
          </button>
        </div>
      </div>

      {/* Final Action & Fare Breakdown Button */}
      <div className="pt-2">
        <button
          onClick={handleBook}
          className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-orange-600 via-amber-600 to-orange-600 hover:from-orange-500 hover:to-amber-500 active:scale-[0.98] transition shadow-lg shadow-orange-600/30 flex items-center justify-between text-white font-extrabold text-base"
        >
          <div className="text-left">
            <span className="block text-xs uppercase opacity-90 font-medium">
              {isScheduled
                ? language === 'hi'
                  ? 'शेड्यूल कन्फर्म करें'
                  : 'Confirm Scheduled Ride'
                : language === 'hi'
                ? 'अभी राइड बुक करें'
                : 'Book Apni Ride'}
            </span>
            <span className="text-sm font-semibold text-amber-200">
              {currentVehicleObj.name}
            </span>
          </div>

          <div className="text-right">
            {discountAmount > 0 && (
              <span className="line-through text-xs text-orange-200 mr-2">
                ₹{rawFare}
              </span>
            )}
            <span className="text-xl font-black">₹{finalFare}</span>
          </div>
        </button>
      </div>

      {/* Safety Assurance Badge */}
      <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 pt-1">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
        <span>100% Police Verified Drivers • SOS Emergency Protected</span>
      </div>

      {/* Location Picker Modals */}
      {pickingType && (
        <LocationPickerModal
          type={pickingType}
          currentPoint={pickingType === 'pickup' ? pickup : destination}
          onSelect={(point) => {
            if (pickingType === 'pickup') {
              setPickup(point);
            } else {
              setDestination(point);
            }
          }}
          onClose={() => setPickingType(null)}
        />
      )}
    </div>
  );
};
