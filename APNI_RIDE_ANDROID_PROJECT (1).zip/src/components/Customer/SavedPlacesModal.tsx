import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { LocationPoint, SavedPlace } from '../../types/ride';
import { X, Home, Briefcase, Heart, Plus, MapPin, CheckCircle, Clock } from 'lucide-react';
import { playSound } from '../../utils/soundEffects';

interface SavedPlacesModalProps {
  onClose: () => void;
  onSelectPlace: (location: LocationPoint) => void;
}

export const SavedPlacesModal: React.FC<SavedPlacesModalProps> = ({
  onClose,
  onSelectPlace,
}) => {
  const { language, popularLocations } = useRide();

  // Mock initial saved places in Ambikapur
  const [savedPlaces, setSavedPlaces] = useState<SavedPlace[]>([
    {
      id: 'sp-home',
      type: 'home',
      title: 'Home',
      titleHi: 'घर (दर्रीपारा)',
      location: popularLocations.find((l) => l.id === 'darripara-main') || popularLocations[0],
    },
    {
      id: 'sp-work',
      type: 'work',
      title: 'Work / Office',
      titleHi: 'ऑफिस (मेडिकल कॉलेज)',
      location: popularLocations.find((l) => l.id === 'medical-college') || popularLocations[1],
    },
    {
      id: 'sp-fav',
      type: 'favorite',
      title: 'Maa Mahamaya Mandir',
      titleHi: 'माँ महामाया मंदिर',
      location: popularLocations.find((l) => l.id === 'mahamaya-mandir') || popularLocations[2],
    },
  ]);

  const [recentLocations] = useState<LocationPoint[]>([
    popularLocations.find((l) => l.id === 'ghadi-chowk') || popularLocations[0],
    popularLocations.find((l) => l.id === 'prateeksha-bus-stand') || popularLocations[1],
    popularLocations.find((l) => l.id === 'railway-station') || popularLocations[2],
  ]);

  const getIcon = (type: SavedPlace['type']) => {
    switch (type) {
      case 'home':
        return <Home className="w-4 h-4 text-emerald-400" />;
      case 'work':
        return <Briefcase className="w-4 h-4 text-blue-400" />;
      default:
        return <Heart className="w-4 h-4 text-rose-400 fill-rose-400" />;
    }
  };

  return (
    <div className="fixed inset-0 z-[700] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-600/20 text-orange-400 flex items-center justify-center font-bold">
              <MapPin className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {language === 'hi' ? 'सहेजे गए स्थान व इतिहास' : 'Saved Places & Recent'}
              </h2>
              <p className="text-[11px] text-slate-400">Quick 1-tap pickup in Ambikapur</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 pt-4 overflow-y-auto max-h-[65vh]">
          {/* Saved Places List */}
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2">
              {language === 'hi' ? 'सहेजे गए पसंदीदा पते' : 'Saved Addresses'}
            </p>
            <div className="space-y-2">
              {savedPlaces.map((sp) => (
                <button
                  key={sp.id}
                  onClick={() => {
                    onSelectPlace(sp.location);
                    playSound('beep');
                    onClose();
                  }}
                  className="w-full flex items-center gap-3 p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-orange-500 text-left transition group"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center shrink-0 group-hover:scale-105 transition">
                    {getIcon(sp.type)}
                  </div>
                  <div className="flex-1 truncate">
                    <p className="text-xs font-bold text-white group-hover:text-orange-400 transition truncate">
                      {language === 'hi' ? sp.titleHi : sp.title}
                    </p>
                    <p className="text-[11px] text-slate-400 truncate">
                      {language === 'hi' ? sp.location.addressHi : sp.location.address}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Recent Location History */}
          <div>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-orange-400" />
              <span>{language === 'hi' ? 'हाल ही में खोजे गए स्थान' : 'Recent Location History'}</span>
            </p>
            <div className="space-y-1.5">
              {recentLocations.map((loc) => (
                <button
                  key={loc.id}
                  onClick={() => {
                    onSelectPlace(loc);
                    playSound('beep');
                    onClose();
                  }}
                  className="w-full flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-950/60 hover:bg-slate-800 text-left transition"
                >
                  <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  <div className="truncate">
                    <p className="text-xs font-semibold text-slate-200 truncate">
                      {language === 'hi' ? loc.nameHi : loc.name}
                    </p>
                    <p className="text-[10px] text-slate-500 truncate">{loc.address}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
