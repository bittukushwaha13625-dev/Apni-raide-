import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { X, CheckCircle, QrCode, ShieldCheck, Banknote, Smartphone, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { playSound } from '../../utils/soundEffects';

interface PaymentModalProps {
  onClose: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ onClose }) => {
  const { currentRide, language, resetRide } = useRide();
  const [selectedGateway, setSelectedGateway] = useState<'upi' | 'gpay' | 'phonepe' | 'paytm' | 'cash'>('upi');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!currentRide) return null;

  const fare = currentRide.finalFare;

  const handlePay = () => {
    setIsProcessing(true);
    playSound('beep');

    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
      playSound('complete');
      try {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-[750] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-600/20 text-orange-400 flex items-center justify-center font-bold">
              ₹
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {language === 'hi' ? 'सुरक्षित भुगतान' : 'Secure Ride Checkout'}
              </h2>
              <p className="text-[11px] text-slate-400">
                {language === 'hi' ? 'अम्बिकापुर राइड # ' : 'Ride ID: '}
                {currentRide.id}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isSuccess ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-white">
                {language === 'hi' ? 'भुगतान सफल रहा!' : 'Payment Received!'}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                {language === 'hi'
                  ? `₹${fare} का भुगतान सफलतापूर्वक हो चुका है।`
                  : `₹${fare} has been successfully settled.`}
              </p>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300">
              <p className="font-semibold text-emerald-400">Transaction ID: UPI/AR/2026/{currentRide.id}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">Paid to: APNI RIDE MOBILITY LLP • AMBIKAPUR</p>
            </div>
            <button
              onClick={() => {
                onClose();
                resetRide();
              }}
              className="w-full py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold rounded-xl transition"
            >
              {language === 'hi' ? 'होम स्क्रीन पर जाएं' : 'Back to Home'}
            </button>
          </div>
        ) : (
          <div className="space-y-4 pt-3">
            {/* Bill breakdown */}
            <div className="bg-slate-950/80 rounded-2xl p-3 border border-slate-800 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-400">
                <span>Base Fare</span>
                <span>₹{currentRide.baseFare}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Distance Charge ({currentRide.distanceKm} km)</span>
                <span>₹{currentRide.distanceFare}</span>
              </div>
              {currentRide.discountAmount > 0 && (
                <div className="flex justify-between text-emerald-400 font-semibold">
                  <span>Special Promo Discount</span>
                  <span>- ₹{currentRide.discountAmount}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-400 pt-1 border-t border-slate-800">
                <span>GST & Surguja Road Safety Cess</span>
                <span className="text-emerald-400 font-medium">Included</span>
              </div>
              <div className="flex justify-between text-white font-bold text-sm pt-1 border-t border-slate-700">
                <span>Total Amount Payable</span>
                <span className="text-orange-400 text-base font-extrabold">₹{fare}</span>
              </div>
            </div>

            {/* UPI QR Simulation */}
            <div className="bg-gradient-to-br from-slate-950 to-slate-900 rounded-2xl p-4 border border-slate-800 text-center space-y-2">
              <div className="inline-block p-2 bg-white rounded-xl shadow-inner">
                {/* Visual SVG QR representation */}
                <div className="w-28 h-28 grid grid-cols-6 grid-rows-6 gap-1 p-1 bg-white">
                  <div className="bg-slate-950 rounded-xs col-span-2 row-span-2"></div>
                  <div className="bg-slate-950 rounded-xs col-span-2"></div>
                  <div className="bg-slate-950 rounded-xs col-span-2 row-span-2"></div>
                  <div className="bg-slate-950 rounded-xs"></div>
                  <div className="bg-orange-600 rounded-xs col-span-2"></div>
                  <div className="bg-slate-950 rounded-xs"></div>
                  <div className="bg-slate-950 rounded-xs col-span-2 row-span-2"></div>
                  <div className="bg-slate-950 rounded-xs"></div>
                  <div className="bg-orange-600 rounded-xs"></div>
                  <div className="bg-slate-950 rounded-xs col-span-2 row-span-2"></div>
                </div>
              </div>
              <p className="text-[11px] font-bold text-slate-300">
                Scan with any UPI App (GPay / PhonePe / Paytm / BHIM)
              </p>
              <p className="text-[10px] text-slate-500">UPI ID: apniride.ambikapur@icici</p>
            </div>

            {/* Quick App Select */}
            <div className="grid grid-cols-4 gap-2">
              <button
                onClick={() => setSelectedGateway('gpay')}
                className={`p-2 rounded-xl border text-center transition ${
                  selectedGateway === 'gpay'
                    ? 'bg-blue-600/20 border-blue-500 text-blue-300 font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <Smartphone className="w-4 h-4 mx-auto mb-1 text-blue-400" />
                <span className="text-[10px] block">GPay</span>
              </button>

              <button
                onClick={() => setSelectedGateway('phonepe')}
                className={`p-2 rounded-xl border text-center transition ${
                  selectedGateway === 'phonepe'
                    ? 'bg-purple-600/20 border-purple-500 text-purple-300 font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <Smartphone className="w-4 h-4 mx-auto mb-1 text-purple-400" />
                <span className="text-[10px] block">PhonePe</span>
              </button>

              <button
                onClick={() => setSelectedGateway('paytm')}
                className={`p-2 rounded-xl border text-center transition ${
                  selectedGateway === 'paytm'
                    ? 'bg-cyan-600/20 border-cyan-500 text-cyan-300 font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <Smartphone className="w-4 h-4 mx-auto mb-1 text-cyan-400" />
                <span className="text-[10px] block">Paytm</span>
              </button>

              <button
                onClick={() => setSelectedGateway('cash')}
                className={`p-2 rounded-xl border text-center transition ${
                  selectedGateway === 'cash'
                    ? 'bg-emerald-600/20 border-emerald-500 text-emerald-300 font-bold'
                    : 'bg-slate-950 border-slate-800 text-slate-400'
                }`}
              >
                <Banknote className="w-4 h-4 mx-auto mb-1 text-emerald-400" />
                <span className="text-[10px] block">Cash</span>
              </button>
            </div>

            {/* Pay Button */}
            <button
              onClick={handlePay}
              disabled={isProcessing}
              className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-50 text-white font-extrabold text-sm rounded-xl transition shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  <span>Verifying UPI Gateway...</span>
                </>
              ) : (
                <>
                  <ShieldCheck className="w-4 h-4" />
                  <span>
                    {selectedGateway === 'cash'
                      ? language === 'hi'
                        ? `ड्राइवर को ₹${fare} नकद दें`
                        : `Confirm Cash to Driver (₹${fare})`
                      : language === 'hi'
                      ? `₹${fare} का भुगतान करें`
                      : `Complete Payment (₹${fare})`}
                  </span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
