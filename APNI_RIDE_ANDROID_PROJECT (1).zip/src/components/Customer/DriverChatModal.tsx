import React, { useState, useEffect, useRef } from 'react';
import { useRide } from '../../context/RideContext';
import { X, Send, Phone, User, CheckCheck } from 'lucide-react';

interface DriverChatModalProps {
  onClose: () => void;
}

export const DriverChatModal: React.FC<DriverChatModalProps> = ({ onClose }) => {
  const { currentRide, chatMessages, sendChatMessage, language } = useRide();
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    sendChatMessage('customer', inputText);
    setInputText('');
  };

  const quickReplies = [
    language === 'hi' ? 'मैं मुख्य गेट पर खड़ा हूँ' : "I'm at the main gate",
    language === 'hi' ? '₹500 का खुला छुट्टा है क्या?' : 'Do you have change for 500?',
    language === 'hi' ? 'कृपया जल्दी आएं' : 'Please arrive quickly',
    language === 'hi' ? 'गाड़ी का नंबर दिख रहा है' : 'I can see your vehicle',
  ];

  return (
    <div className="fixed inset-0 z-[700] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col h-[75vh] max-h-[640px] overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Chat Header */}
        <div className="p-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <img
              src={
                currentRide?.driver?.photo ||
                'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80'
              }
              alt={currentRide?.driver?.name}
              className="w-10 h-10 rounded-full object-cover border-2 border-orange-500"
            />
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-1.5">
                {currentRide?.driver?.name || 'Driver Partner'}
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              </h2>
              <p className="text-xs text-orange-400 font-semibold">
                {currentRide?.driver?.vehicleNumber} • {currentRide?.driver?.vehicleModel}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={`tel:${currentRide?.driver?.phone || '+919826145892'}`}
              className="w-8 h-8 rounded-full bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center hover:bg-emerald-600 hover:text-white transition"
              title="Call Driver"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              onClick={onClose}
              aria-label="Close"
              className="w-8 h-8 rounded-full bg-slate-800 text-slate-300 hover:text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-950/60">
          <div className="text-center my-2">
            <span className="text-[10px] text-slate-400 bg-slate-900 border border-slate-800 px-3 py-1 rounded-full">
              {language === 'hi'
                ? 'सुरक्षा हेतु सभी चैट्स एन्क्रिप्टेड हैं'
                : 'End-to-end encrypted for ride safety'}
            </span>
          </div>

          {chatMessages.map((msg) => {
            const isMe = msg.sender === 'customer';
            const timeStr = new Date(msg.timestamp).toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm shadow ${
                    isMe
                      ? 'bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-br-xs'
                      : 'bg-slate-850 border border-slate-700/80 text-slate-200 rounded-bl-xs'
                  }`}
                >
                  <p>{msg.text}</p>
                  <div
                    className={`flex items-center justify-end gap-1 mt-1 text-[10px] ${
                      isMe ? 'text-amber-200' : 'text-slate-400'
                    }`}
                  >
                    <span>{timeStr}</span>
                    {isMe && <CheckCheck className="w-3 h-3 text-amber-200" />}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-2 bg-slate-900/90 border-t border-slate-800 flex gap-1.5 overflow-x-auto no-scrollbar">
          {quickReplies.map((qr, idx) => (
            <button
              key={idx}
              onClick={() => {
                sendChatMessage('customer', qr);
              }}
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-300 active:scale-95 transition"
            >
              {qr}
            </button>
          ))}
        </div>

        {/* Input box */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={
              language === 'hi' ? 'ड्राइवर को संदेश भेजें...' : 'Type message to driver...'
            }
            className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-orange-500"
          />
          <button
            onClick={handleSend}
            disabled={!inputText.trim()}
            className="w-10 h-10 rounded-xl bg-orange-600 hover:bg-orange-500 disabled:opacity-40 disabled:cursor-not-allowed text-white flex items-center justify-center transition shadow shadow-orange-600/30"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
