import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { Star, ThumbsUp, X, Check, Heart } from 'lucide-react';

interface RideRatingModalProps {
  onClose: () => void;
}

export const RideRatingModal: React.FC<RideRatingModalProps> = ({ onClose }) => {
  const { currentRide, rateRide, resetRide, language } = useRide();
  const [rating, setRating] = useState(5);
  const [review, setReview] = useState('');
  const [tip, setTip] = useState<number>(0);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isSubmitted, setIsSubmitted] = useState(false);

  if (!currentRide) return null;

  const tags = [
    language === 'hi' ? 'सुरक्षित ड्राइविंग' : 'Safe Driving',
    language === 'hi' ? 'साफ-सुथरी गाड़ी' : 'Clean Vehicle',
    language === 'hi' ? 'समय पर आगमन' : 'On-Time Arrival',
    language === 'hi' ? 'विनम्र व्यवहार' : 'Polite Pilot',
    language === 'hi' ? 'सही रास्ता चुना' : 'Great Route',
  ];

  const toggleTag = (t: string) => {
    if (selectedTags.includes(t)) {
      setSelectedTags(selectedTags.filter((x) => x !== t));
    } else {
      setSelectedTags([...selectedTags, t]);
    }
  };

  const handleSubmit = () => {
    rateRide(currentRide.id, rating, review);
    setIsSubmitted(true);
    setTimeout(() => {
      onClose();
      resetRide();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-[700] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 overflow-hidden animate-in slide-in-from-bottom duration-200">
        <div className="flex justify-between items-center pb-2 border-b border-slate-800">
          <h2 className="text-base font-bold text-white">
            {language === 'hi' ? 'अपनी यात्रा का अनुभव बताएं' : 'Rate Your Ride Experience'}
          </h2>
          <button
            onClick={() => {
              onClose();
              resetRide();
            }}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {isSubmitted ? (
          <div className="py-8 text-center space-y-2">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <p className="text-sm font-bold text-white">
              {language === 'hi' ? 'प्रतिक्रिया के लिए धन्यवाद!' : 'Thank you for your rating!'}
            </p>
            <p className="text-xs text-slate-400">
              {language === 'hi'
                ? 'आपकी राय से हमें अम्बिकापुर में सेवा बेहतर बनाने में मदद मिलती है।'
                : 'Your feedback helps improve Apni Ride service across Ambikapur.'}
            </p>
          </div>
        ) : (
          <div className="space-y-4 pt-3 text-center">
            {/* Driver avatar & info */}
            <div>
              <img
                src={
                  currentRide.driver?.photo ||
                  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80'
                }
                alt="Driver"
                className="w-16 h-16 rounded-full mx-auto object-cover border-2 border-orange-500 shadow-md"
              />
              <h3 className="font-bold text-white text-sm mt-2">
                {currentRide.driver?.name || 'Driver Partner'}
              </h3>
              <p className="text-xs text-slate-400">
                {currentRide.driver?.vehicleNumber} • {currentRide.driver?.vehicleModel}
              </p>
            </div>

            {/* Star selector */}
            <div className="flex justify-center gap-2 py-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  className="p-1 text-2xl transition hover:scale-125"
                >
                  <Star
                    className={`w-7 h-7 ${
                      star <= rating
                        ? 'text-amber-400 fill-amber-400'
                        : 'text-slate-700'
                    }`}
                  />
                </button>
              ))}
            </div>

            {/* Compliment badges */}
            <div className="flex flex-wrap justify-center gap-1.5">
              {tags.map((t) => (
                <button
                  key={t}
                  onClick={() => toggleTag(t)}
                  className={`px-2.5 py-1 rounded-full text-xs border transition ${
                    selectedTags.includes(t)
                      ? 'bg-orange-600/30 border-orange-500 text-orange-300 font-semibold'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {/* Optional Driver Tip */}
            <div className="p-2 bg-slate-950/60 rounded-xl border border-slate-800">
              <p className="text-[11px] text-slate-400 flex items-center justify-center gap-1 mb-1.5">
                <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
                <span>Tip for Driver Partner (Optional)</span>
              </p>
              <div className="flex justify-center gap-2">
                {[0, 10, 20, 50].map((amt) => (
                  <button
                    key={amt}
                    onClick={() => setTip(amt)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                      tip === amt
                        ? 'bg-orange-500 text-white'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {amt === 0 ? 'No Tip' : `+₹${amt}`}
                  </button>
                ))}
              </div>
            </div>

            {/* Comments input */}
            <textarea
              value={review}
              onChange={(e) => setReview(e.target.value)}
              placeholder={
                language === 'hi'
                  ? 'कोई अतिरिक्त सुझाव या अनुभव लिखें...'
                  : 'Write additional feedback...'
              }
              rows={2}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-orange-500 resize-none"
            />

            <button
              onClick={handleSubmit}
              className="w-full py-3 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white font-extrabold text-sm rounded-xl transition shadow-lg shadow-orange-600/30"
            >
              {language === 'hi' ? 'रेटिंग सबमिट करें' : 'Submit Review'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
