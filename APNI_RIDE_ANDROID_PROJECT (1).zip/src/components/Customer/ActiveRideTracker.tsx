import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { DriverChatModal } from './DriverChatModal';
import { PaymentModal } from './PaymentModal';
import { RideRatingModal } from './RideRatingModal';
import { SosEmergencyModal } from './SosEmergencyModal';
import {
  Phone,
  MessageSquare,
  ShieldAlert,
  XCircle,
  KeyRound,
  CreditCard,
  Star,
  CheckCircle2,
  Clock,
  Sparkles,
  MapPin,
} from 'lucide-react';

export const ActiveRideTracker: React.FC = () => {
  const { currentRide, cancelRide, language, resetRide } = useRide();

  const [showChat, setShowChat] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [showRating, setShowRating] = useState(false);
  const [showSos, setShowSos] = useState(false);
  const [confirmCancel, setConfirmCancel] = useState(false);

  if (!currentRide) return null;

  const status = currentRide.status;

  // Searching State
  if (status === 'SEARCHING') {
    return (
      <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl shadow-2xl p-5 text-center space-y-4 animate-in slide-in-from-bottom duration-200">
        <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-40"></span>
          <div className="relative w-16 h-16 rounded-full bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center text-3xl shadow-lg shadow-orange-500/30">
            {currentRide.vehicleCategory === 'bike' ? '🏍️' : currentRide.vehicleCategory === 'auto' ? '🛺' : '🚗'}
          </div>
        </div>

        <div>
          <h3 className="text-base font-extrabold text-white">
            {language === 'hi'
              ? 'नजदीकी ड्राइवर से कनेक्ट किया जा रहा है...'
              : 'Connecting to Nearby Driver...'}
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'hi'
              ? 'अम्बिकापुर में उपलब्ध बाइक, ऑटो व कैब को सिग्नल भेजा गया है'
              : 'Broadcasting to registered pilots in Ambikapur (3 km radius)'}
          </p>
        </div>

        {/* Route summary chip */}
        <div className="bg-slate-950/80 rounded-xl p-3 border border-slate-800 text-xs text-left space-y-1">
          <div className="flex items-center gap-2 text-slate-300 truncate">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0"></span>
            <span className="truncate">{currentRide.pickup.name}</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300 truncate">
            <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0"></span>
            <span className="truncate">{currentRide.destination.name}</span>
          </div>
          <div className="pt-1 flex justify-between text-slate-400 font-semibold border-t border-slate-800/80">
            <span>Est. Fare: ₹{currentRide.finalFare}</span>
            <span>{currentRide.distanceKm} km</span>
          </div>
        </div>

        <button
          onClick={() => cancelRide('Customer cancelled while searching')}
          className="text-xs text-rose-400 hover:text-rose-300 font-semibold py-2"
        >
          {language === 'hi' ? 'खोज बंद करें (कैंसिल)' : 'Cancel Search'}
        </button>
      </div>
    );
  }

  // Active or Completed State
  return (
    <>
      <div className="bg-slate-900 border-t border-slate-800 rounded-t-3xl shadow-2xl p-4 md:p-5 space-y-3.5 animate-in slide-in-from-bottom duration-200">
        {/* Status header banner */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-400">
              {status === 'ARRIVING' && (language === 'hi' ? 'ड्राइवर आ रहा है' : 'Driver Arriving')}
              {status === 'ARRIVED' && (language === 'hi' ? 'ड्राइवर पिकअप पर है' : 'Driver at Pickup')}
              {status === 'IN_PROGRESS' && (language === 'hi' ? 'सफर जारी है' : 'Trip in Progress')}
              {status === 'COMPLETED' && (language === 'hi' ? 'यात्रा पूर्ण!' : 'Trip Completed!')}
            </span>
          </div>

          {/* SOS button */}
          <button
            onClick={() => setShowSos(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-600/20 border border-rose-500/40 text-rose-400 text-xs font-bold active:scale-95 transition"
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>SOS</span>
          </button>
        </div>

        {/* 4-digit PIN Security Card (Passenger safety verification) */}
        {status !== 'COMPLETED' && (
          <div className="bg-gradient-to-r from-orange-600/20 to-amber-600/20 border border-orange-500/40 rounded-2xl p-3 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-orange-600/30 text-orange-400 flex items-center justify-center">
                <KeyRound className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[11px] text-slate-300">
                  {language === 'hi' ? 'सफर शुरू करने का गुप्त कोड' : 'Start Ride Safety PIN'}
                </p>
                <p className="text-[10px] text-slate-400">
                  {language === 'hi' ? 'सवारी शुरू होने पर ड्राइवर को बताएं' : 'Share with pilot at pickup'}
                </p>
              </div>
            </div>
            <div className="text-right">
              <span className="font-mono text-2xl font-black text-amber-300 tracking-widest bg-slate-950 px-3 py-1 rounded-xl border border-orange-500/30">
                {currentRide.startOtp}
              </span>
            </div>
          </div>
        )}

        {/* Driver Details Card */}
        <div className="bg-slate-950/80 rounded-2xl p-3 border border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={
                currentRide.driver?.photo ||
                'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80'
              }
              alt="Driver"
              className="w-12 h-12 rounded-2xl object-cover border-2 border-orange-500 shadow"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="font-bold text-white text-sm">
                  {currentRide.driver?.name || 'Rameshwar Sahu'}
                </h4>
                <span className="flex items-center text-amber-400 text-xs font-bold">
                  ★ {currentRide.driver?.rating || 4.89}
                </span>
              </div>
              <p className="text-xs text-orange-400 font-bold uppercase tracking-wider">
                {currentRide.driver?.vehicleNumber || 'CG 15 AB 4821'}
              </p>
              <p className="text-[11px] text-slate-400">
                {currentRide.driver?.vehicleModel || 'Hero Splendor Plus'}
              </p>
            </div>
          </div>

          {/* Call & Chat Action buttons */}
          <div className="flex items-center gap-2">
            <a
              href={`tel:${currentRide.driver?.phone || '+919826145892'}`}
              className="w-10 h-10 rounded-xl bg-emerald-600/20 hover:bg-emerald-600 border border-emerald-500/40 text-emerald-400 hover:text-white flex items-center justify-center transition active:scale-95"
              title="Call Pilot"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              onClick={() => setShowChat(true)}
              className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition active:scale-95"
              title="Chat with Pilot"
            >
              <MessageSquare className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Action button row depending on state */}
        {status === 'COMPLETED' ? (
          <div className="space-y-2 pt-1">
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center justify-between text-xs">
              <div>
                <p className="font-bold text-emerald-400">
                  {language === 'hi' ? 'राइड पूरी हो गई है!' : 'Ride Completed Successfully!'}
                </p>
                <p className="text-slate-300">Total: ₹{currentRide.finalFare}</p>
              </div>
              <button
                onClick={() => setShowPayment(true)}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs"
              >
                {language === 'hi' ? 'रसीद व भुगतान' : 'Bill & Payment'}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setShowRating(true)}
                className="py-2.5 bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition"
              >
                <Star className="w-3.5 h-3.5 fill-white" />
                <span>{language === 'hi' ? 'रेटिंग दें' : 'Rate Pilot'}</span>
              </button>

              <button
                onClick={resetRide}
                className="py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition"
              >
                {language === 'hi' ? 'नई राइड बुक करें' : 'Book New Ride'}
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800">
            <div className="text-slate-400">
              <span>Payment Mode: </span>
              <span className="font-semibold text-slate-200 uppercase">
                {currentRide.paymentMethod}
              </span>
              <span className="font-bold text-white ml-2">₹{currentRide.finalFare}</span>
            </div>

            {status !== 'IN_PROGRESS' && (
              <button
                onClick={() => setConfirmCancel(true)}
                className="text-rose-400 hover:text-rose-300 font-semibold"
              >
                {language === 'hi' ? 'राइड रद्द करें' : 'Cancel Ride'}
              </button>
            )}
          </div>
        )}

        {/* Cancellation confirmation prompt */}
        {confirmCancel && (
          <div className="p-3 bg-rose-950/40 border border-rose-800/80 rounded-xl space-y-2 text-xs">
            <p className="font-bold text-rose-300">
              {language === 'hi' ? 'क्या आप सच में राइड रद्द करना चाहते हैं?' : 'Are you sure you want to cancel?'}
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  cancelRide('Customer cancelled');
                  setConfirmCancel(false);
                }}
                className="flex-1 py-1.5 bg-rose-600 text-white font-bold rounded-lg"
              >
                Yes, Cancel
              </button>
              <button
                onClick={() => setConfirmCancel(false)}
                className="flex-1 py-1.5 bg-slate-800 text-slate-300 font-bold rounded-lg"
              >
                Keep Ride
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      {showChat && <DriverChatModal onClose={() => setShowChat(false)} />}
      {showPayment && <PaymentModal onClose={() => setShowPayment(false)} />}
      {showRating && <RideRatingModal onClose={() => setShowRating(false)} />}
      {showSos && <SosEmergencyModal onClose={() => setShowSos(false)} />}
    </>
  );
};
