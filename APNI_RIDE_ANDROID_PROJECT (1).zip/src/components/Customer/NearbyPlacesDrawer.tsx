import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import { LocationCategory, LocationPoint } from '../../types/ride';
import { AMBIKAPUR_LOCATIONS } from '../../data/ambikapurLocations';
import {
  X,
  Compass,
  MapPin,
  Hospital,
  Shield,
  Fuel,
  Utensils,
  GraduationCap,
  ShoppingBag,
  Bus,
  CreditCard,
  Pill,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { playSound } from '../../utils/soundEffects';

interface NearbyPlacesDrawerProps {
  onClose: () => void;
  onSelectPlace: (place: LocationPoint, action: 'pickup' | 'drop' | 'view') => void;
}

export const NearbyPlacesDrawer: React.FC<NearbyPlacesDrawerProps> = ({
  onClose,
  onSelectPlace,
}) => {
  const { language } = useRide();
  const [activeCategory, setActiveCategory] = useState<LocationCategory | 'all'>('all');

  const categories: { id: LocationCategory | 'all'; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: 'All Places', icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'hospital', label: 'Hospitals', icon: <Hospital className="w-3.5 h-3.5 text-rose-400" /> },
    { id: 'police', label: 'Police', icon: <Shield className="w-3.5 h-3.5 text-blue-400" /> },
    { id: 'petrol', label: 'Petrol Pumps', icon: <Fuel className="w-3.5 h-3.5 text-emerald-400" /> },
    { id: 'pharmacy', label: 'Pharmacies', icon: <Pill className="w-3.5 h-3.5 text-amber-400" /> },
    { id: 'bank', label: 'Banks & ATMs', icon: <CreditCard className="w-3.5 h-3.5 text-cyan-400" /> },
    { id: 'hotel', label: 'Hotels & Food', icon: <Utensils className="w-3.5 h-3.5 text-orange-400" /> },
    { id: 'transit', label: 'Bus & Station', icon: <Bus className="w-3.5 h-3.5 text-indigo-400" /> },
    { id: 'school', label: 'Colleges & Schools', icon: <GraduationCap className="w-3.5 h-3.5 text-violet-400" /> },
    { id: 'commercial', label: 'Markets & Malls', icon: <ShoppingBag className="w-3.5 h-3.5 text-pink-400" /> },
  ];

  const filteredPlaces =
    activeCategory === 'all'
      ? AMBIKAPUR_LOCATIONS
      : AMBIKAPUR_LOCATIONS.filter((p) => p.category === activeCategory);

  return (
    <div className="fixed inset-0 z-[700] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl p-5 overflow-hidden flex flex-col max-h-[85vh] animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-600/20 text-orange-400 flex items-center justify-center font-bold">
              <Compass className="w-4 h-4 animate-spin-slow" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                {language === 'hi' ? 'अम्बिकापुर दर्शनीय व आवश्यक स्थल' : 'Nearby Places & Directory'}
              </h2>
              <p className="text-[11px] text-slate-400">Discover key locations around Ambikapur</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Category Horizontal Filter Carousel */}
        <div className="py-2.5 flex gap-1.5 overflow-x-auto no-scrollbar border-b border-slate-800/80">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id);
                playSound('beep');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition shadow ${
                activeCategory === cat.id
                  ? 'bg-orange-600 text-white'
                  : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {cat.icon}
              <span>{cat.label}</span>
            </button>
          ))}
        </div>

        {/* Places List */}
        <div className="flex-1 overflow-y-auto space-y-2 py-3">
          <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider px-1">
            Found {filteredPlaces.length} Verified Locations
          </p>

          {filteredPlaces.map((place) => (
            <div
              key={place.id}
              className="p-3 rounded-2xl bg-slate-950/80 border border-slate-800/90 hover:border-slate-700 transition space-y-2"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="truncate">
                  <h4 className="text-xs font-bold text-white truncate">
                    {language === 'hi' ? place.nameHi : place.name}
                  </h4>
                  <p className="text-[11px] text-slate-400 truncate mt-0.5">{place.address}</p>
                  {place.landmarkNear && (
                    <p className="text-[10px] text-orange-400 font-medium mt-0.5">
                      Near: {place.landmarkNear}
                    </p>
                  )}
                </div>
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 shrink-0">
                  {place.category}
                </span>
              </div>

              {/* Action Buttons: Set as Pickup, Set as Drop, View on Map */}
              <div className="flex items-center gap-2 pt-1 border-t border-slate-800/60 text-xs">
                <button
                  onClick={() => {
                    onSelectPlace(place, 'pickup');
                    playSound('beep');
                    onClose();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white font-bold transition text-[11px]"
                >
                  Set as Pickup
                </button>
                <button
                  onClick={() => {
                    onSelectPlace(place, 'drop');
                    playSound('beep');
                    onClose();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-rose-600/20 hover:bg-rose-600 text-rose-400 hover:text-white font-bold transition text-[11px]"
                >
                  Set as Drop
                </button>
                <button
                  onClick={() => {
                    onSelectPlace(place, 'view');
                    playSound('beep');
                    onClose();
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition text-[11px] ml-auto"
                >
                  View on Map
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
