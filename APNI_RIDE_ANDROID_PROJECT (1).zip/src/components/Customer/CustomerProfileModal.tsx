import React, { useState } from 'react';
import { useRide } from '../../context/RideContext';
import {
  X,
  User,
  Phone,
  Mail,
  Wallet,
  ShieldCheck,
  History,
  Star,
  MapPin,
  CheckCircle,
  Plus,
  Receipt,
} from 'lucide-react';
import { playSound } from '../../utils/soundEffects';

interface CustomerProfileModalProps {
  onClose: () => void;
}

export const CustomerProfileModal: React.FC<CustomerProfileModalProps> = ({ onClose }) => {
  const { customer, updateCustomerProfile, rideHistory, language, customerLogin } = useRide();

  const [activeTab, setActiveTab] = useState<'profile' | 'wallet' | 'history'>('profile');
  const [name, setName] = useState(customer.name);
  const [email, setEmail] = useState(customer.email);
  const [phone, setPhone] = useState(customer.phone);
  const [otpInput, setOtpInput] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Wallet add money
  const handleAddMoney = (amt: number) => {
    updateCustomerProfile({ walletBalance: customer.walletBalance + amt });
    playSound('success');
  };

  const handleSendOtp = () => {
    setOtpSent(true);
    setOtpInput('5829'); // Simulated auto-sent OTP
    playSound('beep');
  };

  const handleVerifyOtp = () => {
    customerLogin(phone, otpInput);
    setOtpSent(false);
  };

  const handleSaveProfile = () => {
    updateCustomerProfile({ name, email });
    setSavedSuccess(true);
    playSound('success');
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-[700] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-0 sm:p-4">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={customer.photo}
              alt={customer.name}
              className="w-11 h-11 rounded-2xl object-cover border-2 border-orange-500 shadow"
            />
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-1.5">
                {customer.name}
                <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.2 rounded font-semibold">
                  Verified
                </span>
              </h2>
              <p className="text-xs text-slate-400">{customer.phone}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/50 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-3 text-center border-b-2 transition ${
              activeTab === 'profile'
                ? 'border-orange-500 text-orange-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {language === 'hi' ? 'प्रोफ़ाइल विवरण' : 'My Profile'}
          </button>
          <button
            onClick={() => setActiveTab('wallet')}
            className={`flex-1 py-3 text-center border-b-2 transition ${
              activeTab === 'wallet'
                ? 'border-orange-500 text-orange-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {language === 'hi' ? 'वॉलेट (₹)' : 'Apni Wallet'}
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-3 text-center border-b-2 transition ${
              activeTab === 'history'
                ? 'border-orange-500 text-orange-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            {language === 'hi' ? 'राइड हिस्ट्री' : 'Ride History'}
          </button>
        </div>

        {/* Tab contents */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'profile' && (
            <div className="space-y-4">
              {/* Form fields */}
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">
                    {language === 'hi' ? 'पूरा नाम' : 'Full Name'}
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">
                    {language === 'hi' ? 'ईमेल आईडी' : 'Email Address'}
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
                  />
                </div>

                {/* Mobile OTP Verification simulation */}
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">
                    {language === 'hi' ? 'मोबाइल नंबर (OTP सत्यापन)' : 'Mobile Phone (OTP Verified)'}
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none focus:border-orange-500"
                    />
                    <button
                      onClick={handleSendOtp}
                      className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-orange-400 border border-slate-700"
                    >
                      {otpSent ? 'Resend' : 'Send OTP'}
                    </button>
                  </div>

                  {otpSent && (
                    <div className="mt-2 p-2.5 bg-orange-500/10 border border-orange-500/30 rounded-xl flex items-center justify-between gap-2">
                      <div className="flex-1">
                        <p className="text-[11px] text-amber-300 font-bold">
                          OTP Sent! Demo code: 5829
                        </p>
                        <input
                          type="text"
                          value={otpInput}
                          onChange={(e) => setOtpInput(e.target.value)}
                          placeholder="Enter 4-digit OTP"
                          className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white mt-1"
                        />
                      </div>
                      <button
                        onClick={handleVerifyOtp}
                        className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs rounded-lg mt-3"
                      >
                        Verify
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {savedSuccess && (
                <div className="p-2.5 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>Profile updated successfully!</span>
                </div>
              )}

              <button
                onClick={handleSaveProfile}
                className="w-full py-3 bg-orange-600 hover:bg-orange-500 text-white font-bold text-sm rounded-xl transition shadow shadow-orange-600/30"
              >
                {language === 'hi' ? 'परिवर्तन सहेजें' : 'Save Profile Changes'}
              </button>
            </div>
          )}

          {activeTab === 'wallet' && (
            <div className="space-y-4">
              <div className="bg-gradient-to-br from-orange-600 to-amber-600 rounded-2xl p-5 text-white shadow-lg shadow-orange-600/30">
                <p className="text-xs uppercase tracking-wider font-semibold opacity-90">
                  APNI RIDE PASSENGER WALLET
                </p>
                <h3 className="text-3xl font-black mt-1">₹{customer.walletBalance}</h3>
                <p className="text-[11px] opacity-80 mt-2">
                  Use for 1-tap checkout on all Bike, Auto and Cab rides in Ambikapur.
                </p>
              </div>

              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                  {language === 'hi' ? 'वॉलेट में पैसे जोड़ें (तुरंत)' : 'Top-up Wallet (Instant)'}
                </p>
                <div className="grid grid-cols-3 gap-2">
                  {[100, 250, 500].map((amt) => (
                    <button
                      key={amt}
                      onClick={() => handleAddMoney(amt)}
                      className="p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-orange-500 text-white text-center font-bold text-sm transition group"
                    >
                      <Plus className="w-3.5 h-3.5 mx-auto mb-1 text-orange-400 group-hover:scale-110 transition" />
                      <span>+ ₹{amt}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-2">
              {rideHistory.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  <Receipt className="w-8 h-8 mx-auto mb-2 text-slate-600" />
                  <p>{language === 'hi' ? 'अभी कोई पुरानी राइड नहीं है।' : 'No completed rides yet.'}</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Your completed Ambikapur journeys will appear here.
                  </p>
                </div>
              ) : (
                rideHistory.map((r) => (
                  <div
                    key={r.id}
                    className="p-3 bg-slate-950/80 rounded-xl border border-slate-800 text-xs space-y-1.5"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white flex items-center gap-1.5">
                        <span className="text-orange-400">
                          {r.vehicleCategory === 'bike' ? '🏍️' : r.vehicleCategory === 'auto' ? '🛺' : '🚗'}
                        </span>
                        <span>{r.pickup.name} → {r.destination.name}</span>
                      </span>
                      <span className="font-black text-emerald-400 text-sm">₹{r.finalFare}</span>
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-400">
                      <span>{new Date(r.createdAt).toLocaleDateString()}</span>
                      <span className="uppercase text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                        {r.status} • {r.paymentMethod}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
