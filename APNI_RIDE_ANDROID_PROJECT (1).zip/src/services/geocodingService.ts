import { LocationPoint } from '../types/ride';
import { AMBIKAPUR_CENTER, AMBIKAPUR_LOCATIONS } from '../data/ambikapurLocations';

// Local search over all Ambikapur localities, mohallas, shops, and landmarks
export function searchLocalAmbikapur(query: string): LocationPoint[] {
  if (!query || query.trim().length === 0) {
    return AMBIKAPUR_LOCATIONS.slice(0, 8);
  }

  const cleanQ = query.toLowerCase().trim();

  return AMBIKAPUR_LOCATIONS.filter((loc) => {
    return (
      loc.name.toLowerCase().includes(cleanQ) ||
      loc.nameHi.includes(cleanQ) ||
      loc.address.toLowerCase().includes(cleanQ) ||
      loc.addressHi.includes(cleanQ) ||
      (loc.colony && loc.colony.toLowerCase().includes(cleanQ)) ||
      (loc.landmarkNear && loc.landmarkNear.toLowerCase().includes(cleanQ)) ||
      loc.category.toLowerCase().includes(cleanQ)
    );
  });
}

// Live Reverse Geocoding: Converts lat/lng to Ambikapur address
export async function reverseGeocodeAmbikapur(lat: number, lng: number): Promise<LocationPoint> {
  // First check nearest from our rich local landmark database within 250m
  const nearest = findNearestLandmark(lat, lng);
  if (nearest && nearest.distanceMeters < 300) {
    return {
      ...nearest.point,
      id: `loc-rev-${Date.now()}`,
      lat,
      lng,
    };
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);

    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`;
    const res = await fetch(url, {
      signal: controller.signal,
      headers: {
        'Accept-Language': 'hi,en',
        'User-Agent': 'ApniRideAmbikapurApp/1.0',
      },
    });
    clearTimeout(timeout);

    if (res.ok) {
      const data = await res.json();
      const addr = data.address || {};
      const road = addr.road || addr.suburb || addr.neighbourhood || addr.residential || 'Ambikapur Road';
      const city = addr.city || addr.town || 'Ambikapur';
      const name = data.name || road;

      return {
        id: `loc-pin-${Date.now()}`,
        name: `${name}, ${city}`,
        nameHi: `${name}, अम्बिकापुर`,
        address: data.display_name || `${road}, Ambikapur, Chhattisgarh`,
        addressHi: `${road}, अम्बिकापुर, छत्तीसगढ़`,
        lat,
        lng,
        category: 'landmark',
      };
    }
  } catch {
    // fallback
  }

  // Graceful fallback using local coordinates
  return {
    id: `loc-pin-${Date.now()}`,
    name: `Selected Point (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
    nameHi: `चुना गया स्थान (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
    address: 'Ambikapur Urban Road, Surguja, CG-15',
    addressHi: 'अम्बिकापुर नगरीय क्षेत्र, सरगुजा (CG-15)',
    lat,
    lng,
    category: 'landmark',
  };
}

// Helper: Find nearest landmark from coordinates
export function findNearestLandmark(lat: number, lng: number): { point: LocationPoint; distanceMeters: number } | null {
  let closest: LocationPoint | null = null;
  let minDistance = Infinity;

  AMBIKAPUR_LOCATIONS.forEach((loc) => {
    const d = calculateDistanceMeters(lat, lng, loc.lat, loc.lng);
    if (d < minDistance) {
      minDistance = d;
      closest = loc;
    }
  });

  return closest ? { point: closest, distanceMeters: Math.round(minDistance) } : null;
}

function calculateDistanceMeters(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371e3; // meters
  const phi1 = (lat1 * Math.PI) / 180;
  const phi2 = (lat2 * Math.PI) / 180;
  const deltaPhi = ((lat2 - lat1) * Math.PI) / 180;
  const deltaLambda = ((lon2 - lon1) * Math.PI) / 180;

  const a =
    Math.sin(deltaPhi / 2) * Math.sin(deltaPhi / 2) +
    Math.cos(phi1) * Math.cos(phi2) * Math.sin(deltaLambda / 2) * Math.sin(deltaLambda / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}
