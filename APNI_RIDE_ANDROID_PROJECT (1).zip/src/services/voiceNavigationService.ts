// Voice Navigation Service using HTML5 SpeechSynthesis

let isVoiceMuted = false;

export function toggleVoiceMute(): boolean {
  isVoiceMuted = !isVoiceMuted;
  if (isVoiceMuted && typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
  return isVoiceMuted;
}

export function getVoiceMutedState(): boolean {
  return isVoiceMuted;
}

export function speakNavigationInstruction(text: string, language: 'hi' | 'en' = 'hi') {
  if (isVoiceMuted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return;
  }

  try {
    window.speechSynthesis.cancel(); // Stop any pending speech

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Try finding Hindi or Indian English voice
    const voices = window.speechSynthesis.getVoices();
    if (language === 'hi') {
      const hiVoice = voices.find((v) => v.lang.includes('hi') || v.lang.includes('IN'));
      if (hiVoice) utterance.voice = hiVoice;
      utterance.lang = 'hi-IN';
    } else {
      const enVoice = voices.find((v) => v.lang.includes('en-IN') || v.lang.includes('en'));
      if (enVoice) utterance.voice = enVoice;
      utterance.lang = 'en-IN';
    }

    window.speechSynthesis.speak(utterance);
  } catch {
    // Graceful fallback if speech synthesis is disabled on device
  }
}
