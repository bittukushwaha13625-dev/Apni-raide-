import { LocationPoint, RouteOption, TurnInstruction } from '../types/ride';

// Generates route options connecting Pickup and Dropoff across Ambikapur
export async function calculateAmbikapurRoutes(
  pickup: LocationPoint,
  destination: LocationPoint
): Promise<RouteOption[]> {
  const directDistKm = calculateHaversineKm(pickup.lat, pickup.lng, destination.lat, destination.lng);
  
  // Real road distances are typically 1.25x to 1.35x direct line in Ambikapur's grid
  const primaryDistKm = Math.max(1.2, Number((directDistKm * 1.28).toFixed(1)));
  const altDistKm = Math.max(1.0, Number((directDistKm * 1.15).toFixed(1)));

  const primaryDurationMin = Math.max(3, Math.round(primaryDistKm * 2.2));
  const altDurationMin = Math.max(4, Math.round(altDistKm * 2.8)); // Slower due to town bazaar traffic

  // Generate primary route via Ring Road / Main Highway
  const primaryPolyline = generateRoadGeometry(
    [pickup.lat, pickup.lng],
    [destination.lat, destination.lng],
    'ring_road'
  );

  // Generate alternative route via Inner Sadar / Bazaar road
  const altPolyline = generateRoadGeometry(
    [pickup.lat, pickup.lng],
    [destination.lat, destination.lng],
    'inner_city'
  );

  const primaryInstructions = generateTurnInstructions(pickup, destination, 'ring_road');
  const altInstructions = generateTurnInstructions(pickup, destination, 'inner_city');

  const primaryRoute: RouteOption = {
    id: 'route-fastest',
    name: 'Fastest via Ring Road Bypass',
    nameHi: 'रिंग रोड बायपास से (सबसे तेज़)',
    viaRoad: 'Via Ring Road & Manendragarh Highway',
    viaRoadHi: 'रिंग रोड व मनेन्द्रगढ़ हाईवे होकर',
    distanceKm: primaryDistKm,
    durationMinutes: primaryDurationMin,
    trafficLevel: 'smooth',
    isRecommended: true,
    polyline: primaryPolyline,
    turnInstructions: primaryInstructions,
  };

  const altRoute: RouteOption = {
    id: 'route-shortest',
    name: 'Shortest via Sadar Road Market',
    nameHi: 'सदर बाजार होकर (कम दूरी)',
    viaRoad: 'Via Sadar Road & Ghadi Chowk',
    viaRoadHi: 'सदर रोड व घड़ी चौक होकर',
    distanceKm: altDistKm,
    durationMinutes: altDurationMin,
    trafficLevel: 'moderate',
    isRecommended: false,
    polyline: altPolyline,
    turnInstructions: altInstructions,
  };

  return [primaryRoute, altRoute];
}

// Generates realistic multi-segment road coordinates following Ambikapur street curvature
function generateRoadGeometry(
  start: [number, number],
  end: [number, number],
  mode: 'ring_road' | 'inner_city'
): [number, number][] {
  const points: [number, number][] = [];
  const steps = 16;

  const latDiff = end[0] - start[0];
  const lngDiff = end[1] - start[1];

  // Road offset curve
  const offsetMultiplier = mode === 'ring_road' ? 0.0035 : -0.0025;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    // Base straight line
    let curLat = start[0] + latDiff * t;
    let curLng = start[1] + lngDiff * t;

    // Apply smooth sinusoidal road curvature resembling city streets
    const bend = Math.sin(t * Math.PI) * offsetMultiplier;
    curLat += bend * 0.7;
    curLng += bend * 1.1;

    points.push([Number(curLat.toFixed(5)), Number(curLng.toFixed(5))]);
  }

  return points;
}

// Generate turn-by-turn navigation steps
function generateTurnInstructions(
  pickup: LocationPoint,
  drop: LocationPoint,
  mode: 'ring_road' | 'inner_city'
): TurnInstruction[] {
  if (mode === 'ring_road') {
    return [
      {
        stepIndex: 1,
        instruction: `Head north from ${pickup.name} towards Main Highway`,
        instructionHi: `${pickup.nameHi} से मुख्य मार्ग की ओर आगे बढ़ें`,
        distanceMeters: 400,
        maneuver: 'straight',
        coordinate: [pickup.lat, pickup.lng],
        roadName: 'Main Link Road',
      },
      {
        stepIndex: 2,
        instruction: 'Turn right onto Ambikapur Ring Road Bypass',
        instructionHi: 'अम्बिकापुर रिंग रोड बायपास पर दाएं मुड़ें',
        distanceMeters: 1800,
        maneuver: 'turn-right',
        coordinate: [(pickup.lat + drop.lat) / 2 + 0.002, (pickup.lng + drop.lng) / 2],
        roadName: 'Ring Road (NH 343)',
      },
      {
        stepIndex: 3,
        instruction: 'At the roundabout, take the 2nd exit toward Destination',
        instructionHi: 'चौराहे से दूसरा निकास लें और गंतव्य की ओर बढ़ें',
        distanceMeters: 900,
        maneuver: 'roundabout',
        coordinate: [(pickup.lat + drop.lat) / 2 - 0.001, (pickup.lng + drop.lng) / 2 + 0.002],
        roadName: 'Station Approach Road',
      },
      {
        stepIndex: 4,
        instruction: `Arrive at ${drop.name} on the left`,
        instructionHi: `${drop.nameHi} पर बाईं ओर आगमन`,
        distanceMeters: 100,
        maneuver: 'arrive',
        coordinate: [drop.lat, drop.lng],
        roadName: drop.name,
      },
    ];
  } else {
    return [
      {
        stepIndex: 1,
        instruction: `Start from ${pickup.name} and proceed straight`,
        instructionHi: `${pickup.nameHi} से सीधे आगे बढ़ें`,
        distanceMeters: 300,
        maneuver: 'straight',
        coordinate: [pickup.lat, pickup.lng],
        roadName: 'Colony Road',
      },
      {
        stepIndex: 2,
        instruction: 'Turn left at Ghadi Chowk intersection into Sadar Road',
        instructionHi: 'घड़ी चौक से सदर रोड की ओर बाएं मुड़ें',
        distanceMeters: 1100,
        maneuver: 'turn-left',
        coordinate: [23.1235, 83.1965],
        roadName: 'Sadar Road Bazaar',
      },
      {
        stepIndex: 3,
        instruction: 'Continue straight through Gudri Market corridor',
        instructionHi: 'गुदरी बाजार मार्ग से सीधे आगे बढ़ते रहें',
        distanceMeters: 850,
        maneuver: 'straight',
        coordinate: [(pickup.lat + drop.lat) / 2, (pickup.lng + drop.lng) / 2],
        roadName: 'Gudri Road',
      },
      {
        stepIndex: 4,
        instruction: `You have arrived at ${drop.name}`,
        instructionHi: `आप ${drop.nameHi} पहुँच चुके हैं`,
        distanceMeters: 50,
        maneuver: 'arrive',
        coordinate: [drop.lat, drop.lng],
        roadName: drop.name,
      },
    ];
  }
}

function calculateHaversineKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}
