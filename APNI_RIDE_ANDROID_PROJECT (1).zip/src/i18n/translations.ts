export type Language = 'en' | 'hi';

export interface Translations {
  appName: string;
  tagline: string;
  cityBadge: string;
  customerApp: string;
  driverApp: string;
  adminPanel: string;
  devicePreview: string;
  downloadApk: string;
  
  // Customer Booking
  whereTo: string;
  pickupLocation: string;
  dropLocation: string;
  currentLocation: string;
  selectOnMap: string;
  popularPlaces: string;
  chooseRide: string;
  bookNow: string;
  scheduleLater: string;
  confirmBooking: string;
  findingDriver: string;
  findingSubtext: string;
  connectingWithNearby: string;
  cancelRide: string;
  
  // Ride Status
  driverArriving: string;
  driverArrived: string;
  rideInProgress: string;
  rideCompleted: string;
  rideCancelled: string;
  otpToStart: string;
  shareOtpWithDriver: string;
  callDriver: string;
  chatWithDriver: string;
  sosEmergency: string;
  eta: string;
  distance: string;
  estFare: string;
  totalFare: string;
  
  // Payment
  payVia: string;
  cashOnDrop: string;
  onlineUpi: string;
  wallet: string;
  payNow: string;
  paymentSuccess: string;
  
  // Driver App
  driverPartner: string;
  online: string;
  offline: string;
  goOnline: string;
  goOffline: string;
  newRideAlert: string;
  accept: string;
  reject: string;
  startTrip: string;
  completeTrip: string;
  enterOtp: string;
  verifyOtp: string;
  todaysEarnings: string;
  totalRides: string;
  driverRating: string;
  walletBalance: string;
  kycVerification: string;
  kycVerified: string;
  kycPending: string;
  uploadDocuments: string;
  
  // Admin Panel
  adminDashboard: string;
  totalCustomers: string;
  totalDrivers: string;
  activeRidesCount: string;
  totalRevenue: string;
  driverCommission: string;
  liveFleetMonitoring: string;
  driverApprovals: string;
  fareSettings: string;
  approve: string;
  rejectAction: string;
  
  // Modals & Extras
  promoCode: string;
  applyPromo: string;
  applied: string;
  rateYourRide: string;
  submitReview: string;
  emergencyAlertSent: string;
  safetyMessage: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appName: 'APNI RIDE',
    tagline: "Ambikapur's Premier Ride Booking Platform",
    cityBadge: 'Ambikapur, CG-15',
    customerApp: 'Customer App',
    driverApp: 'Driver Partner',
    adminPanel: 'Admin Control',
    devicePreview: 'Android Frame',
    downloadApk: 'Download APK',
    
    whereTo: 'Where do you want to go?',
    pickupLocation: 'Pickup Location',
    dropLocation: 'Where to drop?',
    currentLocation: 'Current Location',
    selectOnMap: 'Select on Map',
    popularPlaces: 'Popular Ambikapur Hubs',
    chooseRide: 'Choose your ride',
    bookNow: 'Book Apni Ride Now',
    scheduleLater: 'Schedule for Later',
    confirmBooking: 'Confirm Booking',
    findingDriver: 'Connecting to nearby drivers...',
    findingSubtext: 'Matching you with the fastest Bike, Auto or Cab in Ambikapur',
    connectingWithNearby: 'Searching nearby pilots in 3 km radius',
    cancelRide: 'Cancel Ride',
    
    driverArriving: 'Driver is Arriving',
    driverArrived: 'Driver has Arrived at Pickup',
    rideInProgress: 'Heading to Destination',
    rideCompleted: 'You Have Arrived!',
    rideCancelled: 'Ride Cancelled',
    otpToStart: 'Start Ride PIN',
    shareOtpWithDriver: 'Share this 4-digit PIN with driver to start ride',
    callDriver: 'Call Driver',
    chatWithDriver: 'Chat with Driver',
    sosEmergency: 'SOS Emergency',
    eta: 'ETA',
    distance: 'Distance',
    estFare: 'Est. Fare',
    totalFare: 'Total Fare',
    
    payVia: 'Payment Method',
    cashOnDrop: 'Cash to Driver',
    onlineUpi: 'UPI (GPay / PhonePe / Paytm)',
    wallet: 'Apni Ride Wallet',
    payNow: 'Pay Now',
    paymentSuccess: 'Payment Successful!',
    
    driverPartner: 'Apni Ride Partner',
    online: 'ONLINE',
    offline: 'OFFLINE',
    goOnline: 'Go Online to Receive Rides',
    goOffline: 'Go Offline',
    newRideAlert: 'NEW RIDE REQUEST!',
    accept: 'ACCEPT RIDE',
    reject: 'DECLINE',
    startTrip: 'Start Trip',
    completeTrip: 'Complete Ride',
    enterOtp: 'Enter Customer 4-digit OTP',
    verifyOtp: 'Verify & Start',
    todaysEarnings: "Today's Earnings",
    totalRides: 'Total Rides Completed',
    driverRating: 'Your Rating',
    walletBalance: 'Driver Wallet',
    kycVerification: 'KYC & Vehicle Verification',
    kycVerified: 'Verified & Active',
    kycPending: 'Pending Admin Review',
    uploadDocuments: 'Submit KYC Documents',
    
    adminDashboard: 'Admin Control Center',
    totalCustomers: 'Total Passengers',
    totalDrivers: 'Active Fleet Drivers',
    activeRidesCount: 'Live Active Rides',
    totalRevenue: 'Total Gross Revenue',
    driverCommission: 'Platform Commission (15%)',
    liveFleetMonitoring: 'Ambikapur Live City Map',
    driverApprovals: 'Driver KYC Approvals',
    fareSettings: 'Vehicle Fare Config',
    approve: 'Approve',
    rejectAction: 'Reject',
    
    promoCode: 'Have a Promo Code?',
    applyPromo: 'Apply',
    applied: 'Applied',
    rateYourRide: 'Rate your journey',
    submitReview: 'Submit Feedback',
    emergencyAlertSent: 'Emergency SOS Signal Sent!',
    safetyMessage: 'Alerting Ambikapur Police (112) & Emergency Contacts with live GPS coordinates.',
  },
  
  hi: {
    appName: 'अपनी राइड',
    tagline: 'अम्बिकापुर की अपनी भरोसेमंद सवारी',
    cityBadge: 'अम्बिकापुर, सरगुजा (CG-15)',
    customerApp: 'ग्राहक ऐप',
    driverApp: 'ड्राइवर पार्टनर',
    adminPanel: 'एडमिन कंट्रोल',
    devicePreview: 'मोबाइल व्यू',
    downloadApk: 'APK डाउनलोड',
    
    whereTo: 'आपको कहाँ जाना है?',
    pickupLocation: 'पिकअप स्थान',
    dropLocation: 'ड्रॉप स्थान (कहाँ जाना है)',
    currentLocation: 'वर्तमान स्थान',
    selectOnMap: 'मैप पर चुनें',
    popularPlaces: 'अम्बिकापुर के प्रमुख स्थान',
    chooseRide: 'अपनी सवारी चुनें',
    bookNow: 'तुरंत राइड बुक करें',
    scheduleLater: 'बाद के लिए शेड्यूल करें',
    confirmBooking: 'बुकिंग कन्फर्म करें',
    findingDriver: 'नजदीकी ड्राइवर खोज रहे हैं...',
    findingSubtext: 'अम्बिकापुर में सबसे नजदीकी बाइक, ऑटो या कैब से कनेक्ट किया जा रहा है',
    connectingWithNearby: '3 किमी के दायरे में उपलब्ध ड्राइवर सर्च हो रहे हैं',
    cancelRide: 'राइड कैंसिल करें',
    
    driverArriving: 'ड्राइवर आ रहा है',
    driverArrived: 'ड्राइवर आपके स्थान पर पहुँच गया है',
    rideInProgress: 'सफर जारी है',
    rideCompleted: 'आप गंतव्य पर पहुँच चुके हैं!',
    rideCancelled: 'राइड रद्द कर दी गई',
    otpToStart: 'राइड शुरू करने का पिन',
    shareOtpWithDriver: 'सफर शुरू करने के लिए यह 4-अंकीय पिन ड्राइवर को बताएं',
    callDriver: 'कॉल करें',
    chatWithDriver: 'मैसेज भेजें',
    sosEmergency: 'आपातकालीन SOS',
    eta: 'अनुमानित समय',
    distance: 'दूरी',
    estFare: 'अनुमानित किराया',
    totalFare: 'कुल किराया',
    
    payVia: 'भुगतान का तरीका',
    cashOnDrop: 'ड्राइवर को नकद दें',
    onlineUpi: 'UPI (GPay / PhonePe / Paytm)',
    wallet: 'अपनी राइड वॉलेट',
    payNow: 'भुगतान करें',
    paymentSuccess: 'भुगतान सफल रहा!',
    
    driverPartner: 'अपनी राइड पायलट पार्टनर',
    online: 'ऑनलाइन (ड्यूटी चालू)',
    offline: 'ऑफलाइन (ड्यूटी बंद)',
    goOnline: 'राइड पाने के लिए ऑनलाइन आएं',
    goOffline: 'ऑफलाइन जाएं',
    newRideAlert: 'नई राइड रिक्वेस्ट आई है!',
    accept: 'राइड स्वीकार करें',
    reject: 'अस्वीकार करें',
    startTrip: 'राइड शुरू करें',
    completeTrip: 'राइड पूर्ण करें',
    enterOtp: 'ग्राहक का 4-अंकीय OTP दर्ज करें',
    verifyOtp: 'सत्यापित कर शुरू करें',
    todaysEarnings: 'आज की कुल कमाई',
    totalRides: 'पूर्ण की गई राइड्स',
    driverRating: 'आपकी रेटिंग',
    walletBalance: 'ड्राइवर वॉलेट शेष',
    kycVerification: 'केवाईसी व वाहन दस्तावेज',
    kycVerified: 'सत्यापित व सक्रिय',
    kycPending: 'एडमिन द्वारा जांच जारी',
    uploadDocuments: 'दस्तावेज अपलोड करें',
    
    adminDashboard: 'एडमिनिस्ट्रेटर कंट्रोल सेंटर',
    totalCustomers: 'कुल पंजीकृत ग्राहक',
    totalDrivers: 'पंजीकृत ड्राइवर',
    activeRidesCount: 'वर्तमान सक्रिय राइड्स',
    totalRevenue: 'कुल सकल आमदनी',
    driverCommission: 'प्लेटफ़ॉर्म कमीशन (15%)',
    liveFleetMonitoring: 'अम्बिकापुर लाइव सिटी फ्लीट मैप',
    driverApprovals: 'ड्राइवर KYC सत्यापन',
    fareSettings: 'किराया व दर निर्धारण',
    approve: 'मंजूरी दें',
    rejectAction: 'अस्वीकार करें',
    
    promoCode: 'प्रोमो कोड है?',
    applyPromo: 'लागू करें',
    applied: 'लागू हुआ',
    rateYourRide: 'अपनी यात्रा का अनुभव बताएं',
    submitReview: 'रेटिंग सबमिट करें',
    emergencyAlertSent: 'आपातकालीन SOS अलर्ट भेजा गया!',
    safetyMessage: 'अम्बिकापुर पुलिस कंट्रोल (112) और आपके परिजनों को लाइव जीपीएस लोकेशन भेज दी गई है।',
  },
};
