/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { RideProvider, useRide } from './context/RideContext';
import { Header } from './components/Common/Header';
import { DeviceFrame } from './components/Common/DeviceFrame';
import { CustomerApp } from './components/Customer/CustomerApp';
import { DriverApp } from './components/Driver/DriverApp';
import { AdminDashboard } from './components/Admin/AdminDashboard';
import { AndroidApkDownloadModal } from './components/Android/AndroidApkDownloadModal';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { WifiOff } from 'lucide-react';

const MainContent: React.FC = () => {
  const {
    activeRole,
    isDevicePreview,
    setIsDevicePreview,
    showApkModal,
    setShowApkModal,
  } = useRide();

  const isOnline = useOnlineStatus();

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans">
      {/* Top Global Navigation Bar */}
      <Header />

      {/* Offline Status Banner */}
      {!isOnline && (
        <div className="bg-amber-600 text-white text-xs py-1 px-4 text-center font-bold flex items-center justify-center gap-2 z-50">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Mode: Ambikapur local cached maps & bookings active</span>
        </div>
      )}

      {/* Main App Workspace */}
      <main className="flex-1 overflow-hidden relative">
        <DeviceFrame
          enabled={isDevicePreview}
          onToggle={() => setIsDevicePreview(false)}
        >
          {activeRole === 'customer' && <CustomerApp />}
          {activeRole === 'driver' && <DriverApp />}
          {activeRole === 'admin' && <AdminDashboard />}
        </DeviceFrame>
      </main>

      {/* Android APK Download Modal */}
      {showApkModal && (
        <AndroidApkDownloadModal onClose={() => setShowApkModal(false)} />
      )}
    </div>
  );
};

export default function App() {
  return (
    <RideProvider>
      <MainContent />
    </RideProvider>
  );
}
